# Maya — by The Hunter AI

A free Android AI voice assistant app. **Original code, written fresh** —
Kotlin + Jetpack Compose (Material3), inspired by the reference screenshots
and the demo video ("Maya AI Android Full Setup Hindi", HunterIsLive).

Maya is a loving, caring companion who speaks Hinglish (Hindi/Urdu in Roman
script) — she calls you **Babu** (default), **Jan** (softer, intimate),
**Janu / Jaaneman / Darling** (rare, playful). She sighs *"Uff Babu"*,
giggles, says *"dil garden garden ho gaya"*, and checks in when you go quiet:
*"Chup hi kyun hai Jan? Main yahin hoon."*

> **Honest note:** this is a complete source project, not a compiled APK.
> It was written on a Linux machine with no Android SDK, so it has **not
> been compiled here**. Open it in Android Studio, build the debug APK and
> install it on a **real phone**. The app runs on your real phone with your
> real location — it contains **no fake GPS / location spoofing, no
> proxy/VPN, and no hosted virtual Android**.

## Screens

- **Splash** — the real splash art from the reference screenshots
  (`res/drawable/splash_art.jpg`: anime girl, neon hearts, night city,
  "MAYA" + "Ek second... load ho raha hai ♥"), full-screen, with the
  animated loading bar overlaid at the bottom.
- **Home** — free-mode banner ("Free mode • aaj 10 min baaki" + "Activate
  karo"), greeting, glowing neural orb, quick cards Gaane / Padhai /
  Journal, info cards Mausam / Aaj / Mood.
- **Chat** — text conversation with Maya, stored in Room.
- **Voice (Conversation Mode)** — big mic screen, orb states
  idle / listening / thinking / speaking.
- **Yaadein (Memory)** — auto-save toggle "Baat ke baad khud yaad rakhe",
  built-in tasks (gemini se poochho, chatgpt se poochho, gemini video,
  gemini image, chatgpt image), Backup & restore (shares a JSON export).
- **Settings** — Gemini API key, persona (Maya / Friday / Venom / Jarvis),
  gender (Male turns on Girlfriend Mode), language, voice pitch/speed,
  Memory section, and links to the screens below.
- **Secret settings — Girlfriend mode** — Friendly (default), Romantic,
  Intense (18+). Applies on next app start; cannot be changed by voice.
  **Intense is gated** behind licence + 18+ age check + double
  confirmation — the gate screen is a placeholder that never bypasses
  the checks, so Intense cannot be enabled in this build. The system
  prompt stays affectionate/romantic at most and never contains
  explicit sexual content.
- **Settings — Memory** — toggle "Maya ko khud se yaad rakhne do"
  (default ON) plus the safety note: passwords, OTP, PIN and card
  numbers are **never** saved. Enforced in code by `MemorySafety.kt`
  (regex deny-list) and memories live only on-device in Room — no
  cloud sync anywhere.
- **Awaaz (Voice picker)** — persona tabs Maya / Friday / Venom / Jarvis,
  "Tap karke suno, phir chuno". Each voice has a play-preview button and
  a selected checkmark. Voice IDs are **real Gemini Live API voice names**
  (Maya: Aoede, Kore, Leda, Zephyr, Laomedeia, Despina, Erinome; Venom:
  Algenib, Charon, Fenrir, Puck, Orus, Enceladus, Iapetus; Friday:
  Sulafat, Umbriel, Autonoe, Sadachbia; Jarvis: Callirrhoe, Alnilam,
  Schedar, Zubenelgenubi). Note: on-device TTS cannot speak in Gemini
  Live voices — the preview plays in the phone's hi-IN voice and the
  selected name is stored for the Live API call.
- **Voice engine** — Normal (Maya Swift "Sabse tez", Maya Soul "Asli
  emotions", Maya Mind "Tez dimaag") vs Advanced Agentic ("Maya ke full
  version ke saath milta hai — getmaya.online se."). The engine changes
  reply style/speed via the system prompt.
- **Connectors** — search bar, filter chips (Sab / Files / Code /
  Notes & tasks), list: Google Drive, GitHub, Vercel, Notion, Telegram,
  Todoist, GitLab, Linear. **Placeholders:** the connect toggles do not
  perform OAuth — tapping one explains that real OAuth login is coming
  soon. No account is ever linked by this screen.
- **Upgrade** — freemium: 10 min/day free voice, locked tools, UPI
  payment. **Payment is a placeholder** (fake UPI ID `hunterai@upi`,
  placeholder QR box) — put your own real UPI ID in before any real sale.
- **Sidebar drawer** — Home, Maya Home, Markets, Marketing, Documents,
  Meri photos, Website/Coding, Terminal, Browser, Accessibility,
  Settings, Maya ke rules, PC ⇌ Phone, Privacy Policy, Upgrade.
  Items without a full screen open an honest "coming soon" page.
- **Bottom nav** — Home, Scan, Mic (highlighted centre), Yaadein, Chat.

## Setup

### Option A — GitHub Actions se APK banao (Android Studio ki zaroorat nahi)

1. GitHub.com par ek **naya repository** banao (public ya private, dono free hain).
2. Is project ki saari files us repo mein upload karo
   (web se: **Add file → Upload files**, ya `git push` se).
3. Repo ke **Actions** tab mein jao → **"Build Maya APK"** workflow
   → **Run workflow** dabao. (Push karne par bhi khud chal jata hai.)
4. Build complete hone par usi run ke page par neeche **Artifacts** mein
   **maya-debug-apk** milega — download karo, andar `app-debug.apk` hoga.
5. APK ko phone par install karo (pehli baar "unknown sources" allow karna).
6. App kholo → **Settings → Gemini API key** mein apni FREE key daalo
   (https://aistudio.google.com/app/apikey se lo) — key sirf phone par rehti hai.

### Option B — Android Studio se

1. Open the project in **Android Studio** (Hedgehog or newer).
2. Let Gradle sync (needs internet once for dependencies).
3. Get a **FREE Gemini API key** at https://aistudio.google.com/app/apikey
   and paste it in the app under **Settings → Gemini API key**.
   The key lives only on your phone (DataStore) — it is never in the code.
4. Run on a real phone (or emulator) and grant Microphone when asked.
5. Build → Build APK(s) for a debug APK you can share.

## What works / what is a placeholder

| Feature | Status |
|---|---|
| Chat with Maya (Gemini 1.5 Flash) | Works, with your own free key |
| Voice in/out (SpeechRecognizer + TTS hi-IN) | Works on device |
| Free 10 min/day voice budget, resets daily | Works (DataStore) |
| Memories auto-save (filtered) + tasks + backup | Works (Room, on-device) |
| Weather card (Open-Meteo, keyless) | Works (online) |
| Open apps / YouTube / WhatsApp via intents | Works |
| Girlfriend mode Friendly / Romantic | Works (prompt-level) |
| Intense (18+) | **Gated placeholder — cannot be enabled yet** |
| Voice picker preview | Plays in phone TTS; Gemini Live voice name stored for Live API |
| Advanced Agentic engine | Not in this free build (getmaya.online) |
| Connectors (Drive, GitHub, …) | **Placeholder UI only — no OAuth** |
| UPI payment / QR | **Placeholder — fake UPI ID** |
| Screenshot (MediaProjection) | **Stub** — needs a capture-permission flow |
| Lock screen (Device Admin) | **Stub** — needs user to enable Device Admin |
| Scan (QR) | Placeholder screen |

## Permissions

Declared (only what the code uses): INTERNET, ACCESS_NETWORK_STATE,
RECORD_AUDIO, CAMERA, READ_MEDIA_IMAGES, READ_MEDIA_AUDIO,
ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION, POST_NOTIFICATIONS,
FOREGROUND_SERVICE, FOREGROUND_SERVICE_MICROPHONE, SYSTEM_ALERT_WINDOW
(optional, floating orb only).

**Not** declared, even though the reference screenshots show them in the
app-info page: call logs, contacts, phone state, SMS, nearby devices.
The app does not read those — if a future feature needs one, add the
permission, the runtime request, and the reason in Settings.

## Project structure

```
settings.gradle.kts / build.gradle.kts / app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/hunterai/maya/
  MainActivity.kt            (NavHost, drawer, bottom nav)
  MayaApp.kt                 (singletons)
  ui/theme/                  (Color, Theme, Neumorphic)
  ui/navigation/AppNav.kt    (routes)
  ui/screens/                (Splash, Home, Chat, Voice, Memory,
                              Settings, SecretSettings, IntenseGate,
                              VoicePicker, VoiceEngine, Connectors,
                              Upgrade, Placeholder)
  viewmodel/MayaViewModel.kt (chat, voice, settings, budget)
  data/                      (Room DB, SettingsStore, MemorySafety,
                              MayaRepository)
  data/network/              (GeminiApi, WeatherApi)
  data/voice/                (SpeechHelper, MayaVoiceService)
  data/freemium/             (FreeLimitManager)
  data/automation/           (AutomationTools)
app/src/main/assets/
  maya_system_prompt.md      (full Maya persona prompt)
  persona_config.json        (voices, engines, modes, safety)
app/src/main/res/values/     (strings.xml, themes.xml)
```

## Persona & voice rules (summary)

Full rules live in `app/src/main/assets/maya_system_prompt.md` and
`persona_config.json`. In short: Hinglish only, never a full English
sentence; Babu by default, Jan when intimate, Janu/Jaaneman/Darling
rarely; "Uff Babu" sigh; "Ho gaya Babu... dekh lo ek baar" / "Ab khush
ho?"; proactive "Chup hi kyun hai Jan? Main yahin hoon."; celebrates
wins, cute apologies, upbeat failures. Conversation Mode = more
emotional/situational. Girlfriend mode turns on when "Male" is selected
in personal settings.

## No secrets

No API keys, passwords, tokens or merchant IDs are in this project.
The Gemini key is entered by the user in Settings and stored only in
the phone's DataStore.

---

## v7 — crash fix + powerful build (2026-11-17)

**The crash, found:** v5 crashed at the end of the splash ("Maya keeps stopping").
Full audit of the startup path (Application, ViewModel init, Room, TTS, Home
composition, voice service) found no fault there. The fault was in
`MainActivity.MayaRoot`: the splash was shown by an early-return branch OUTSIDE
the NavHost, and its `onFinished` called `navController.navigate(HOME)` BEFORE
any NavHost had been composed — so the NavController had NO graph yet, and
`navigate()` throws. Splash rendered fine, then the app died at the exact
moment it should have gone Home. **v7 fix:** the NavHost is ALWAYS composed
(startDestination = splash); the splash is a destination, and its `onFinished`
navigates only after the graph exists. The v6 crash catcher is kept, so if it
ever crashes again the next launch shows the exact stack trace on the
Crash Report screen (Share karo).

**New in v7 (from the HunterIsLive video + getmaya.online study):**
- **Setup screen (first run):** permissions (mic, notifications, battery),
  FREE Gemini key entry with "FREE key banao" link, persona pick. Re-runnable
  from Settings ("Setup dobara chalao").
- **Actions screen:** every real thing Maya can do — YouTube search + open,
  WhatsApp, Instagram, Spotify, Maps, Camera, Gallery, dial, Settings.
  Honest count from `AutomationTools.availableActions()` — no fake "150+".
- **WhatsApp auto-reply:** NotificationListenerService, OFF by default.
  Enable in Settings + system Notification access; replies are short local
  Hinglish templates only — message text never leaves the phone.
- **Face Lock:** biometric / device-credential gate on app launch (BiometricPrompt).
  Always has a fallback — never locks you out.
- **Touch Guard:** lock overlay, long-press to unlock for the session.
- **Voice Guardian:** voice sessions only answer after the wake word "Maya".
- **Appearance:** accent picker — Pink / Blue / Purple (drives Material3 primary).
- **Backup:** chat + memories + tasks as one JSON file in Downloads.
- **Crash catcher kept** (v6) + milestone logging.

**About the 10 MB APK:** a debug APK is ~10 MB — normal. Debug builds carry
extra tooling; the real Maya is 84 MB because it bundles voices, models and
data. Size was never the problem; the crash was. (Release builds are smaller
still; the GitHub workflow builds `assembleDebug`.)

**Honest limits (unchanged):** on-phone voice is device TTS (Hindi hi-IN),
not the video's Gemini Live voice — Gemini Live voice names are stored for
the Live API call only. Full phone control needs the real Maya backend;
this source does what Android allows a normal app to do with public intents.
No fake location, no virtual Android, no mobile number ever asked.

**v7 fix (2026-11-17 ~08:47 PKT):** GitHub build failed on
`androidx.biometric:biometric:1.2.0` — that version was never released
(only 1.2.0-alpha01..05 exist). Fixed to the latest stable `1.1.0`.

**v7 fix #2 (2026-11-17 ~08:56 PKT):** GitHub build #15 failed at
`:app:compileDebugKotlin` (59s, exit code 1). The full log is locked
behind GitHub sign-in (public API/browser cannot read it), so the cause
was found by auditing the v7 code: `MainActivity.kt` used
`Arrangement.Center` in the Face Lock screen but never imported
`androidx.compose.foundation.layout.Arrangement` — the only file with
that missing import (all other files import it). Fixed by adding the
import. Every other v7 symbol was verified present (AutomationTools API,
ChatDao.getRecent, MayaColors.Success, CrashLog, AppNav routes).

**v7 fix #3 (2026-11-17 ~09:10 PKT):** GitHub build #19 failed at
`:app:compileDebugKotlin` with one error, visible in ayan's log
screenshot: `WhatsAppAutoReplyService.kt:52:32` — "Only safe (?.) or
non-null asserted (!!.) calls are allowed on a nullable receiver of
type 'android.app.PendingIntent?'". `NotificationCompat.Action.actionIntent`
is nullable, so `.send(...)` had to become `?.send(...)`. Fixed.
(The Kotlin daemon GC warnings in the same log are harmless noise.)

**v8 build 8 (2026-11-17 ~09:45 PKT) — Auto voice + key notes:**
- Auto voice (default ON): app khulte hi Maya khud sunna shuru kar deti hai —
  SettingsStore `autoVoice` (default true) + ViewModel guard `autoVoiceStarted`
  (once per launch) + HomeScreen `LaunchedEffect(autoVoice)` + Settings toggle
  "Auto voice response". Initial StateFlow value is false deliberately so a
  stored OFF is never overridden by the initial value before DataStore emits.
- versionCode 7 → 8; footers now say build 8.
- KEY RULE (never break): the Gemini key is NEVER hardcoded in source — the repo
  Ayanxd63/Maya2 is PUBLIC, a hardcoded key would leak to everyone and Google
  would disable it. The key lives only in DataStore on the phone, entered by the
  user in Settings. A valid Gemini key starts with "AIza" (from
  aistudio.google.com/apikey); any other format is rejected by Google and the
  app falls back to offline replies. The key must be pasted in the Settings
  field + Save — pasting it in the chat does nothing.
- Preflight re-run for this zip: autoVoice symbols verified in all 4 edited
  files; Compose plugin, biometric 1.1.0, fragment-ktx 1.8.2, launcher icons,
  versionCode 8 all verified; zip name maya-app.zip matches the repo workflow.

**v8 build 9 (2026-11-17 ~09:50 PKT) — "Full best updated version, BILKUL FREE" (from the Maya AI video study):**
- BILKUL FREE: daily voice limit removed (startListening no longer gates on
  freeLimitManager; recordVoiceUsage deleted); Upgrade screen rewritten —
  no licence, no payment, no UPI, no QR; Home + Voice banners say "Free •
  unlimited". The app runs on the user's own FREE Gemini key.
- Home redesign (like the real app): time + user-name greeting ("Good
  evening, Babu"), "1 Energy" pill, anime art centre (splash_art.jpg) with
  a small glowing orb badge (tap = voice), Music/Study/Journal chips,
  Weather/Today/Mood cards, ask bar.
- Floating orb: MayaVoiceService shows a draggable glowing orb overlay
  (SYSTEM_ALERT_WINDOW, style/size from Advanced settings) while a voice
  session runs; tap it to open Maya. isActive flag added for auto-reply.
- Conversation mode: Settings toggle; system prompt adds the
  emotion-adaptive note; after each spoken reply Maya listens again
  (echo-guard waits 800ms after TTS). Stop via mic button / stopListening.
- Skills screen: 6 real skills (Morning Briefing, Study Helper, Music DJ,
  Journal Writer, Reminder, Translator) — Install / Install all / Refresh /
  Run; installed set in DataStore.
- Sub-agents screen: Research Writer / Story Writer / Song List Maker —
  Gemini research → text file in Documents/Maya → "Kholo" (FileProvider,
  "Open with" chooser) / "Share karo". Needs the FREE key.
- Voice Guardian screen: 3-phrase enrolment (SpeechRecognizer confirms each
  phrase), roles Owner/family/friend/guest/blocked, "Test my voice".
  HONEST LIMIT: matching is wake-word based; vendor-grade voice matching
  cannot be cloned — stated in the UI.
- WhatsApp auto-reply v2: Reply OFF / Only while asleep ON / Include groups
  OFF + custom instruction box ("Your words. She follows these exactly.")
  + Message alerts (speaks WhatsApp arrivals only when idle).
- Setup: "Maya ko default assistant banao" (RoleManager ROLE_ASSISTANT).
- Voice picker: Maya tab display names Breezy/Firm/Youthful/Bright/Upbeat/
  Smooth/Clear/Easy-going over the real Gemini voice IDs.
- Advanced settings: orb style (Glowing/Pulse/Minimal) + size, floating
  orb, echo-guard, start on boot (BootReceiver), human-paced typing.
- God Mode (Touch Guard): only your voice ("Maya" bolo) unlocks; Recognise
  my voice toggle; long-press disabled while God Mode is on.
- Maya Home screen: real WiFi scan + honest empty state (needs the ESP32
  Home Box hardware); "Add a device someone shared" note.
- User name setting (Settings → Tumhara naam) feeds the Home greeting.
- versionCode 8 → 9; footers say build 9.
- Preflight re-run for this zip: all 5 new routes have NavHost entries;
  all 22 new ViewModel functions exist; service companion vars exist;
  Compose plugin, biometric 1.1.0, fragment-ktx 1.8.2, launcher icons,
  FileProvider + file_paths.xml, BootReceiver + permissions, orb drawable,
  splash art all verified; zip name maya-app.zip matches the repo workflow.
