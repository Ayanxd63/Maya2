package com.hunterai.maya.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Sub-agents — custom models and background agents (v8).
 * A sub-agent runs in the background: it researches with Gemini and writes
 * a text file into Documents/Maya, then offers "Open with" (the file opens
 * in any text app) — exactly the demo flow from the real app.
 * Needs the FREE Gemini key; without it the agent says so and stops.
 */
data class SubAgentDef(val name: String, val subtitle: String, val topicHint: String)

private val subAgents = listOf(
    SubAgentDef("Research Writer", "Kisi bhi topic pe research note banao", "Topic likho, jaise: Black holes"),
    SubAgentDef("Story Writer", "Ek chhoti kahani likho", "Kahani kis pe ho?"),
    SubAgentDef("Song List Maker", "Mood ke hisaab se gaano ki list banao", "Mood likho, jaise: sad")
)

@Composable
fun SubAgentsScreen(viewModel: MayaViewModel, navController: NavController) {
    val context = LocalContext.current
    var topic by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    var lastUri by remember { mutableStateOf<Uri?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Sub-agents", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Text(
                "Custom models and background agents",
                fontSize = 14.sp,
                color = MayaColors.TextMuted
            )
            Spacer(Modifier.height(8.dp))
            NeumorphicCard(modifier = Modifier.fillMaxWidth(), backgroundColor = MayaColors.SurfaceBlue) {
                Text(
                    "Sub-agent background mein kaam karta hai — research karke ek text file " +
                        "Documents/Maya mein save karta hai. Phir use kisi bhi app se kholo.",
                    fontSize = 13.sp,
                    color = MayaColors.TextBody
                )
            }
        }
        subAgents.forEach { agent ->
            item {
                NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text(agent.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                        Text(agent.subtitle, fontSize = 13.sp, color = MayaColors.TextBody)
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = topic,
                onValueChange = { topic = it },
                label = { Text("Topic likho...") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    running = true
                    result = ""
                    lastUri = null
                    viewModel.runSubAgent(topic) { ok, msg, uri ->
                        running = false
                        result = msg
                        lastUri = uri
                    }
                },
                enabled = !running,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MayaColors.PinkDeep)
            ) {
                Text(if (running) "Sub-agent kaam kar raha hai..." else "Sub-agent chalao")
            }
        }
        if (result.isNotBlank()) {
            item {
                NeumorphicCard(modifier = Modifier.fillMaxWidth(), backgroundColor = MayaColors.SurfaceBlue) {
                    Column {
                        Text(result, fontSize = 14.sp, color = MayaColors.TextDark)
                        if (lastUri != null) {
                            Spacer(Modifier.height(10.dp))
                            Row {
                                Button(onClick = {
                                    val view = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(lastUri, "text/plain")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(view, "Open with"))
                                }) { Text("Kholo") }
                                Button(
                                    onClick = {
                                        val share = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_STREAM, lastUri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(share, "Share karo"))
                                    },
                                    modifier = Modifier.padding(start = 10.dp)
                                ) { Text("Share karo") }
                            }
                        }
                    }
                }
            }
        }
    }
}
