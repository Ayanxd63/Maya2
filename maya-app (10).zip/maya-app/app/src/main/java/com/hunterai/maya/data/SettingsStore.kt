package com.hunterai.maya.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "maya_settings")

/**
 * Settings storage (DataStore Preferences).
 * The Gemini API key lives ONLY here, on the user's own phone, entered by
 * the user in Settings. It is never hardcoded, never logged, never synced.
 */
class SettingsStore(private val context: Context) {

    companion object {
        private val KEY_API_KEY = stringPreferencesKey("gemini_api_key")
        private val KEY_PERSONA = stringPreferencesKey("persona")
        private val KEY_GENDER = stringPreferencesKey("gender")
        private val KEY_LANGUAGE = stringPreferencesKey("language")
        private val KEY_AUTO_SAVE = booleanPreferencesKey("auto_save_memory")
        private val KEY_VOICE_PITCH = floatPreferencesKey("voice_pitch")
        private val KEY_VOICE_RATE = floatPreferencesKey("voice_rate")
        private val KEY_PREMIUM = booleanPreferencesKey("is_premium")
        private val KEY_GIRLFRIEND_MODE = stringPreferencesKey("girlfriend_mode")
        private val KEY_VOICE_NAME = stringPreferencesKey("voice_name")
        private val KEY_VOICE_ENGINE = stringPreferencesKey("voice_engine")
        private val KEY_SETUP_DONE = booleanPreferencesKey("setup_done")
        private val KEY_ACCENT = stringPreferencesKey("accent")
        private val KEY_FACE_LOCK = booleanPreferencesKey("face_lock")
        private val KEY_TOUCH_GUARD = booleanPreferencesKey("touch_guard")
        private val KEY_VOICE_GUARDIAN = booleanPreferencesKey("voice_guardian")
        private val KEY_WHATSAPP_AUTO_REPLY = booleanPreferencesKey("whatsapp_auto_reply")
        private val KEY_AUTO_VOICE = booleanPreferencesKey("auto_voice")
        // ---- v8 keys ----
        private val KEY_USER_NAME = stringPreferencesKey("user_name")
        private val KEY_CONVERSATION_MODE = booleanPreferencesKey("conversation_mode")
        private val KEY_MESSAGE_ALERTS = booleanPreferencesKey("message_alerts")
        private val KEY_INSTALLED_SKILLS = stringSetPreferencesKey("installed_skills")
        private val KEY_VG_ENROLLED = booleanPreferencesKey("vg_enrolled")
        private val KEY_VG_ROLE = stringPreferencesKey("vg_role")
        private val KEY_VG_PHRASES = stringSetPreferencesKey("vg_phrases")
        private val KEY_WA_ONLY_ASLEEP = booleanPreferencesKey("wa_only_asleep")
        private val KEY_WA_INCLUDE_GROUPS = booleanPreferencesKey("wa_include_groups")
        private val KEY_WA_INSTRUCTION = stringPreferencesKey("wa_instruction")
        private val KEY_FLOATING_ORB = booleanPreferencesKey("floating_orb")
        private val KEY_ORB_STYLE = stringPreferencesKey("orb_style")
        private val KEY_ORB_SIZE = stringPreferencesKey("orb_size")
        private val KEY_ECHO_GUARD = booleanPreferencesKey("echo_guard")
        private val KEY_START_ON_BOOT = booleanPreferencesKey("start_on_boot")
        private val KEY_HUMAN_TYPING = booleanPreferencesKey("human_typing")
        private val KEY_GOD_MODE = booleanPreferencesKey("god_mode")
        private val KEY_RECOGNIZE_VOICE = booleanPreferencesKey("recognize_voice")

        const val PERSONA_MAYA = "Maya"
        const val PERSONA_FRIDAY = "Friday"
        const val PERSONA_VENOM = "Venom"
        const val PERSONA_JARVIS = "Jarvis"

        const val MODE_FRIENDLY = "Friendly"
        const val MODE_ROMANTIC = "Romantic"
        const val MODE_INTENSE = "Intense"

        const val ENGINE_SWIFT = "Swift"
        const val ENGINE_SOUL = "Soul"
        const val ENGINE_MIND = "Mind"
    }

    val apiKey: Flow<String> = context.settingsDataStore.data.map { it[KEY_API_KEY] ?: "" }
    val persona: Flow<String> = context.settingsDataStore.data.map { it[KEY_PERSONA] ?: PERSONA_MAYA }
    val gender: Flow<String> = context.settingsDataStore.data.map { it[KEY_GENDER] ?: "Prefer not to say" }
    val language: Flow<String> = context.settingsDataStore.data.map { it[KEY_LANGUAGE] ?: "Hindi / Urdu (Hinglish)" }
    val autoSaveMemory: Flow<Boolean> = context.settingsDataStore.data.map { it[KEY_AUTO_SAVE] ?: true }
    val voicePitch: Flow<Float> = context.settingsDataStore.data.map { it[KEY_VOICE_PITCH] ?: 1.1f }
    val voiceRate: Flow<Float> = context.settingsDataStore.data.map { it[KEY_VOICE_RATE] ?: 0.95f }
    val isPremium: Flow<Boolean> = context.settingsDataStore.data.map { it[KEY_PREMIUM] ?: false }

    /** Girlfriend mode — default Friendly. Applies on next app start. */
    val girlfriendMode: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_GIRLFRIEND_MODE] ?: MODE_FRIENDLY }

    /** Selected Gemini Live API voice name (e.g. "Aoede"). */
    val voiceName: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_VOICE_NAME] ?: "Aoede" }

    /** Voice engine — Swift (default), Soul or Mind. */
    val voiceEngine: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_VOICE_ENGINE] ?: ENGINE_SWIFT }

    /** First-run setup done (permissions + key + persona). Default false. */
    val setupDone: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_SETUP_DONE] ?: false }

    /** Appearance accent — "Pink" (default), "Blue" or "Purple". */
    val accent: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_ACCENT] ?: "Pink" }

    /** Face Lock — biometric / device-credential gate on app launch. Default off. */
    val faceLock: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_FACE_LOCK] ?: false }

    /** Touch Guard — lock overlay, long-press to unlock. Default off. */
    val touchGuard: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_TOUCH_GUARD] ?: false }

    /** Voice Guardian — voice sessions only answer after the wake word "Maya". Default off. */
    val voiceGuardian: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_VOICE_GUARDIAN] ?: false }

    /** WhatsApp auto-reply — OFF by default; needs Notification access in system settings. */
    val whatsappAutoReply: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_WHATSAPP_AUTO_REPLY] ?: false }

    /** Auto voice — app khulte hi Maya khud sunna shuru kar de. Default ON. */
    val autoVoice: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_AUTO_VOICE] ?: true }

    // ================= v8 =================

    /** The user's name, used in greetings ("Good evening, Babu"). Default "Babu". */
    val userName: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_USER_NAME] ?: "Babu" }

    /** Conversation mode — "Talk to her, rather than ask her". Maya only. Default off. */
    val conversationMode: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_CONVERSATION_MODE] ?: false }

    /** Message alerts — Maya speaks WhatsApp arrivals when idle. Default off. */
    val messageAlerts: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_MESSAGE_ALERTS] ?: false }

    /** Installed skills (Skill store). */
    val installedSkills: Flow<Set<String>> =
        context.settingsDataStore.data.map { it[KEY_INSTALLED_SKILLS] ?: emptySet() }

    /** Voice Guardian — owner's voice enrolled (3 phrases). Default false. */
    val vgEnrolled: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_VG_ENROLLED] ?: false }

    /** Voice Guardian — enrolled role: Owner / family / friend / guest / blocked. */
    val vgRole: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_VG_ROLE] ?: "Owner" }

    /** Voice Guardian — enrolled phrase indices ("0", "1", "2"). */
    val vgPhrases: Flow<Set<String>> =
        context.settingsDataStore.data.map { it[KEY_VG_PHRASES] ?: emptySet() }

    /** WhatsApp auto-reply — only while Maya is asleep. Default ON (like the real app). */
    val waOnlyAsleep: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_WA_ONLY_ASLEEP] ?: true }

    /** WhatsApp auto-reply — include groups. Default OFF. */
    val waIncludeGroups: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_WA_INCLUDE_GROUPS] ?: false }

    /** WhatsApp auto-reply — the user's own words. Default is the text seen in the real app. */
    val waInstruction: Flow<String> =
        context.settingsDataStore.data.map {
            it[KEY_WA_INSTRUCTION]
                ?: "Politely say I am busy right now and will reply myself soon. Keep it short, warm and friendly. Reply in the same language they wrote in."
        }

    /** Floating orb over the home screen. Default ON. */
    val floatingOrb: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_FLOATING_ORB] ?: true }

    /** Orb style — Glowing / Pulse / Minimal. Default Glowing. */
    val orbStyle: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_ORB_STYLE] ?: "Glowing" }

    /** Orb size — Small / Medium / Large. Default Medium. */
    val orbSize: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_ORB_SIZE] ?: "Medium" }

    /** Echo-guard — wait for TTS to fully finish before listening again. Default ON. */
    val echoGuard: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_ECHO_GUARD] ?: true }

    /** Start on boot — show the floating orb after a restart. Default OFF. */
    val startOnBoot: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_START_ON_BOOT] ?: false }

    /** Human-paced typing — Maya's chat replies appear with a small delay. Default OFF. */
    val humanTyping: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_HUMAN_TYPING] ?: false }

    /** Touch Guard God Mode — only your voice can unlock. Default OFF. */
    val godMode: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_GOD_MODE] ?: false }

    /** Touch Guard — recognise my voice. Default ON (like the real app). */
    val recognizeVoice: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_RECOGNIZE_VOICE] ?: true }

    suspend fun setApiKey(value: String) {
        context.settingsDataStore.edit { it[KEY_API_KEY] = value }
    }

    suspend fun setPersona(value: String) {
        context.settingsDataStore.edit { it[KEY_PERSONA] = value }
    }

    suspend fun setGender(value: String) {
        context.settingsDataStore.edit { it[KEY_GENDER] = value }
    }

    suspend fun setLanguage(value: String) {
        context.settingsDataStore.edit { it[KEY_LANGUAGE] = value }
    }

    suspend fun setAutoSaveMemory(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_AUTO_SAVE] = value }
    }

    suspend fun setVoicePitch(value: Float) {
        context.settingsDataStore.edit { it[KEY_VOICE_PITCH] = value }
    }

    suspend fun setVoiceRate(value: Float) {
        context.settingsDataStore.edit { it[KEY_VOICE_RATE] = value }
    }

    suspend fun setPremium(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_PREMIUM] = value }
    }

    suspend fun setGirlfriendMode(value: String) {
        context.settingsDataStore.edit { it[KEY_GIRLFRIEND_MODE] = value }
    }

    suspend fun setVoiceName(value: String) {
        context.settingsDataStore.edit { it[KEY_VOICE_NAME] = value }
    }

    suspend fun setVoiceEngine(value: String) {
        context.settingsDataStore.edit { it[KEY_VOICE_ENGINE] = value }
    }

    suspend fun setSetupDone(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_SETUP_DONE] = value }
    }

    suspend fun setAccent(value: String) {
        context.settingsDataStore.edit { it[KEY_ACCENT] = value }
    }

    suspend fun setFaceLock(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_FACE_LOCK] = value }
    }

    suspend fun setTouchGuard(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_TOUCH_GUARD] = value }
    }

    suspend fun setVoiceGuardian(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_VOICE_GUARDIAN] = value }
    }

    suspend fun setWhatsappAutoReply(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_WHATSAPP_AUTO_REPLY] = value }
    }

    suspend fun setAutoVoice(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_AUTO_VOICE] = value }
    }

    // ---- v8 setters ----

    suspend fun setUserName(value: String) {
        context.settingsDataStore.edit { it[KEY_USER_NAME] = value }
    }

    suspend fun setConversationMode(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_CONVERSATION_MODE] = value }
    }

    suspend fun setMessageAlerts(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_MESSAGE_ALERTS] = value }
    }

    suspend fun setInstalledSkills(value: Set<String>) {
        context.settingsDataStore.edit { it[KEY_INSTALLED_SKILLS] = value }
    }

    suspend fun setVgEnrolled(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_VG_ENROLLED] = value }
    }

    suspend fun setVgRole(value: String) {
        context.settingsDataStore.edit { it[KEY_VG_ROLE] = value }
    }

    suspend fun setVgPhrases(value: Set<String>) {
        context.settingsDataStore.edit { it[KEY_VG_PHRASES] = value }
    }

    suspend fun setWaOnlyAsleep(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_WA_ONLY_ASLEEP] = value }
    }

    suspend fun setWaIncludeGroups(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_WA_INCLUDE_GROUPS] = value }
    }

    suspend fun setWaInstruction(value: String) {
        context.settingsDataStore.edit { it[KEY_WA_INSTRUCTION] = value }
    }

    suspend fun setFloatingOrb(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_FLOATING_ORB] = value }
    }

    suspend fun setOrbStyle(value: String) {
        context.settingsDataStore.edit { it[KEY_ORB_STYLE] = value }
    }

    suspend fun setOrbSize(value: String) {
        context.settingsDataStore.edit { it[KEY_ORB_SIZE] = value }
    }

    suspend fun setEchoGuard(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_ECHO_GUARD] = value }
    }

    suspend fun setStartOnBoot(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_START_ON_BOOT] = value }
    }

    suspend fun setHumanTyping(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_HUMAN_TYPING] = value }
    }

    suspend fun setGodMode(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_GOD_MODE] = value }
    }

    suspend fun setRecognizeVoice(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_RECOGNIZE_VOICE] = value }
    }
}
