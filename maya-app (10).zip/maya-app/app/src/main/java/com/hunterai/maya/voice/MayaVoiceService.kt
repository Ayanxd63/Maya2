package com.hunterai.maya.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.hunterai.maya.MainActivity
import com.hunterai.maya.R
import com.hunterai.maya.data.SettingsStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * Foreground service that keeps a voice session alive while Maya listens.
 * Declared in AndroidManifest with foregroundServiceType="microphone".
 * The ViewModel starts/stops it around a voice session; it does no
 * recording by itself — SpeechHelper does the listening.
 *
 * v8: isActive (so WhatsApp auto-reply / message alerts know when Maya is
 * awake) and the floating orb — a glowing orb over the home screen while a
 * voice session runs. The orb only appears when the user enabled it in
 * Advanced settings AND granted the overlay permission. Tap it to open
 * Maya; drag it to move it.
 */
class MayaVoiceService : Service() {

    private var windowManager: WindowManager? = null
    private var orbView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        isActive = true
        startForeground(NOTIFICATION_ID, buildNotification())
        showOrb()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        isActive = false
        removeOrb()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val channelId = "maya_voice"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Maya voice",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Maya sun rahi hai" }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Maya sun rahi hai…")
            .setContentText("Babu, bolo — main yahin hoon.")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .build()
    }

    /** Floating orb (v8). Best-effort: never crash the voice session over it. */
    private fun showOrb() {
        try {
            if (orbView != null) return
            val show = runBlocking { SettingsStore(applicationContext).floatingOrb.first() }
            if (!show) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return
            val sizeName = runBlocking { SettingsStore(applicationContext).orbSize.first() }
            val dp = when (sizeName) { "Small" -> 72; "Large" -> 128; else -> 96 }
            val px = (dp * resources.displayMetrics.density).toInt()
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            windowManager = wm
            val view = View(this).apply { setBackgroundResource(R.drawable.orb_floating) }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            val params = WindowManager.LayoutParams(
                px, px, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 100
                y = 400
            }
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            view.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = params.x
                        startY = params.y
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt()
                        val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                        params.x = startX + dx
                        params.y = startY + dy
                        try {
                            wm.updateViewLayout(view, params)
                        } catch (e: Exception) {
                            // Best effort only.
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            val open = Intent(this, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            }
                            try {
                                startActivity(open)
                            } catch (e: Exception) {
                                // Best effort only.
                            }
                        }
                        true
                    }
                    else -> false
                }
            }
            orbView = view
            wm.addView(view, params)
        } catch (e: Exception) {
            // Overlay is best-effort — never crash the voice session over it.
        }
    }

    private fun removeOrb() {
        try {
            orbView?.let { windowManager?.removeView(it) }
        } catch (e: Exception) {
            // Best effort only.
        }
        orbView = null
        windowManager = null
    }

    companion object {
        const val NOTIFICATION_ID = 1001

        /** True while a voice session is running. Used by auto-reply / alerts. */
        @Volatile
        var isActive: Boolean = false

        fun start(context: Context) {
            val intent = Intent(context, MayaVoiceService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, MayaVoiceService::class.java))
        }
    }
}
