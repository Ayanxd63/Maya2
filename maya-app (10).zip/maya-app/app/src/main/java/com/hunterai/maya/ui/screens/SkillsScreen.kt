package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Skills — the Skill store (v8).
 * Each skill is a real local behaviour (see MayaViewModel.runSkill): nothing
 * here is a fake button. Install toggles the skill on; Run executes it.
 */
data class SkillDef(
    val id: String,
    val title: String,
    val subtitle: String,
    val needsArg: Boolean = false,
    val argHint: String = ""
)

private val skillCatalogue = listOf(
    SkillDef("morning-briefing", "Morning Briefing", "Mausam, aaj ki date aur tasks ek saath suno"),
    SkillDef("study-helper", "Study Helper", "Koi bhi topic Hinglish mein samjhao", needsArg = true, argHint = "Topic likho, jaise: photosynthesis"),
    SkillDef("music-dj", "Music DJ", "Pasandida gaana chala do"),
    SkillDef("journal", "Journal Writer", "Boli hui baat Yaadein mein save karo", needsArg = true, argHint = "Journal note likho..."),
    SkillDef("reminder", "Reminder", "Kuch yaad rakhne ke liye save karo", needsArg = true, argHint = "Kya yaad rakhna hai?"),
    SkillDef("translator", "Translator", "Hinglish ↔ English translate karo", needsArg = true, argHint = "Text likho...")
)

@Composable
fun SkillsScreen(viewModel: MayaViewModel, navController: NavController) {
    val installed by viewModel.installedSkills.collectAsState()
    var result by remember { mutableStateOf("") }
    val args = remember { mutableStateMapOf<String, String>() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Skills", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Text(
                "Installed playbooks and the skill store",
                fontSize = 14.sp,
                color = MayaColors.TextMuted
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { viewModel.installAllSkills(skillCatalogue.map { it.id }) }) {
                    Text("Install all")
                }
                TextButton(onClick = { /* re-reads the installed set from DataStore */ }) {
                    Text("Refresh", color = MayaColors.Primary)
                }
                Text(
                    "${installed.size} / ${skillCatalogue.size} installed",
                    fontSize = 13.sp,
                    color = MayaColors.TextMuted,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
        items(skillCatalogue) { skill ->
            val isInstalled = skill.id in installed
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(skill.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Text(skill.subtitle, fontSize = 13.sp, color = MayaColors.TextBody)
                    Spacer(Modifier.height(10.dp))
                    if (isInstalled && skill.needsArg) {
                        OutlinedTextField(
                            value = args[skill.id] ?: "",
                            onValueChange = { args[skill.id] = it },
                            label = { Text(skill.argHint) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    Row {
                        Button(
                            onClick = {
                                if (isInstalled) viewModel.uninstallSkill(skill.id)
                                else viewModel.installSkill(skill.id)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isInstalled) MayaColors.SurfaceBlue else MayaColors.Primary,
                                contentColor = MayaColors.TextDark
                            )
                        ) {
                            Text(if (isInstalled) "Installed ✓" else "Install")
                        }
                        if (isInstalled) {
                            Button(
                                onClick = {
                                    viewModel.runSkill(skill.id, args[skill.id] ?: "") { result = it }
                                },
                                modifier = Modifier.padding(start = 10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MayaColors.PinkDeep)
                            ) {
                                Text("Run")
                            }
                        }
                    }
                }
            }
        }
        if (result.isNotBlank()) {
            item {
                NeumorphicCard(modifier = Modifier.fillMaxWidth(), backgroundColor = MayaColors.SurfaceBlue) {
                    Text(result, fontSize = 14.sp, color = MayaColors.TextDark)
                }
            }
        }
    }
}
