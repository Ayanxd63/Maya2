package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Upgrade — v8: BILKUL FREE.
 * No licence, no payment, no UPI, no daily voice limit. The app runs on the
 * user's own FREE Gemini key (aistudio.google.com/apikey), so there is
 * nothing to sell and nothing to buy. This screen only lists what is free.
 */
@Composable
fun UpgradeScreen(viewModel: MayaViewModel, navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("♥", fontSize = 52.sp, color = MayaColors.PinkDeep)
        Text(
            "Sab kuch FREE hai, Babu!",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MayaColors.TextDark,
            textAlign = TextAlign.Center
        )
        Text(
            "Koi licence nahi, koi payment nahi, koi time limit nahi. " +
                "Ye app tumhari apni FREE Gemini key pe chalti hai — jo chaaho, jitna chaaho, bolo ♥",
            fontSize = 15.sp,
            color = MayaColors.TextBody,
            textAlign = TextAlign.Center
        )

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureRow("Unlimited voice baat — roz, kabhi bhi, koi limit nahi")
                FeatureRow("Conversation Mode — baat karte raho, Maya jawab deti rahegi")
                FeatureRow("Skills aur Sub-agents — sab free, sab chalte hain")
                FeatureRow("WhatsApp auto-reply aur Message alerts")
                FeatureRow("Voice Guardian, Face Lock, Touch Guard")
                FeatureRow("Yaadein backup — kabhi kuch bhoolti nahi")
                FeatureRow("No ads, no payment, no licence")
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth(), backgroundColor = MayaColors.SurfaceBlue) {
            Column {
                Text(
                    "Ek hi cheez chahiye — FREE Gemini key",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MayaColors.TextDark
                )
                Text(
                    "Settings → Gemini API key mein apni FREE key daal do " +
                        "(aistudio.google.com/apikey → Create API key). " +
                        "Key sirf tumhare phone pe rehti hai, kahin nahi jati. " +
                        "Key ke bina bhi Maya offline pyaar se jawab deti hai.",
                    fontSize = 13.sp,
                    color = MayaColors.TextBody
                )
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun FeatureRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Check, contentDescription = null, tint = MayaColors.Success, modifier = Modifier.size(20.dp))
        Text(text, fontSize = 15.sp, color = MayaColors.TextDark, modifier = Modifier.padding(start = 10.dp))
    }
}
