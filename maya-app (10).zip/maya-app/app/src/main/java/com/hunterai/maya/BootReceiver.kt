package com.hunterai.maya

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hunterai.maya.data.SettingsStore
import com.hunterai.maya.voice.MayaVoiceService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * Start on boot (v8): if the user enabled it in Advanced settings, show the
 * floating orb again after a restart by starting the voice service.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        try {
            val startOnBoot = runBlocking { SettingsStore(context).startOnBoot.first() }
            if (startOnBoot) MayaVoiceService.start(context)
        } catch (e: Exception) {
            // Best effort only — never crash on boot.
        }
    }
}
