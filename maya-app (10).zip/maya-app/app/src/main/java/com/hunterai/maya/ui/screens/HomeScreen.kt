package com.hunterai.maya.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.R
import com.hunterai.maya.data.CrashLog
import com.hunterai.maya.ui.navigation.AppNav
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.ui.theme.NeumorphicChip
import com.hunterai.maya.viewmodel.MayaViewModel
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Home dashboard — v8 redesign, like the real Maya Home:
 * time + name greeting, "1 Energy" pill, anime art centre (splash art),
 * glowing orb badge on the art (tap = voice), Music / Study / Journal chips,
 * Weather / Today / Mood cards, and the ask bar. BILKUL FREE — no minutes.
 */
@Composable
fun HomeScreen(viewModel: MayaViewModel, navController: NavController) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { CrashLog.append(context, "Home composed") }
    val weather by viewModel.weather.collectAsState()
    val mood by viewModel.currentMood.collectAsState()
    val userName by viewModel.userName.collectAsState()
    // Auto voice (default ON): app khulte hi Maya khud sunna shuru kar de —
    // mic dabane ki zaroorat nahi. Fires once per app launch only.
    val autoVoice by viewModel.autoVoice.collectAsState()
    LaunchedEffect(autoVoice) {
        if (autoVoice && !viewModel.autoVoiceStarted) {
            viewModel.autoVoiceStarted = true
            viewModel.startListening()
        }
    }

    val hour = LocalTime.now().hour
    // Two-line greeting: time-of-day line + the user's name (like "Good evening, Hunter").
    val (greetLine1, greetLine2) = when {
        hour in 0..4 -> "Abhi tak jaag rahe ho," to userName
        hour in 5..11 -> "Good morning," to userName
        hour in 12..16 -> "Kaise ho," to userName
        hour in 17..20 -> "Good evening," to userName
        else -> "Abhi tak jaag rahe ho," to userName
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ---- Free-mode banner — v8: BILKUL FREE, no minutes, no upgrade ----
        NeumorphicCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = MayaColors.SurfaceBlue
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Lock,
                    contentDescription = null,
                    tint = MayaColors.Primary,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Free mode • bilkul free",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MayaColors.TextDark
                    )
                    Text(
                        "Sab kuch free hai, Babu — koi limit nahi, koi payment nahi ♥",
                        fontSize = 13.sp,
                        color = MayaColors.TextBody
                    )
                }
            }
        }

        // ---- Greeting ----
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    greetLine1,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MayaColors.TextDark
                )
                Text(
                    greetLine2,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold,
                    color = MayaColors.TextDark
                )
            }
            NeumorphicChip {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⚡", fontSize = 16.sp)
                    Spacer(Modifier.width(6.dp))
                    Column {
                        Text("1", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                        Text("Energy", fontSize = 11.sp, color = MayaColors.TextMuted)
                    }
                }
            }
        }

        // ---- Anime art centre (v8) — the real Maya Home has the girl in the
        // middle; the glowing orb sits on it (tap = voice screen). ----
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .clip(RoundedCornerShape(28.dp))
                .clickable { navController.navigate(AppNav.VOICE) },
            contentAlignment = Alignment.BottomEnd
        ) {
            Image(
                painter = painterResource(id = R.drawable.splash_art),
                contentDescription = "Maya",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(modifier = Modifier.padding(10.dp)) {
                NeuralOrb(size = 72.dp)
            }
        }

        // ---- Quick cards — Music / Study / Journal (like the real app) ----
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            QuickCard(
                title = "Music",
                icon = Icons.Default.MusicNote,
                modifier = Modifier.weight(1f)
            ) { viewModel.playFavoriteSong() }
            QuickCard(
                title = "Study",
                icon = Icons.Default.Book,
                modifier = Modifier.weight(1f)
            ) { navController.navigate(AppNav.CHAT) }
            QuickCard(
                title = "Journal",
                icon = Icons.Default.Edit,
                modifier = Modifier.weight(1f)
            ) { navController.navigate(AppNav.MEMORY) }
        }

        // ---- Info cards — Weather / Today / Mood ----
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            InfoCard(
                label = "Weather",
                icon = Icons.Default.WbSunny,
                big = weather?.temperature ?: "12°",
                small = weather?.condition ?: "Clear",
                extra = weather?.humidity?.let { "$it%" } ?: "52%",
                modifier = Modifier.weight(1f)
            )
            InfoCard(
                label = "Today",
                icon = Icons.Default.CalendarToday,
                big = LocalDate.now().dayOfMonth.toString(),
                small = LocalDate.now().format(
                    DateTimeFormatter.ofPattern("EEE, MMM", Locale("en"))
                ),
                extra = null,
                modifier = Modifier.weight(1f)
            )
            InfoCard(
                label = "Mood",
                icon = Icons.Default.Favorite,
                big = mood,
                small = "Sab badhiya",
                extra = null,
                modifier = Modifier.weight(1f)
            )
        }

        // ---- Ask bar (like the reference: "Maya se kuch bhi poochho...") ----
        NeumorphicCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .clickable { navController.navigate(AppNav.CHAT) },
            cornerRadius = 28.dp
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.AttachFile,
                    contentDescription = null,
                    tint = MayaColors.TextMuted
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Maya se kuch bhi poochho...",
                    fontSize = 15.sp,
                    color = MayaColors.TextMuted,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MayaColors.Primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Send,
                        contentDescription = "Bhejo",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

/** Pulsing glowing orb — the neural-ring centrepiece. Size is adjustable. */
@Composable
fun NeuralOrb(size: androidx.compose.ui.unit.Dp = 190.dp) {
    val transition = rememberInfiniteTransition(label = "orb-pulse")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb-scale"
    )
    val glow by transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb-glow"
    )

    Box(contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(size)
                .scale(scale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            MayaColors.OrbGlow.copy(alpha = 0.35f * glow),
                            Color.Transparent
                        )
                    )
                )
        )
        Box(
            modifier = Modifier
                .size(size * 0.63f)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(MayaColors.OrbCore, MayaColors.OrbRing, MayaColors.OrbGlow)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text("✦", fontSize = (size.value * 0.21f).sp, color = Color.White)
        }
    }
}

@Composable
private fun QuickCard(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    NeumorphicCard(
        modifier = modifier.clickable { onClick() },
        cornerRadius = 20.dp
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = title, tint = MayaColors.Primary)
            Spacer(Modifier.width(8.dp))
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
        }
    }
}

@Composable
private fun InfoCard(
    label: String,
    icon: ImageVector,
    big: String,
    small: String,
    extra: String?,
    modifier: Modifier = Modifier
) {
    NeumorphicCard(modifier = modifier, cornerRadius = 20.dp) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = label, tint = MayaColors.Primary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(label, fontSize = 13.sp, color = MayaColors.TextMuted)
            }
            Spacer(Modifier.height(8.dp))
            Text(big, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Text(small, fontSize = 13.sp, color = MayaColors.TextBody)
            if (extra != null) {
                Text(extra, fontSize = 12.sp, color = MayaColors.TextMuted)
            }
        }
    }
}
