package com.hunterai.maya.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.viewmodel.MayaViewModel
import com.hunterai.maya.viewmodel.VoiceState

/**
 * Voice / Conversation Mode — the big mic screen.
 * Orb states: idle (soft pulse) / listening (green, fast pulse) /
 * thinking (amber) / speaking (blue). v8: BILKUL FREE — no daily voice
 * limit any more; Conversation mode keeps the chat going.
 */
@Composable
fun VoiceScreen(viewModel: MayaViewModel, navController: NavController) {
    val voiceState by viewModel.voiceState.collectAsState()
    val lastHeard by viewModel.lastHeard.collectAsState()
    val lastReply by viewModel.lastReply.collectAsState()
    val conversationMode by viewModel.conversationMode.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                when (voiceState) {
                    VoiceState.IDLE -> "Babu, bolo — main sun rahi hoon ♥"
                    VoiceState.LISTENING -> "Sun rahi hoon, Babu..."
                    VoiceState.THINKING -> "Soch rahi hoon..."
                    VoiceState.SPEAKING -> "Maya bol rahi hai..."
                },
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MayaColors.TextDark,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (conversationMode) "Conversation mode ON • baat karte raho, Babu ♥"
                else "Free • unlimited, Babu ♥",
                fontSize = 14.sp,
                color = MayaColors.TextMuted
            )
        }

        // Orb — colour + pulse follow the state
        VoiceOrb(state = voiceState)

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (lastHeard.isNotBlank()) {
                Text(
                    "Tumne kaha: \"$lastHeard\"",
                    fontSize = 14.sp,
                    color = MayaColors.TextMuted,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(6.dp))
            }
            if (lastReply.isNotBlank()) {
                Text(
                    lastReply,
                    fontSize = 16.sp,
                    color = MayaColors.TextDark,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
            }

            IconButton(
                onClick = {
                    if (voiceState == VoiceState.LISTENING) viewModel.stopListening()
                    else viewModel.startListening()
                },
                modifier = Modifier
                    .size(84.dp)
                    .clip(CircleShape)
                    .background(
                        if (voiceState == VoiceState.LISTENING) MayaColors.PinkDeep
                        else MayaColors.Primary
                    )
            ) {
                Icon(
                    if (voiceState == VoiceState.LISTENING) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Mic",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Mic dabao aur bolo, Babu",
                fontSize = 13.sp,
                color = MayaColors.TextMuted
            )
        }
    }
}

@Composable
private fun VoiceOrb(state: VoiceState) {
    val baseColor = when (state) {
        VoiceState.IDLE -> MayaColors.OrbRing
        VoiceState.LISTENING -> MayaColors.Listening
        VoiceState.THINKING -> MayaColors.Thinking
        VoiceState.SPEAKING -> MayaColors.Speaking
    }
    val speed = if (state == VoiceState.LISTENING || state == VoiceState.SPEAKING) 700 else 1600
    val transition = rememberInfiniteTransition(label = "voice-orb")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(speed, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice-orb-scale"
    )

    Box(contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(240.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(baseColor.copy(alpha = 0.35f), Color.Transparent)
                    )
                )
        )
        Box(
            modifier = Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(MayaColors.OrbCore, baseColor, MayaColors.OrbGlow)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when (state) {
                    VoiceState.IDLE -> "♥"
                    VoiceState.LISTENING -> "♪"
                    VoiceState.THINKING -> "…"
                    VoiceState.SPEAKING -> "♥"
                },
                fontSize = 52.sp,
                color = Color.White
            )
        }
    }
}
