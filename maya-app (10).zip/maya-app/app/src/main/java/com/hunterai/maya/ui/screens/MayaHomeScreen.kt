package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Maya Home — smart home screen (v8).
 * Honest: this screen is real UI + a real WiFi scan, but it cannot control
 * anything without the Maya Home Box (ESP32 hardware on local WiFi). The
 * scan says so plainly when nothing is found — it never pretends a device
 * exists.
 */
@Composable
fun MayaHomeScreen(viewModel: MayaViewModel, navController: NavController) {
    var scanning by remember { mutableStateOf(false) }
    var scanResult by remember { mutableStateOf("") }
    var shareNote by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Maya Home", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Text(
                "Smart home — ESP32 devices on local WiFi",
                fontSize = 14.sp,
                color = MayaColors.TextMuted
            )
        }
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("Devices", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Koi device nahi mila. Scan dabao — Maya is WiFi pe Home Box dhoondhegi.",
                        fontSize = 13.sp,
                        color = MayaColors.TextBody
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            scanning = true
                            scanResult = ""
                            viewModel.scanMayaHome { msg ->
                                scanning = false
                                scanResult = msg
                            }
                        },
                        enabled = !scanning,
                        colors = ButtonDefaults.buttonColors(containerColor = MayaColors.Primary)
                    ) {
                        Text(if (scanning) "Scan ho raha hai..." else "Scan")
                    }
                    if (scanResult.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(scanResult, fontSize = 14.sp, color = MayaColors.TextDark)
                    }
                }
            }
        }
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth(), backgroundColor = MayaColors.SurfaceBlue) {
                Column {
                    Text("Add a device", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Kisi ne device share kiya ho to uska QR scan karo — lekin hardware " +
                            "ke baghair add nahi hoga. Maya Home Box (ESP32) alag se milta hai.",
                        fontSize = 13.sp,
                        color = MayaColors.TextBody
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            shareNote = "QR scan ke liye Home Box chahiye — abhi koi device share nahi hua."
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MayaColors.SurfaceBlue)
                    ) { Text("Add a device someone shared") }
                    if (shareNote.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(shareNote, fontSize = 13.sp, color = MayaColors.TextBody)
                    }
                }
            }
        }
    }
}
