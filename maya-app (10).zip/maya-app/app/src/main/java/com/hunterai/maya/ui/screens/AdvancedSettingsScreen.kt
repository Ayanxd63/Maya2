package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Advanced settings (v8) — Look and feel + Behaviour + Typing,
 * mirroring the real app's Advanced page.
 */
@Composable
fun AdvancedSettingsScreen(viewModel: MayaViewModel, navController: NavController) {
    val orbStyle by viewModel.orbStyle.collectAsState()
    val orbSize by viewModel.orbSize.collectAsState()
    val floatingOrb by viewModel.floatingOrb.collectAsState()
    val echoGuard by viewModel.echoGuard.collectAsState()
    val startOnBoot by viewModel.startOnBoot.collectAsState()
    val humanTyping by viewModel.humanTyping.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Advanced", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Text("Look and feel • Behaviour • Typing", fontSize = 14.sp, color = MayaColors.TextMuted)
        }
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("Appearance — Orb style", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Text("Orb kaisa dikhe — colour aur size", fontSize = 13.sp, color = MayaColors.TextBody)
                    Spacer(Modifier.height(8.dp))
                    Text("Style", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    for (option in listOf("Glowing", "Pulse", "Minimal")) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(selected = orbStyle == option, onClick = { viewModel.setOrbStyle(option) })
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = orbStyle == option, onClick = { viewModel.setOrbStyle(option) })
                            Text(option, fontSize = 15.sp, color = MayaColors.TextDark)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Size", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    for (option in listOf("Small", "Medium", "Large")) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(selected = orbSize == option, onClick = { viewModel.setOrbSize(option) })
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = orbSize == option, onClick = { viewModel.setOrbSize(option) })
                            Text(option, fontSize = 15.sp, color = MayaColors.TextDark)
                        }
                    }
                }
            }
        }
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("Behaviour", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Spacer(Modifier.height(8.dp))
                    AdvSwitch(
                        title = "Floating orb",
                        subtitle = "Voice orb home screen pe tairta rahe (SYSTEM_ALERT_WINDOW chahiye)",
                        checked = floatingOrb,
                        onChange = { viewModel.setFloatingOrb(it) }
                    )
                    AdvSwitch(
                        title = "Echo-guard",
                        subtitle = "Maya bolte waqt khud ko sunna band kare — apni hi awaz pe jawab na de",
                        checked = echoGuard,
                        onChange = { viewModel.setEchoGuard(it) }
                    )
                    AdvSwitch(
                        title = "Start on boot",
                        subtitle = "Phone restart ho to Maya ka orb phir se aa jaye",
                        checked = startOnBoot,
                        onChange = { viewModel.setStartOnBoot(it) }
                    )
                }
            }
        }
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("Typing", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Spacer(Modifier.height(8.dp))
                    AdvSwitch(
                        title = "Human-paced typing",
                        subtitle = "Maya ke chat replies thode ruk ke aayen — jaise koi insaan likh raha ho",
                        checked = humanTyping,
                        onChange = { viewModel.setHumanTyping(it) }
                    )
                }
            }
        }
    }
}

@Composable
private fun AdvSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MayaColors.TextDark)
            Text(subtitle, fontSize = 13.sp, color = MayaColors.TextBody)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
