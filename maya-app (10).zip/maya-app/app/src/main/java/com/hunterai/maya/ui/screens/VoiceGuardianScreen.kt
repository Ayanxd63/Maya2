package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Voice Guardian — "Answer only your voice" (v8).
 *
 * Honest limit: this app cannot do vendor-grade voice matching. What it
 * really does is the wake-word check — Maya only answers after hearing
 * "Maya". Enrolment records the 3 phrases (the phone confirms you said
 * them out loud) and stores the role; the check itself stays wake-word
 * based, which is exactly what the on-device Voice Guardian toggle uses.
 */
private val enrolPhrases = listOf(
    "Maya, main Babu hoon",
    "Maya, tum meri dost ho",
    "Maya, suno na"
)

private val roles = listOf("Owner", "family", "friend", "guest", "blocked")

@Composable
fun VoiceGuardianScreen(viewModel: MayaViewModel, navController: NavController) {
    val enrolled by viewModel.vgEnrolled.collectAsState()
    val phrases by viewModel.vgPhrases.collectAsState()
    val role by viewModel.vgRole.collectAsState()
    var status by remember { mutableStateOf("") }
    var testResult by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Voice Guardian", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Text(
                "Answer only your voice",
                fontSize = 14.sp,
                color = MayaColors.TextMuted
            )
            Spacer(Modifier.height(8.dp))
            NeumorphicCard(modifier = Modifier.fillMaxWidth(), backgroundColor = MayaColors.SurfaceBlue) {
                Text(
                    "Maya sirf tab jawab degi jab pehle 'Maya' bolo. " +
                        "Enrolment mein tum 3 phrases zor se padhte ho — phone confirm karta hai " +
                        "ke tumne boli hain. Ye on-device wake-word check hai; vendor jaisi " +
                        "real voice matching is app mein nahi hai.",
                    fontSize = 13.sp,
                    color = MayaColors.TextBody
                )
            }
        }
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("Enroll a voice", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Text(
                        "Har phrase ke saamne Record dabao aur phrase zor se padho.",
                        fontSize = 13.sp,
                        color = MayaColors.TextBody
                    )
                    Spacer(Modifier.height(10.dp))
                    enrolPhrases.forEachIndexed { index, phrase ->
                        val done = index.toString() in phrases
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(phrase, fontSize = 15.sp, color = MayaColors.TextDark)
                                Text(
                                    if (done) "Enrolled ✓" else "Abhi nahi",
                                    fontSize = 12.sp,
                                    color = if (done) MayaColors.Success else MayaColors.TextMuted
                                )
                            }
                            Button(
                                onClick = {
                                    status = "Sun rahi hoon — phrase bolo..."
                                    viewModel.enrollPhrase(index) { ok ->
                                        status = if (ok) "Phrase $index enrolled ♥" else "Suna nahi — phir se try karo"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (done) MayaColors.SurfaceBlue else MayaColors.Primary,
                                    contentColor = MayaColors.TextDark
                                )
                            ) { Text(if (done) "Dobara" else "Record") }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Enrolled voices — ${phrases.size} / 3 phrases" +
                            if (enrolled) " • Owner's voice enrolled ✓" else "",
                        fontSize = 13.sp,
                        color = MayaColors.TextBody
                    )
                    if (status.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(status, fontSize = 13.sp, color = MayaColors.TextBody)
                    }
                }
            }
        }
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("Role", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Text("Ye awaz kis ki hai?", fontSize = 13.sp, color = MayaColors.TextBody)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        roles.forEach { r ->
                            Button(
                                onClick = { viewModel.setVgRole(r) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (role == r) MayaColors.PinkDeep else MayaColors.SurfaceBlue,
                                    contentColor = MayaColors.TextDark
                                )
                            ) { Text(r) }
                        }
                    }
                }
            }
        }
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("Test my voice", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            testResult = "Sun rahi hoon — 'Maya' bolo..."
                            viewModel.testVoice { ok ->
                                testResult = if (ok) "Pehchan gayi, Babu ♥ — tum hi ho!" else "Pehchan nahi hui — 'Maya' bolo aur phir try karo"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MayaColors.Primary)
                    ) { Text("Test my voice") }
                    if (testResult.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(testResult, fontSize = 14.sp, color = MayaColors.TextDark)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "God Mode (Touch Guard — sirf tumhari awaz se unlock) Settings → Suraksha mein hai.",
                        fontSize = 12.sp,
                        color = MayaColors.TextMuted
                    )
                }
            }
        }
    }
}
