package com.hunterai.maya.voice

import android.app.Notification
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.hunterai.maya.data.SettingsStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.util.Locale

/**
 * WhatsApp auto-reply (v8) + Message alerts.
 *
 * Auto-reply — answers WhatsApp for you when you are not there. Three
 * toggles, with the real defaults from the app:
 *  - Reply — OFF by default. Nothing is sent until the user turns this on.
 *  - Only while Maya is asleep — ON by default (skip while a voice session
 *    is active, so she never answers mid-conversation).
 *  - Include groups — OFF by default (a bot replying in a work group is
 *    hard to take back).
 * "How she replies — Your words. She follows these exactly": the custom
 * instruction box is used as the reply when the user wrote their own words;
 * otherwise one of 3 local Hinglish templates is used. No message text
 * ever leaves the phone; no Gemini call is made here.
 *
 * Message alerts — when ON, Maya speaks a short alert ("Babu, WhatsApp pe
 * [sender] ka message aaya hai") only when she is idle, never mid-topic.
 *
 * NOTE: Android only delivers notifications to this service after the user
 * turns it on in Settings > Apps > Special access > Notification access.
 */
class WhatsAppAutoReplyService : NotificationListenerService() {

    private var tts: TextToSpeech? = null

    override fun onCreate() {
        super.onCreate()
        // Restore the user's toggles (the service can start before the app).
        try {
            runBlocking {
                val store = SettingsStore(applicationContext)
                enabled = store.whatsappAutoReply.first()
                onlyAsleep = store.waOnlyAsleep.first()
                includeGroups = store.waIncludeGroups.first()
                instruction = store.waInstruction.first()
                messageAlerts = store.messageAlerts.first()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Settings restore failed", e)
        }
    }

    override fun onDestroy() {
        try {
            tts?.shutdown()
        } catch (e: Exception) {
            // Best effort only.
        }
        tts = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn?.notification ?: return
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        try {
            val extras: Bundle = notification.extras
            val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            if (text.isBlank()) return

            val isGroup = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
            val mayaAwake = MayaVoiceService.isActive

            // ---- Message alerts: only when idle, never mid-topic ----
            if (messageAlerts && !mayaAwake) {
                speakAlert(sender)
            }

            // ---- Auto-reply ----
            if (!enabled) return
            if (onlyAsleep && mayaAwake) return
            if (isGroup && !includeGroups) return

            val action = findReplyAction(notification) ?: return
            val remoteInput = action.remoteInputs?.firstOrNull() ?: return
            val results = Bundle().apply {
                putCharSequence(remoteInput.resultKey, pickReply())
            }
            val intent = Intent()
            RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, results)
            try {
                action.actionIntent?.send(applicationContext, 0, intent)
                Log.d(TAG, "Auto-reply sent to $sender")
            } catch (e: Exception) {
                Log.w(TAG, "Auto-reply send failed", e)
            }
        } catch (e: Exception) {
            Log.w(TAG, "onNotificationPosted failed", e)
        }
    }

    private fun findReplyAction(notification: Notification): NotificationCompat.Action? {
        val wearableActions = NotificationCompat.WearableExtender(notification).actions
        wearableActions.firstOrNull { it.remoteInputs?.isNotEmpty() == true }?.let { return it }
        for (i in 0 until NotificationCompat.getActionCount(notification)) {
            val action = NotificationCompat.getAction(notification, i)
            if (action?.remoteInputs?.isNotEmpty() == true) return action
        }
        return null
    }

    /** The user's own words win; otherwise a rotating local Hinglish template. */
    private fun pickReply(): String {
        val custom = instruction.trim()
        val defaultInstruction = "Politely say I am busy right now and will reply myself soon. " +
            "Keep it short, warm and friendly. Reply in the same language they wrote in."
        return if (custom.isNotEmpty() && custom != defaultInstruction) {
            custom.take(200)
        } else {
            REPLIES[(System.currentTimeMillis() / 1000 % REPLIES.size).toInt()]
        }
    }

    private fun speakAlert(sender: String) {
        try {
            if (tts == null) {
                tts = TextToSpeech(applicationContext) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        tts?.language = Locale("hi", "IN")
                        speakAlertNow(sender)
                    }
                }
            } else {
                speakAlertNow(sender)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Message alert failed", e)
        }
    }

    private fun speakAlertNow(sender: String) {
        try {
            val who = if (sender.isBlank()) "koi" else sender
            val msg = "Babu, WhatsApp pe $who ka message aaya hai."
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    try { tts?.shutdown() } catch (e: Exception) { }
                    tts = null
                }
                override fun onError(utteranceId: String?) {
                    try { tts?.shutdown() } catch (e: Exception) { }
                    tts = null
                }
            })
            tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "maya-alert")
        } catch (e: Exception) {
            Log.w(TAG, "Message alert speak failed", e)
        }
    }

    companion object {
        private const val TAG = "MayaAutoReply"

        /** Reply — OFF by default. Set by the app; restored in onCreate. */
        @Volatile
        var enabled: Boolean = false

        /** Only while Maya is asleep — ON by default. */
        @Volatile
        var onlyAsleep: Boolean = true

        /** Include groups — OFF by default. */
        @Volatile
        var includeGroups: Boolean = false

        /** The user's own words for "How she replies". */
        @Volatile
        var instruction: String = ""

        /** Message alerts — speak WhatsApp arrivals when idle. */
        @Volatile
        var messageAlerts: Boolean = false

        private val REPLIES = listOf(
            "Uff, abhi busy hoon Babu — thodi der mein khud reply karunga ♥",
            "Arre, abhi main busy hoon — baad mein baat karte hain, Babu ♥",
            "Abhi thoda busy hoon, Babu — jaldi wapas aata hoon ♥"
        )
    }
}
