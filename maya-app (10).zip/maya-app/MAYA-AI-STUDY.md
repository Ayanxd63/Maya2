# Maya AI — Video Study (for v8)

**Source:** "Maya AI Android Full Setup Hindi | Download, API Key & Phone Control",
HunterIsLive, 1h 10m 42s, 59,595 views — https://youtu.be/GMqckXxK46c
**Method:** video WATCHED visually + listened to in segments (not description/transcript).
Segments: 0:00–2:20 opening voice demo; 3:38–4:08 download; 10:20–10:22 API key;
12:51–12:54 permissions; 17:24–18:47 settings; 20:53 conversation mode; 24:39 skill
store; 37:23–38:00 Voice Guardian; 45:19 Touch Guard; 50:07–50:22 WhatsApp
auto-reply; 55:42/56:12 Maya Home; 1:00:15 PC link; 1:01 Home; 1:03–1:04
conversation/proactive demo; 1:05 sidebar; ~1:06 sub-agent text-file demo.
Website checked: https://getmaya.online, /android, /agentic.
**Study date:** 2026-11-17. **Video presents the app as version 4** (website lists v5.2.60).
Audio caveat: live transcription was garbled in places; spoken quotes are "as heard".
"mentioned, not shown" = chapter title / settings label / website text only, never
seen executing on screen.

## 1. Feature inventory (seen on screen, unless flagged)

- **Voice assistant (Home + floating orb):** Hinglish, answers questions, greets by
  name/time of day. Centre blue mic in bottom nav starts it. Seen 0:00, 1:03.
- **Gemini API key setup:** in-app "Key" dialog — voice + brain run on Google Gemini,
  key is free, starts with "AIza". 4 steps: Google AI Studio → sign in → "Create API
  key" → pick project, copy key → menu → Settings → Personal → Gemini API key, paste,
  Save, press mic again. Orange "Get a free key" button. Seen 10:20; AI Studio screen
  seen 10:22.
- **Default digital assistant:** Android system picker (None, ChatGPT, Claude, Firefox,
  Google [selected], Maya, Maya Home, Meta AI, UC Browser). Setting Maya as default
  assistant is part of setup. Seen 12:54.
- **Download/install via website:** Chrome opens getmaya.online, dark homepage
  "The AI that runs your world.", purple "Buy now". Seen 4:08. APK install screens
  not sampled — mentioned, not shown.
- **Personas:** Maya / Friday / Venom tabs on Voice screen; "Persona" field in Maya
  settings (value "Maya"). Girlfriend mode toggle in Maya settings, seen OFF at 18:48.
  Memory toggle seen ON ("What Maya is allowed to remember").
- **Voice choice:** Voice screen, "Tap to listen, then pick", per-persona tabs, each
  voice with speaker preview button + radio: Breezy (selected), Firm, Youthful, Bright,
  Upbeat, Smooth, Clear, Easy-going (list scrolls). Seen 18:47.
- **Conversation mode:** card in Maya settings, "Talk to her, rather than ask her".
  On-screen text: "Emotion-adaptive voice (experimental). She hears the mood in your
  voice and answers in kind. Maya only — Venom and Friday stay in normal mode."
  Warning: "Replies take about 2s instead of 0.5s, and she keeps only her quick brain
  — everything else still works, one step at a time. You can also say
  'conversation mode on/off'." Seen 20:53.
- **Message alerts:** "Tell me about new WhatsApp messages" toggle seen ON (blue).
  She tells you only when silent for a moment, never mid-topic; saying a phrase
  switches it off. Seen 20:53.
- **Skills / Skill store:** Settings → Skills ("Installed playbooks and the online
  skill store"). Store shows a list of skills each with an "Install" button, plus
  "Install all / Refresh" at top. Individual skill names not legible — not claimed.
  Seen 24:39.
- **Sub-agents:** Settings → Sub-agents ("Custom models and background agents"). Demo
  ~1:06: Maya made a text file, Android showed an "Open with" app chooser. Creation /
  model screens not legibly shown.
- **Social media automation:** Settings entry "Social media" (caption, voice, scheduled
  posts, partly legible). Facebook-story demo is a chapter title (1:06:57) — mentioned,
  not shown.
- **Connectors / backup / appearance:** chapter titles at 32:14; Settings list shows
  Email ("Let Maya send mail from your address") and "WhatsApp groups & reports"
  ("Your groups, and the report formats she fills in"). Backup screen not sampled —
  mentioned, not shown.
- **Voice Guardian:** Settings → Advanced → Voice Guardian ("Answer only your voice").
  "Enroll a voice" dialog: "You'll read 3 short phrases out loud. Recording each one
  separately (instead of one long clip) lets Maya learn how you sound at different
  lengths and energy levels, so she still knows you when you're tired, excited or
  across the room." Role/trust chips: Owner (selected), family, friend, guest, blocked.
  Buttons Cancel / Start. Below: "Enrolled voices — No voices enrolled yet",
  "+ Record owner's voice", "Test my voice". Seen 37:23–38:00.
- **Emergency SOS:** Settings entry only ("Contacts, siren and what gets sent"). No
  siren/call seen — mentioned, not shown.
- **Touch Guard + God Mode:** Touch Guard screen ("Watch the phone while you are away
  from it"), bulleted explanation (partly legible: unlocking, warning, siren), "God
  Mode" section ("Only your voice can…" toggle seen OFF), "Recognise my voice" toggle
  seen ON, under "Switching it off". Seen 45:19.
- **Screen lock:** Settings entry only ("Wake the phone, and unlocking it"). Face Lock /
  face recognition is a chapter concept — no face scan seen on screen — mentioned,
  not shown.
- **WhatsApp auto-reply:** full screen seen 50:22. "Auto-reply — Answer WhatsApp for
  you when you are not there." Defaults: "Reply to WhatsApp messages — Off by default.
  Nothing is sent until you turn this on" (OFF); "Only while Maya is asleep — On: she
  replies only when she is asleep or stopped. Off: always — even mid-conversation with
  you" (ON); "Include groups — Off by default. A bot replying in a work group is hard
  to take back…" (OFF). "How she replies — Your words. She follows these exactly."
  Instruction box (seen text): "Politely say I am busy right now and will reply
  myself soon. Keep it short, warm and friendly. Reply in the same language they
  wrote in." Voice-change examples: "ab se sabko formal reply karna", "bol dena ki
  main shaam tak free ho jaunga". No WhatsApp message seen being sent — mentioned,
  not shown as an executed action.
- **Maya Home (smart home):** "Find your home's ESP32 devices on this WiFi, name them,
  and control them from here or with a voice command to Maya." Blue "Scan" button,
  "+ Add a device someone shared". "New devices found": "MAYA-8D5B7C, 8 channel •
  192.168.1.3" with "Save" / "Identify". "My devices — No devices added yet. Power on
  the device, put the phone and device on the same WiFi, then tap 'Scan'." Seen 56:12.
- **PC ⇄ Phone link:** "Link your PC — memory sync + a live call with the Maya on your
  PC. Easiest: scan the PC's QR." Blue "Scan the PC's QR" button, or email/password
  with "Login" / "Create account". Seen 1:00:15. No live PC link seen working.
- **Markets, Documents, Study / Whiteboard:** sidebar items under PRODUCTIVITY. Inner
  screens not opened — mentioned, not shown.
- **Study mode, Journal, Music:** Home chips labelled Music, Study, Journal. Tapping
  not seen — mentioned, not shown.
- **Notifications:** bell icon in top bar of Home and Settings. Panel not opened.
- **Scan (bottom nav):** label only; function not shown.

## 2. UI map (as seen)

- **Home (dark grey-blue gradient):** top row hamburger (left), "Maya" centred, bell,
  round avatar (right). Greeting "Good evening, Hunter" in large type (time-of-day +
  user name), small sub-line, "1 Energy" pill top-right. Centre: full-body anime girl
  — orange hair, dark witch hat, dark-blue/gold jacket, shorts, boots. Below her,
  pill chips: Music, Study, Journal. Below that, three cards in a row: Weather
  "No data", Today "29 Sat, Aug", Mood "Warm / All good". Bottom: rounded input bar,
  mic icon, "Ask Maya anything…" placeholder, send arrow. Bottom nav (5): Home
  (blue/active), Scan, large raised blue circular mic button (centre), Memories, Chat.
- **Android home screen (voice invoked):** dark wallpaper with a glowing purple-pink
  orb in the centre, app folders/icons at the bottom — voice floats over the normal
  home screen, not a full-screen voice page. Seen 1:03–1:04.
- **Sidebar drawer (light theme):** header logo + "Maya / By The Hunter AI", avatar
  top-right. HOME: Home (highlighted blue pill), Maya Home, Memories, Chat.
  PRODUCTIVITY: Markets, Documents, Study / Whiteboard. Settings below the fold.
  Seen 1:05.
- **Chat screen / Memories ("Yaadein"):** labels only — no thread/list opened in samples.
- **Settings — main list:** header back arrow, "Settings", bell, avatar. ACCOUNT:
  Personal ("Your name, music, Gemini & YouTube keys"). ASSISTANT: Maya ("Persona,
  girlfriend mode, voice, language"), Skills ("Installed playbooks and the online skill
  store"), Sub-agents ("Custom models and background agents"). WORK & MESSAGES: Email
  ("Let Maya send mail from your address"), WhatsApp groups & reports ("Your groups,
  and the report formats she fills in"), Social media (caption/voice/scheduled posts).
- **Settings — Advanced page:** LOOK AND FEEL: Theme ("Colours, typeface, text size and
  corners"), Appearance ("Orb style, colour and size"), Behaviour ("Floating orb,
  echo-guard, start on boot"), Typing ("Human-paced typing in editors"). SAFETY AND
  ACCESS: Voice Guardian ("Answer only your voice"), Emergency SOS ("Contacts, siren
  and what gets sent"), Touch Guard ("Watch the phone while you are away from it"),
  Screen lock, Permissions ("Grant the access Maya's features need"), WhatsApp
  auto-reply (below).
- **Maya settings sub-screen:** Assistant name "maya", Persona "Maya", Girlfriend mode
  OFF, Memory ON.
- **Voice sub-screen:** "Voice — Tap to listen, then pick", tabs Maya/Friday/Venom,
  voice rows with speaker-preview + radio.
- Promo art (not the app): app icon is a purple-haired anime girl in a circle, badges
  "VOICE ASSISTANT / SMART CHAT / IMAGE GENERATOR / AUTOMATION", small green robot
  mascot.

## 3. Voice & persona (heard)

- Young female voice, Hinglish, fast and bright, playful/teasing, not flat/robotic.
- Address words: "Babu" heard at 1:03, teasing reply beginning "Uff, Babu…" when asked
  to play his favourite song — she said he had forgotten hers. A "Jaanu"-like address
  seemed to occur in the opening demo but audio was too garbled to confirm — NOT
  verified. No "Jan" was clearly heard in the samples.
- Conversation flow (1:03): user: "Maya, YouTube [pe] my favourite song play kar
  dena". Maya teases him for forgetting her favourite song, says she will play it,
  repeats her favourite song's name, heard as "Kobi Manuka" (spelling uncertain).
  Full sentences, exclamations ("Uff"), keeps the thread. Reply timing: normal
  ~0.5s, conversation mode ~2s (on-screen text); heard demos had no long pause.
- Listening/speaking animation: no full-screen waveform; the visible voice state is
  the glowing purple-pink orb floating over the Android home screen (1:03–1:04) and
  the avatar on Home.
- When the user stays quiet: in the 1:04 sample the presenter went quiet, the phone
  sat on Maya Home, 45s of audio was mostly silence/mumbling with no clear proactive
  Maya message — proactive-on-silence NOT verified. (Conversation-mode screen says
  she interrupts for WhatsApp only when silent for a moment.)
- Opening demo (0:00–2:20): Maya answered a question about the channel and offered a
  song; exact figures not clearly heard, not reported. At ~2:20 the presenter says
  "today we are going to talk about Maya version 4 update" — video presents v4.

## 4. Automation — seen executing vs only labelled

Seen executing: opening the website in Chrome; creating a Gemini API key in AI Studio;
being set as default digital assistant; navigating Settings (Voice, Conversation mode,
Skill store, Voice Guardian enrol dialog, Touch Guard, WhatsApp auto-reply, Maya Home
Scan, PC-link); creating a text file (sub-agent demo ~1:06) with an "Open with"
chooser.
NOT seen executing (chapter title / label only): opening a named app, playing a
YouTube video (Maya said she would play it at 1:03, but at 1:04:02 the phone was on
the Android home screen — YouTube opening not shown), sending a WhatsApp message,
placing/answering a call, taking a screenshot, setting a reminder/alarm, posting to
social media, Face Lock unlocking, Emergency SOS, call announcement/driving mode.
"150+ actions / 17 suites" is the WEBSITE's claim, not a count verified in the video.

## 5. Settings seen, with states where legible

- Personal: name "maya", Persona "Maya". (Music, Gemini key, YouTube key fields in
  subtitle; values not legible.)
- Maya: Girlfriend mode OFF; Memory ON; Voice Breezy selected, Maya tab; Language value
  not legible.
- Conversation mode: experimental, Maya only; toggle state not clearly legible. Normal
  ~0.5s, conversation ~2s.
- Message alerts: "Tell me about new WhatsApp messages" ON.
- Skills: Install buttons per skill; "Install all / Refresh" at top.
- Sub-agents, Email, WhatsApp groups & reports, Social media: entries seen; inner
  toggles not sampled.
- Theme / Appearance / Behaviour / Typing: entries seen; values not legible. Appearance
  = "Orb style, colour and size"; Behaviour = "Floating orb, echo-guard, start on
  boot"; Typing = "Human-paced typing in editors".
- Voice Guardian: enrol dialog, roles Owner/family/friend/guest/blocked; "No voices
  enrolled yet".
- Emergency SOS, Screen lock, Permissions: entries seen; inner values not sampled.
- Touch Guard: God Mode OFF; "Recognise my voice" ON.
- WhatsApp auto-reply: Reply OFF; Only while Maya is asleep ON; Include groups OFF;
  instruction text box as quoted in §1.
- Maya Home: Scan button; device "MAYA-8D5B7C" not yet saved.
- PC ⇄ Phone: Scan-the-PC's-QR; email/password Login / Create account.
- Home: "1 Energy" pill (what an Energy unit buys was not explained on screen).

## 6. Free vs paid (website + video)

- Website (getmaya.online/android): Android v5.2.60. Chhath sale: **$9 one-time,
  lifetime** for the Android app; **$12 after 19 Nov 2026**; sale ends 11:59pm IST,
  18 Nov 2026. Pro Max add-on: +$8 one-time, lifetime — all characters, Hunter TTS
  (needs 6GB+ RAM), Conversation mode + calling Maya by your own name, all live
  wallpapers. Characters: Free — 1 (Maya-anime); $9 app — 3 (Maya-anime, studio,
  green); Pro Max — all (full body, violet, saree, Jarvis, Venom, new ones). Free
  tier: **10 minutes/day for the first 2 days, then 5 minutes/day**. Site lists 22
  capabilities and "150+ actions across 17 suites".
- Agentic plan (getmaya.online/agentic): monthly add-on for Advanced Agentic Mode
  without an API key; price shown as ₹…/month (masked until signed in); needs a
  licence; no auto-renew; daily + weekly fair-use limits, falls back to Normal mode
  at the limit; paid in rupees by UPI/card; phone and PC plans are separate.
- In the video: Gemini key explicitly free (Key dialog, 10:20); "Buy now" button seen
  (4:08); "1 Energy" seen on Home. Licence-activation screen and exact rupee prices
  NOT sampled on screen.
- Top comments (viewers' reports, not verified): ask for a sub-agent delete button;
  ask how to pay a licence by bKash; ask to resize the anime character; ask for the
  source code; ask for a data-entry/repeated-work demo; privacy concern (app has
  access to everything); voice lock opened for another person's voice; Hindi replies
  coming back in English; bought a plan but got no MacBook version; Spotify/YouTube
  song not audible.

## 7. The "maza" factor (seen/heard; short quotes only)

- Greets him by name and time of day ("Good evening, Hunter") + Mood card ("Warm /
  All good") — the app feels like someone is home.
- Teasing instead of obeying flatly: "Uff, Babu…" — scolds him playfully for
  forgetting her favourite song, then promises to play it anyway.
- Offers music unprompted in the opening demo; frames things as doing them together.
- The anime avatar (orange hair, witch hat) and the glowing orb make the assistant a
  visible character, not a faceless voice; Home chips (Music / Study / Journal)
  present her as a companion for the day, not a search box.
- Conversation mode is framed as "Talk to her, rather than ask her" and
  emotion-adaptive — the fun is in the relationship, not a command list.

## 8. Gaps — what CANNOT be cloned from source alone

- Google Gemini: Key dialog states Maya's voice and brain run on Google's Gemini; a
  clone needs the user's own Gemini key and Google's service.
- Hunter TTS / voice models and voice-enrolment matching (Voice Guardian 3-phrase
  enrolment, owner/family/friend/guest/blocked trust) need the vendor's speech models
  and servers; enrolment UI can be cloned, matching cannot.
- Licence / payment / Energy: $9/$12 licence, Pro Max, Agentic Plan (monthly,
  server-side, fair-use limits) and the "1 Energy" economy are vendor-server enforced;
  a clone cannot reproduce activation, character unlocks or the Agentic brain.
- Advanced Agentic Mode / sub-agents: video shows the entries and a text file being
  created, but multi-step planning, model choice and background-agent execution run on
  the vendor's side — not reproducible from the UI alone.
- WhatsApp / YouTube / calls / social posting: work through the phone's apps,
  accessibility/notification access and (for WhatsApp auto-reply) notification
  listening; the video never showed one executing end-to-end, so the exact mechanism,
  reliability and limits are unproven. WhatsApp auto-reply is off by default and warns
  about groups — treat as a notification-reply feature, not a WhatsApp API.
- Maya Home hardware: ESP32 device "MAYA-8D5B7C, 8 channel" is physical hardware on
  local WiFi — Scan/Save/Identify UI can be cloned, device firmware/pairing cannot.
- PC ⇄ Phone link: needs a vendor account server for memory sync and live calls.
- Website feature catalogue (getmaya.online/android, site's claims — not verified in
  the video): 17 suites — Calls & SMS, WhatsApp, Music & Video, Phone control, Screen
  & camera, Alarms & reminders, Notifications, Files & docs, Coding & websites,
  Knowledge & live info, Location & maps, Smart home, Memory, Study mode, Task macros,
  Personas & voice, System & settings. Named features: real-time voice, calls answered
  by voice, WhatsApp & WhatsApp Business, full phone control, wake word "Hey Maya Ai" /
  sleep "Bye Maya Ai" (offline), three personalities (girlfriend / professional /
  Venom), screen & camera vision, live screen share, live game commentary for
  BGMI/Free Fire, notifications & auto-reply, code writing, deep research,
  making/posting pictures, documents & email, markets & watchlist, whiteboard teaching,
  Voice Guardian, memory, background operation, teachable routines/macros, PC-phone
  link, Maya Home dashboard / Home Box. Wake word, game commentary, markets, documents
  and whiteboard were NOT seen working in the video.
- Other videos noted, NOT used as evidence: "Maya AI V5 Android Tutorial | Install,
  Setup & Agentic Mode Live Demo" (https://www.youtube.com/watch?v=pyC0u3AsOFY, 1h 26m,
  27K views) and "Gemini vs DeepSeek vs Maya Agentic Plan | Phone AI Agent Real Test"
  (https://www.youtube.com/watch?v=L3G0G5ia78o, 44m, 5.6K views).
- Study limits: phone screen small in the recording; some text not legible (skill
  names, Touch Guard bullets, Permissions list); Chat and Memories screens never
  opened in the sampled segments; several automation demos are chapter titles only.
  Treat every "mentioned, not shown" item as unproven until seen executing.

## 9. v8 plan (what to build from this study)

NEW vs v7:
1. Home redesign — greeting by time + name, Energy/free-minutes pill, anime art
   centre (reuse splash art), Music/Study/Journal chips, Weather/Today/Mood cards.
2. Floating orb — voice floats as a glowing orb over the home screen
   (SYSTEM_ALERT_WINDOW, already in manifest); voice page becomes secondary.
3. Conversation mode toggle — emotion-adaptive prompt, Maya only, ~2s replies,
   "Talk to her, rather than ask her".
4. Message alerts toggle — Maya speaks WhatsApp arrivals when idle, never mid-topic.
5. Skills screen — local catalogue of installable skills (Install / Install all /
   Refresh), each toggling a real local behaviour.
6. Sub-agents screen — background task: research via Gemini → text file in Downloads
   → "Open with" chooser (as seen in the demo).
7. Voice Guardian enrolment UI — 3 phrases, roles Owner/family/friend/guest/blocked,
   "Test my voice". HONEST LIMIT: matching is wake-word based; vendor-grade voice
   matching cannot be cloned.
8. WhatsApp auto-reply v2 — three toggles (Reply OFF / Only while asleep ON / Include
   groups OFF) + custom instruction box ("Your words. She follows these exactly.").
9. Setup: "Maya ko default assistant banao" (RoleManager ROLE_ASSISTANT request).
10. Voice picker display names — Breezy/Firm/Youthful/Bright/Upbeat/Smooth/Clear/
    Easy-going (mapping to the Gemini voices underneath).
11. Advanced settings — orb style/size, floating orb on/off, echo-guard, start on boot.
12. Touch Guard: God Mode toggle (voice-only unlock via wake word).
13. Maya Home screen UI (Scan button, empty state) — honest: needs the real Home Box
    hardware to do anything.

CANNOT be cloned (do not promise): licence/payment/Energy server, Hunter TTS + real
voice matching, Agentic server brain, Maya Home hardware, PC-link server.
