package com.hunterai.maya.data.freemium

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.time.LocalDate

private val Context.limitDataStore: DataStore<Preferences> by preferencesDataStore(name = "maya_limits")

/**
 * Freemium voice budget: 10 minutes of voice per day, free.
 * Resets at midnight (device date). Premium users (isPremium in
 * SettingsStore) bypass the limit. All state is local, on-device.
 */
class FreeLimitManager(private val context: Context) {

    companion object {
        const val FREE_SECONDS_PER_DAY = 10 * 60L // 10 minutes
        private val KEY_SECONDS_USED = longPreferencesKey("voice_seconds_used_today")
        private val KEY_DATE = stringPreferencesKey("voice_budget_date")
    }

    private fun today(): String = LocalDate.now().toString()

    /** Seconds of free voice left today (premium = effectively unlimited). */
    val secondsRemaining: Flow<Long> = context.limitDataStore.data.map { prefs ->
        val date = prefs[KEY_DATE]
        val used = prefs[KEY_SECONDS_USED] ?: 0L
        if (date != today()) FREE_SECONDS_PER_DAY else (FREE_SECONDS_PER_DAY - used).coerceAtLeast(0L)
    }

    suspend fun recordUsage(seconds: Long) {
        context.limitDataStore.edit { prefs ->
            val date = prefs[KEY_DATE]
            if (date != today()) {
                prefs[KEY_DATE] = today()
                prefs[KEY_SECONDS_USED] = seconds
            } else {
                val used = prefs[KEY_SECONDS_USED] ?: 0L
                prefs[KEY_SECONDS_USED] = used + seconds
            }
        }
    }

    suspend fun hasBudget(): Boolean = secondsRemaining.first() > 0

    suspend fun resetToday() {
        context.limitDataStore.edit { prefs ->
            prefs[KEY_DATE] = today()
            prefs[KEY_SECONDS_USED] = 0L
        }
    }
}
