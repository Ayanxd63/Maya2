package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Connectors screen.
 *
 * Search + filter chips (Sab / Files / Code / Notes & tasks) + the list:
 * Google Drive, GitHub, Vercel, Notion, Telegram, Todoist, GitLab, Linear.
 *
 * PLACEHOLDER: the connect toggles do NOT perform OAuth — tapping one
 * shows a toast explaining that real OAuth login is coming soon, and the
 * toggle stays off. No account is ever linked by this screen. See README.
 */
private data class Connector(
    val name: String,
    val description: String,
    val category: String // Files | Code | Notes & tasks
)

private val allConnectors = listOf(
    Connector("Google Drive", "Files you create or pick", "Files"),
    Connector("GitHub", "Repos, issues and files", "Code"),
    Connector("Vercel", "Put a site online", "Code"),
    Connector("Notion", "Pages, notes and databases", "Notes & tasks"),
    Connector("Telegram", "Send yourself messages and files", "Notes & tasks"),
    Connector("Todoist", "Your real task list", "Notes & tasks"),
    Connector("GitLab", "Projects, issues and files", "Code"),
    Connector("Linear", "Issues and cycles", "Notes & tasks")
)

@Composable
fun ConnectorsScreen(viewModel: MayaViewModel, navController: NavController) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Sab") }

    val visible = allConnectors.filter { connector ->
        (filter == "Sab" || connector.category == filter) &&
            (query.isBlank() || connector.name.contains(query, ignoreCase = true))
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text("Connectors", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Connectors search karo") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (chip in listOf("Sab", "Files", "Code", "Notes & tasks")) {
                    FilterChip(
                        selected = filter == chip,
                        onClick = { filter = chip },
                        label = { Text(chip) }
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Connect karna abhi placeholder hai — asli OAuth login jald aa raha hai. Koi account link nahi hota.",
                fontSize = 12.sp,
                color = MayaColors.TextMuted
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(visible) { connector ->
                NeumorphicCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(connector.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                            Text(connector.description, fontSize = 13.sp, color = MayaColors.TextBody)
                            Text(connector.category, fontSize = 12.sp, color = MayaColors.Primary)
                        }
                        Switch(
                            checked = false,
                            onCheckedChange = { viewModel.onConnectorTapped(connector.name) }
                        )
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}
