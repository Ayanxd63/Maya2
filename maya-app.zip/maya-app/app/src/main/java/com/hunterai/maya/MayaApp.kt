package com.hunterai.maya

import android.app.Application
import com.hunterai.maya.data.AppDatabase
import com.hunterai.maya.data.CrashLog
import com.hunterai.maya.data.MayaRepository
import com.hunterai.maya.data.SettingsStore
import com.hunterai.maya.data.freemium.FreeLimitManager
import com.hunterai.maya.data.network.GeminiApi
import com.hunterai.maya.data.network.WeatherApi

/**
 * Application class — builds the singletons the ViewModel uses.
 * No API keys live here. The Gemini key is read from SettingsStore
 * (user-entered in Settings) at request time.
 */
class MayaApp : Application() {

    lateinit var repository: MayaRepository
        private set

    lateinit var settingsStore: SettingsStore
        private set

    lateinit var freeLimitManager: FreeLimitManager
        private set

    override fun onCreate() {
        super.onCreate()
        installCrashCatcher()
        CrashLog.append(this, "App onCreate start")
        val db = AppDatabase.getInstance(this)
        settingsStore = SettingsStore(this)
        freeLimitManager = FreeLimitManager(this)
        repository = MayaRepository(
            database = db,
            settingsStore = settingsStore,
            geminiApi = GeminiApi.create(),
            weatherApi = WeatherApi.create()
        )
        CrashLog.append(this, "App onCreate OK")
    }

    /** Saves any uncaught exception's stack trace, then lets Android show the usual crash dialog. */
    private fun installCrashCatcher() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                CrashLog.appendCrash(this, thread, throwable)
            } catch (_: Exception) {
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
