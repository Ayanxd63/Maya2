package com.hunterai.maya.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/** One chat message (Maya or the user). */
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,               // "user" | "maya"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

/** One saved memory — auto-saved after chats when the toggle is on. */
@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val category: String,           // e.g. "pasand", "kaam", "yaad"
    val timestamp: Long = System.currentTimeMillis()
)

/** One built-in / custom automated task (Yaadein screen). */
@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val title: String,
    val steps: Int,
    val type: String,               // e.g. "sawaal", "video prompt", "image prompt"
    val builtIn: Boolean = true,
    val enabled: Boolean = true
)

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAll(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<ChatMessageEntity>

    @Insert
    suspend fun insert(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearAll()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY timestamp DESC")
    fun getAll(): Flow<List<MemoryEntity>>

    @Insert
    suspend fun insert(memory: MemoryEntity): Long

    @Delete
    suspend fun delete(memory: MemoryEntity)

    @Query("DELETE FROM memories")
    suspend fun clearAll()
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY title ASC")
    fun getAll(): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(tasks: List<TaskEntity>)
}

/** UI-friendly chat message (mapped from the entity). */
data class ChatMessage(val role: String, val text: String)

@Database(
    entities = [ChatMessageEntity::class, MemoryEntity::class, TaskEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "maya.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        /** Built-in Yaadein tasks, like the reference screen. */
        fun defaultTasks(): List<TaskEntity> = listOf(
            TaskEntity("gemini se poochho", 8, "sawaal"),
            TaskEntity("chatgpt se poochho", 8, "sawaal"),
            TaskEntity("gemini video", 16, "video prompt"),
            TaskEntity("gemini image", 17, "image prompt"),
            TaskEntity("chatgpt image", 14, "image prompt")
        )
    }
}
