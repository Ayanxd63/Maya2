package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors

/**
 * Generic placeholder for drawer destinations that do not have a full
 * screen yet (Markets, Marketing, Documents, Meri photos, Website/Coding,
 * Terminal, Browser, Accessibility, Maya ke rules, PC ⇌ Phone,
 * Privacy Policy, About, Notifications, Scan).
 * Honest stub — it says the feature is coming instead of faking it.
 */
@Composable
fun PlaceholderScreen(title: String, navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("♥", fontSize = 56.sp, color = MayaColors.PinkDeep)
        Spacer(Modifier.height(12.dp))
        Text(
            title,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = MayaColors.TextDark,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Uff Babu, ye wala hissa abhi ban raha hai — jald aa raha hai! " +
                "Tab tak Chat ya Voice se baat kar lo, main yahin hoon.",
            fontSize = 15.sp,
            color = MayaColors.TextBody,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = { navController.popBackStack() }) {
            Text("Wapas jao")
        }
    }
}
