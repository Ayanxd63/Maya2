package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Intense (18+) gate — PLACEHOLDER flow, never bypassed.
 *
 * Real flow needs: a valid licence, an 18+ age check, and two separate
 * confirmations. This screen shows those steps honestly and does NOT
 * enable Intense — the final "Confirm" only explains that licence
 * verification is coming soon. The ViewModel's markIntenseGatePassed()
 * is never called from here.
 */
@Composable
fun IntenseGateScreen(viewModel: MayaViewModel, navController: NavController) {
    var ageConfirmed by remember { mutableStateOf(false) }
    var understood by remember { mutableStateOf(false) }
    var showSoon by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Intense (18+)", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
        Text(
            "Ye mode sirf adults ke liye hai, Babu. On karne se pehle teen cheezein chahiye:",
            fontSize = 14.sp,
            color = MayaColors.TextBody
        )

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("1. Licence — Maya ki valid licence", fontSize = 15.sp, color = MayaColors.TextDark)
                Text("2. Age check — tumhari age 18+ honi chahiye", fontSize = 15.sp, color = MayaColors.TextDark)
                Text("3. Do confirmation — do alag screens par haan", fontSize = 15.sp, color = MayaColors.TextDark)
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = ageConfirmed, onCheckedChange = { ageConfirmed = it })
                    Text("Main 18 saal ya usse zyada ka hoon.", fontSize = 15.sp, color = MayaColors.TextDark)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = understood, onCheckedChange = { understood = it })
                    Text(
                        "Main samajhta hoon ke ye mode sirf adults ke liye hai.",
                        fontSize = 15.sp,
                        color = MayaColors.TextDark
                    )
                }
            }
        }

        Button(
            onClick = { showSoon = true },
            enabled = ageConfirmed && understood,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Confirm karo")
        }
        Text(
            "Licence verification abhi is app mein placeholder hai — confirm karne par bhi Intense on nahi hoga, jab tak asli licence flow nahi aata.",
            fontSize = 12.sp,
            color = MayaColors.TextMuted
        )
        Spacer(Modifier.height(8.dp))
    }

    if (showSoon) {
        AlertDialog(
            onDismissRequest = { showSoon = false },
            title = { Text("Abhi available nahi") },
            text = {
                Text(
                    "Uff Babu, licence verification jald aa raha hai. Tab tak tumhara mode Friendly hi rahega — main waise bhi tumse pyaar se baat karti hoon ♥"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showSoon = false
                    navController.popBackStack()
                }) { Text("Theek hai") }
            }
        )
    }
}
