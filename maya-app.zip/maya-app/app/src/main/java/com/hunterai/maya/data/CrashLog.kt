package com.hunterai.maya.data

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Crash + milestone log, kept on-device only (filesDir/maya_crash_log.txt).
 * If the app crashes, the stack trace is saved here. On the next launch
 * the app shows it on a Crash Report screen so the user can share it
 * instead of the app just dying silently again.
 */
object CrashLog {
    private const val FILE = "maya_crash_log.txt"

    fun append(context: Context, message: String) {
        try {
            val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            File(context.filesDir, FILE).appendText("[$time] $message\n")
        } catch (_: Exception) {
        }
    }

    fun appendCrash(context: Context, thread: Thread, throwable: Throwable) {
        try {
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            File(context.filesDir, FILE).appendText(
                "\n===== CRASH $time | thread ${thread.name} =====\n$sw\n"
            )
        } catch (_: Exception) {
        }
    }

    /** Returns the log only when it contains a crash, else null. */
    fun read(context: Context): String? = try {
        val f = File(context.filesDir, FILE)
        if (f.exists()) {
            val text = f.readText()
            if (text.contains("===== CRASH")) text else null
        } else {
            null
        }
    } catch (_: Exception) {
        null
    }

    fun clear(context: Context) {
        try {
            File(context.filesDir, FILE).delete()
        } catch (_: Exception) {
        }
    }
}
