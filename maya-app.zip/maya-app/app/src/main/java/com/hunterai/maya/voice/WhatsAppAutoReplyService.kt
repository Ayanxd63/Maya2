package com.hunterai.maya.voice

import android.app.Notification
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.hunterai.maya.data.SettingsStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * WhatsApp auto-reply — OFF by default. The user enables it in Settings AND
 * grants Notification access in the system settings. Replies use short local
 * Hinglish templates only — message text is never sent to any cloud, never
 * saved, never logged.
 *
 * NOTE: Android only delivers notifications to this service after the user
 * turns it on in Settings > Apps > Special access > Notification access.
 */
class WhatsAppAutoReplyService : NotificationListenerService() {

    companion object {
        @Volatile
        var enabled: Boolean = false
    }

    override fun onCreate() {
        super.onCreate()
        // Restore the stored toggle when the service (re)starts.
        enabled = try {
            runBlocking { SettingsStore(applicationContext).whatsappAutoReply.first() }
        } catch (e: Exception) {
            false
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn?.notification ?: return
        if (!enabled) return
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        val action = findReplyAction(notification) ?: return
        val remoteInput = action.remoteInputs?.firstOrNull() ?: return
        val results = Bundle().apply {
            putCharSequence(remoteInput.resultKey, pickReply())
        }
        val intent = Intent()
        RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, results)
        try {
            action.actionIntent.send(applicationContext, 0, intent)
        } catch (e: Exception) {
            // Best-effort only — never crash on a failed auto-reply.
        }
    }

    private fun findReplyAction(notification: Notification): NotificationCompat.Action? {
        val wearableActions = NotificationCompat.WearableExtender(notification).actions
        wearableActions.firstOrNull { it.remoteInputs?.isNotEmpty() == true }?.let { return it }
        for (i in 0 until NotificationCompat.getActionCount(notification)) {
            val action = NotificationCompat.getAction(notification, i)
            if (action?.remoteInputs?.isNotEmpty() == true) return action
        }
        return null
    }

    private fun pickReply(): String {
        val options = listOf(
            "Uff Babu, abhi main thodi busy hoon — thodi der mein jawab deti hoon ♥ — Maya",
            "Arre Babu! Tumhara message mil gaya, main yahin hoon — abhi aati hoon ♥ — Maya",
            "Dil garden garden ho gaya tumhara message dekh kar, Babu! Thodi der mein baat karte hain ♥ — Maya"
        )
        return options[(System.currentTimeMillis() % options.size).toInt()]
    }
}
