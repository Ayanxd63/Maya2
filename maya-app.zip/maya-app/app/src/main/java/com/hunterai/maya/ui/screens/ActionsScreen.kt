package com.hunterai.maya.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Actions — every real thing Maya can do on your phone right now.
 * Honest count from AutomationTools.availableActions() — no fake "150+".
 * Tap a row to run it; YouTube search takes your words.
 */
@Composable
fun ActionsScreen(viewModel: MayaViewModel, navController: NavController) {
    var query by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Actions", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
        Text(
            "Jo Maya abhi sach mein kar sakti hai — koi jhoota daawa nahi. Row dabao, kaam ho jayega, Babu.",
            fontSize = 13.sp, color = MayaColors.TextBody
        )

        // ---- YouTube search ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("YouTube search", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Gaana / video dhoondo...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.runAction("youtube", query) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("YouTube pe chalao") }
            }
        }

        // ---- Action rows ----
        for (item in viewModel.actionList()) {
            NeumorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.runAction(item.id) }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = MayaColors.TextDark)
                        Text(item.subtitle, fontSize = 13.sp, color = MayaColors.TextBody)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MayaColors.TextMuted)
                }
            }
        }

        Text(
            "Aur actions jald aa rahe hain — pehle ye wale pakke kar lo, Babu ♥",
            fontSize = 13.sp, color = MayaColors.TextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )
    }
}
