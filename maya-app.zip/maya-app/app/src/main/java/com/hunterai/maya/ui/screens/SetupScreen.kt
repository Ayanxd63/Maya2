package com.hunterai.maya.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.navigation.AppNav
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * First-run setup — the same flow the original app walks through:
 * permissions, FREE Gemini API key, persona. 2 minutes, then Maya is
 * fully yours. Can be re-run anytime from Settings ("Setup dobara chalao").
 */
@Composable
fun SetupScreen(viewModel: MayaViewModel, navController: NavController) {
    val context = LocalContext.current
    val persona by viewModel.persona.collectAsState()

    var keyInput by remember { mutableStateOf("") }
    var keySaved by remember { mutableStateOf(false) }
    var micGranted by remember { mutableStateOf(false) }
    var notifGranted by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> micGranted = granted }
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> notifGranted = granted }

    fun finishSetup() {
        viewModel.setSetupDone(true)
        navController.navigate(AppNav.HOME) {
            popUpTo(AppNav.SETUP) { inclusive = true }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Maya Setup", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
        Text(
            "Pehli baar 2 minute — phir Maya poori tarah tumhari hai, Babu ♥",
            fontSize = 14.sp, color = MayaColors.TextBody
        )

        // ---- Step 1: permissions ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Step 1 — Permissions", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(10.dp))
                SetupRow(
                    title = "Microphone",
                    subtitle = if (micGranted) "Allow ho gaya ✓" else "Maya sun sake, iske liye chahiye",
                    button = "Allow karo",
                    onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    SetupRow(
                        title = "Notifications",
                        subtitle = if (notifGranted) "Allow ho gaya ✓" else "Voice session aur yaadein batane ke liye",
                        button = "Allow karo",
                        onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                    )
                }
                SetupRow(
                    title = "Battery — background mein chale",
                    subtitle = "Maya ko battery optimization se bahar rakho, warna band ho jayegi",
                    button = "Allow karo",
                    onClick = {
                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:" + context.packageName)
                        }
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            context.startActivity(Intent(Settings.ACTION_SETTINGS))
                        }
                    }
                )
            }
        }

        // ---- Step 2: Gemini key ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Step 2 — FREE Gemini key", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Text(
                    "Bina key ke Maya sirf offline jawab degi. Key sirf tumhare phone mein save hoti hai, kahin nahi jati.",
                    fontSize = 13.sp, color = MayaColors.TextBody
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { keyInput = it },
                    label = { Text("AIza...") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        viewModel.setApiKey(keyInput.trim())
                        keySaved = true
                    }) { Text("Save karo") }
                    TextButton(onClick = {
                        context.startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("https://aistudio.google.com/apikey")
                            )
                        )
                    }) { Text("FREE key banao") }
                }
                if (keySaved) {
                    Text(
                        "Key save ho gayi ✓ — Maya ab aur smart hai, Babu!",
                        fontSize = 13.sp, color = MayaColors.Success
                    )
                }
            }
        }

        // ---- Step 3: persona ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Step 3 — Persona", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                for (option in listOf("Maya", "Friday", "Venom", "Jarvis")) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = persona == option, onClick = { viewModel.setPersona(option) })
                            .padding(vertical = 6.dp)
                    ) {
                        RadioButton(selected = persona == option, onClick = { viewModel.setPersona(option) })
                        Text(option, fontSize = 15.sp, color = MayaColors.TextDark)
                    }
                }
            }
        }

        Button(
            onClick = { finishSetup() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Shuru karo, Babu! ♥") }
        TextButton(
            onClick = { finishSetup() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Baad mein — seedha Home jao") }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SetupRow(title: String, subtitle: String, button: String, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MayaColors.TextDark)
            Text(subtitle, fontSize = 13.sp, color = MayaColors.TextBody)
        }
        Button(onClick = onClick) { Text(button) }
    }
}
