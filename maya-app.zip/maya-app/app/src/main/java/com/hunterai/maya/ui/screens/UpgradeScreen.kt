package com.hunterai.maya.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Upgrade — freemium screen.
 * Free: 10 min/day voice + basic tools. Premium: unlimited voice + all tools.
 *
 * PAYMENT IS A PLACEHOLDER: the UPI intent below uses a clearly-marked
 * placeholder payee ("hunterai@upi" — NOT a real merchant account) and the
 * QR box is a visual placeholder. To go live, the app owner must put their
 * own real UPI ID / merchant details here and verify payments server-side.
 * Do NOT ship this screen as-is expecting money to arrive.
 */
@Composable
fun UpgradeScreen(viewModel: MayaViewModel, navController: NavController) {
    val isPremium by viewModel.isPremium.collectAsState()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("♥", fontSize = 52.sp, color = MayaColors.PinkDeep)
        Text(
            "Maya Premium",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MayaColors.TextDark,
            textAlign = TextAlign.Center
        )
        Text(
            "Babu, unlimited baat karo — koi time limit nahi, saare tools khule ♥",
            fontSize = 15.sp,
            color = MayaColors.TextBody,
            textAlign = TextAlign.Center
        )

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureRow("Unlimited voice baat — roz, kabhi bhi")
                FeatureRow("Saare tools unlocked (Gaane, Padhai, Journal, tasks)")
                FeatureRow("Conversation Mode — zyada emotional, slow replies")
                FeatureRow("Yaadein backup — kabhi kuch bhoolti nahi")
                FeatureRow("No ads, no limits")
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth(), backgroundColor = MayaColors.SurfaceBlue) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = MayaColors.Primary)
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text("Free mode", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Text(
                        "Roz 10 minute voice + basic tools. Aaj ka time khatam ho to kal phir milega.",
                        fontSize = 13.sp, color = MayaColors.TextBody
                    )
                }
            }
        }

        if (isPremium) {
            Text(
                "Premium active hai, Babu — enjoy karo! ♥",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MayaColors.Success
            )
        } else {
            // QR placeholder box
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "QR code yahan aayega\n(placeholder —\nreal UPI ID daalo)",
                    fontSize = 13.sp,
                    color = MayaColors.TextMuted,
                    textAlign = TextAlign.Center
                )
            }
            Button(
                onClick = {
                    // PLACEHOLDER UPI intent — replace "hunterai@upi" with a real
                    // merchant UPI ID before any real sale. See file header.
                    val upiUri = Uri.parse(
                        "upi://pay?pa=hunterai@upi&pn=Maya%20Premium&am=199&cu=INR&tn=Maya%20Premium%20Lifetime"
                    )
                    val intent = Intent(Intent.ACTION_VIEW, upiUri)
                    context.startActivity(Intent.createChooser(intent, "UPI app chuno"))
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MayaColors.PinkDeep)
            ) {
                Text("UPI se pay karo — ₹199 lifetime", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                "Payment placeholder hai — asli UPI ID daale bina paise nahi aayenge. " +
                    "Payment ke baad license activate karne ke liye Settings mein jaao.",
                fontSize = 12.sp,
                color = MayaColors.TextMuted,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun FeatureRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Check, contentDescription = null, tint = MayaColors.Success, modifier = Modifier.size(20.dp))
        Text(text, fontSize = 15.sp, color = MayaColors.TextDark, modifier = Modifier.padding(start = 10.dp))
    }
}
