package com.hunterai.maya.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.hunterai.maya.R
import com.hunterai.maya.ui.theme.MayaColors
import kotlinx.coroutines.delay

/**
 * Splash — the real splash art from the user's reference screenshots,
 * full-screen (anime girl, neon hearts, night city), with the animated
 * loading bar overlaid at the bottom, right where the art's own bar is.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    var progress by remember { mutableStateOf(0f) }
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 400, easing = LinearEasing),
        label = "splash-progress"
    )

    LaunchedEffect(Unit) {
        repeat(20) {
            delay(110)
            progress += 0.05f
        }
        delay(300)
        onFinished()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.splash_art),
            contentDescription = "Maya",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        LinearProgressIndicator(
            progress = { animatedProgress.coerceIn(0f, 1f) },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(start = 48.dp, end = 48.dp, bottom = 56.dp)
                .height(8.dp)
                .clip(RoundedCornerShape(8.dp)),
            color = MayaColors.NeonPink,
            trackColor = Color.White.copy(alpha = 0.35f)
        )
    }
}
