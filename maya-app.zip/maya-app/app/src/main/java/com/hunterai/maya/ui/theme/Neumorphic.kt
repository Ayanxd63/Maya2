package com.hunterai.maya.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Neumorphic helpers — soft raised cards on a pastel background.
 * True neumorphism (two opposite offset shadows) is approximated with a
 * large soft shadow + a white inner-feel surface; Compose has no built-in
 * dual-shadow, so we use one soft dark shadow and a light top edge via
 * the background colour contrast. Kept deliberately simple and fast.
 */
fun Modifier.neumorphic(
    cornerRadius: Dp = 24.dp,
    elevation: Dp = 8.dp,
    backgroundColor: Color = MayaColors.Surface
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = RoundedCornerShape(cornerRadius),
        ambientColor = MayaColors.ShadowDark.copy(alpha = 0.45f),
        spotColor = MayaColors.ShadowDark.copy(alpha = 0.55f)
    )
    .background(backgroundColor, RoundedCornerShape(cornerRadius))

/** A raised soft card. */
@Composable
fun NeumorphicCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    backgroundColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .neumorphic(cornerRadius = cornerRadius, backgroundColor = backgroundColor)
            .padding(16.dp)
    ) {
        content()
    }
}

/** A soft pressed/inset-looking chip (used for info cards). */
@Composable
fun NeumorphicChip(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    backgroundColor: Color = MayaColors.BackgroundSoft,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(cornerRadius),
                ambientColor = MayaColors.ShadowDark.copy(alpha = 0.25f),
                spotColor = MayaColors.ShadowDark.copy(alpha = 0.30f)
            )
            .background(backgroundColor, RoundedCornerShape(cornerRadius))
            .padding(14.dp)
    ) {
        content()
    }
}
