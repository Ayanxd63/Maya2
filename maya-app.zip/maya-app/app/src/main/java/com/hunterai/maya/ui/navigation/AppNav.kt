package com.hunterai.maya.ui.navigation

/** All navigation routes in the app. Keep in sync with MainActivity's NavHost. */
object AppNav {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CHAT = "chat"
    const val VOICE = "voice"
    const val MEMORY = "memory"
    const val SETTINGS = "settings"
    const val UPGRADE = "upgrade"
    const val SECRET_SETTINGS = "secret-settings"
    const val INTENSE_GATE = "intense-gate"
    const val VOICE_PICKER = "voice-picker"
    const val VOICE_ENGINE = "voice-engine"
    const val CONNECTORS = "connectors"
    const val PLACEHOLDER = "placeholder/{title}"

    fun placeholder(title: String): String = "placeholder/${title}"

    /** Routes that show the bottom navigation bar + drawer. */
    val MAIN_ROUTES = setOf(HOME, CHAT, VOICE, MEMORY)
}
