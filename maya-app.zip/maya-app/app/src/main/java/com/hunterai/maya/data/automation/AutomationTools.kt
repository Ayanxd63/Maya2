package com.hunterai.maya.data.automation

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Device & app automation — only what Android allows a normal app to do
 * with public intents. Anything needing special setup is a clearly
 * labelled STUB with the exact steps, never a fake "it works" claim.
 *
 * Works (intents, no special permission):
 *  - openApp(packageName)      — launch any installed app
 *  - playYouTube(query)        — open YouTube search / video
 *  - sendWhatsApp(number, msg) — open WhatsApp chat with prefilled text
 *  - openUrl(url)              — browser
 *
 * Stubs (need extra user setup — see comments):
 *  - takeScreenshot()          — needs MediaProjection + foreground service
 *  - lockScreen()              — needs Device Admin (user must enable it)
 */
class AutomationTools(private val context: Context) {

    fun openApp(packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } else {
            Toast.makeText(context, "App installed nahi hai, Babu.", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun playYouTube(query: String) {
        val uri = Uri.parse(
            "https://www.youtube.com/results?search_query=" + Uri.encode(query)
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openYouTubeVideo(videoId: String) {
        val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val webIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/watch?v=$videoId")
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        try {
            context.startActivity(appIntent)
        } catch (e: Exception) {
            context.startActivity(webIntent)
        }
    }

    fun sendWhatsApp(number: String, message: String) {
        // number: international format WITHOUT '+' e.g. "919876543210"
        val uri = Uri.parse(
            "https://wa.me/$number?text=" + Uri.encode(message)
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    // ------------------------------------------------------------------
    // STUB — Screenshot (MediaProjection)
    // ------------------------------------------------------------------
    // A real screenshot needs: a MediaProjectionManager token (the user
    // must accept the system "Start recording/casting?" dialog once),
    // a foreground service, and an ImageReader + VirtualDisplay pipeline.
    // That is ~300 lines and a permission flow — intentionally left as a
    // stub here so the app never pretends it can screenshot silently.
    // TODO: implement with MediaProjectionManager.createScreenCaptureIntent()
    // from an Activity, then capture via ImageReader in a foreground service.
    fun takeScreenshot(): Boolean {
        Toast.makeText(
            context,
            "Screenshot ke liye pehle screen-capture permission chahiye — jald aa raha hai, Babu.",
            Toast.LENGTH_LONG
        ).show()
        return false
    }

    // ------------------------------------------------------------------
    // STUB — Lock screen (Device Admin)
    // ------------------------------------------------------------------
    // Locking needs the user to enable Maya as a Device Admin in
    // Settings > Security > Device admin apps. Until then lockNow() is a
    // no-op that explains itself. requestDeviceAdmin() opens the system
    // enable screen; lockNow() only works after the user enables it.
    fun isDeviceAdminEnabled(adminComponent: ComponentName): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent)
    }

    fun requestDeviceAdmin(activity: Activity, adminComponent: ComponentName, requestCode: Int) {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Maya ko lock karne ke liye device admin chahiye, Babu."
            )
        }
        activity.startActivityForResult(intent, requestCode)
    }

    fun lockNow(adminComponent: ComponentName): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return if (dpm.isAdminActive(adminComponent)) {
            dpm.lockNow()
            true
        } else {
            Toast.makeText(
                context,
                "Pehle Settings mein Maya ko Device Admin banao, Babu.",
                Toast.LENGTH_LONG
            ).show()
            false
        }
    }
}
