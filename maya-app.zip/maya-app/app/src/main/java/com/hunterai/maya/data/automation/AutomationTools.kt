package com.hunterai.maya.data.automation

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Device & app automation — only what Android allows a normal app to do
 * with public intents. Anything needing special setup is a clearly
 * labelled STUB with the exact steps, never a fake "it works" claim.
 *
 * Works (intents, no special permission):
 *  - openApp(packageName)      — launch any installed app
 *  - playYouTube(query)        — open YouTube search / video
 *  - sendWhatsApp(number, msg) — open WhatsApp chat with prefilled text
 *  - openUrl(url)              — browser
 *
 * Stubs (need extra user setup — see comments):
 *  - takeScreenshot()          — needs MediaProjection + foreground service
 *  - lockScreen()              — needs Device Admin (user must enable it)
 */
class AutomationTools(private val context: Context) {

    fun openApp(packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } else {
            Toast.makeText(context, "App installed nahi hai, Babu.", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun playYouTube(query: String) {
        val uri = Uri.parse(
            "https://www.youtube.com/results?search_query=" + Uri.encode(query)
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openYouTubeVideo(videoId: String) {
        val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val webIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/watch?v=$videoId")
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        try {
            context.startActivity(appIntent)
        } catch (e: Exception) {
            context.startActivity(webIntent)
        }
    }

    fun sendWhatsApp(number: String, message: String) {
        // number: international format WITHOUT '+' e.g. "919876543210"
        val uri = Uri.parse(
            "https://wa.me/$number?text=" + Uri.encode(message)
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    // ------------------------------------------------------------------
    // More real actions (all public intents — no special permission).
    // ------------------------------------------------------------------

    private fun isInstalled(packageName: String): Boolean = try {
        @Suppress("DEPRECATION")
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (e: Exception) {
        false
    }

    /** Open Instagram (app if installed, else the web). */
    fun openInstagram() {
        if (isInstalled("com.instagram.android")) openApp("com.instagram.android")
        else openUrl("https://www.instagram.com/")
    }

    /** Open Spotify (app if installed, else the web player). */
    fun openSpotify() {
        if (isInstalled("com.spotify.music")) openApp("com.spotify.music")
        else openUrl("https://open.spotify.com/")
    }

    /** Open Google Maps at a place / search query. */
    fun openMaps(query: String) {
        val uri = Uri.parse("geo:0,0?q=" + Uri.encode(query))
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            openUrl("https://www.google.com/maps/search/" + Uri.encode(query))
        }
    }

    /** Open the camera app (photo is saved by the camera app itself). */
    fun openCamera() {
        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Camera nahi khula, Babu.", Toast.LENGTH_SHORT).show()
        }
    }

    /** Open the photo gallery. */
    fun openGallery() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Gallery nahi khuli, Babu.", Toast.LENGTH_SHORT).show()
        }
    }

    /** Open the phone's Settings app. */
    fun openSettings() {
        val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /** Dial a number (opens the dialer — Maya never calls without you pressing Call). */
    fun dialNumber(number: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /** One catalogue entry for the Actions screen. */
    data class ActionItem(val id: String, val title: String, val subtitle: String)

    /** The actions Maya can really do right now (honest count — no fake 150). */
    fun availableActions(): List<ActionItem> = listOf(
        ActionItem("youtube", "YouTube kholo", "Gaane / video — search bhi kar sakti ho"),
        ActionItem("whatsapp", "WhatsApp kholo", "Chat kholo ya message bhejo"),
        ActionItem("instagram", "Instagram kholo", "Reels aur posts"),
        ActionItem("spotify", "Spotify kholo", "Gaane suno"),
        ActionItem("maps", "Maps kholo", "Jagah dhoondo — New Delhi"),
        ActionItem("camera", "Camera kholo", "Photo lo"),
        ActionItem("gallery", "Gallery kholo", "Apni photos dekho"),
        ActionItem("dial", "Call karo", "Dialer kholo"),
        ActionItem("settings", "Phone Settings kholo", "System settings"),
        ActionItem("lock", "Screen lock karo", "Device Admin enable karne ke baad")
    )

    // ------------------------------------------------------------------
    // STUB — Screenshot (MediaProjection)
    // ------------------------------------------------------------------
    // A real screenshot needs: a MediaProjectionManager token (the user
    // must accept the system "Start recording/casting?" dialog once),
    // a foreground service, and an ImageReader + VirtualDisplay pipeline.
    // That is ~300 lines and a permission flow — intentionally left as a
    // stub here so the app never pretends it can screenshot silently.
    // TODO: implement with MediaProjectionManager.createScreenCaptureIntent()
    // from an Activity, then capture via ImageReader in a foreground service.
    fun takeScreenshot(): Boolean {
        Toast.makeText(
            context,
            "Screenshot ke liye pehle screen-capture permission chahiye — jald aa raha hai, Babu.",
            Toast.LENGTH_LONG
        ).show()
        return false
    }

    // ------------------------------------------------------------------
    // STUB — Lock screen (Device Admin)
    // ------------------------------------------------------------------
    // Locking needs the user to enable Maya as a Device Admin in
    // Settings > Security > Device admin apps. Until then lockNow() is a
    // no-op that explains itself. requestDeviceAdmin() opens the system
    // enable screen; lockNow() only works after the user enables it.
    fun isDeviceAdminEnabled(adminComponent: ComponentName): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent)
    }

    fun requestDeviceAdmin(activity: Activity, adminComponent: ComponentName, requestCode: Int) {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Maya ko lock karne ke liye device admin chahiye, Babu."
            )
        }
        activity.startActivityForResult(intent, requestCode)
    }

    fun lockNow(adminComponent: ComponentName): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return if (dpm.isAdminActive(adminComponent)) {
            dpm.lockNow()
            true
        } else {
            Toast.makeText(
                context,
                "Pehle Settings mein Maya ko Device Admin banao, Babu.",
                Toast.LENGTH_LONG
            ).show()
            false
        }
    }
}
