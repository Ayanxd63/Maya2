package com.hunterai.maya.data

/**
 * Memory safety — enforced before ANYTHING is auto-saved to Yaadein.
 *
 * Rule (also shown on the Settings > Memory card): passwords, OTP, PIN
 * and card numbers are NEVER saved, no matter the toggle. Memories live
 * only on this phone, in Room — there is no cloud sync anywhere in the app.
 *
 * shouldSave() returns true only when the text looks worth remembering
 * AND contains nothing from the deny-list below.
 */
object MemorySafety {

    private val denyList = listOf(
        // Passwords: "password: abc123", "pwd=...", "passwd ..."
        Regex("(?i)(password|passwd|pwd)\\s*[:=]\\s*\\S+"),
        // OTP: "OTP 483920", "otp: 123456", "one time password 1234"
        Regex("(?i)\\b(otp|one[- ]?time password)\\b\\s*[:=]?\\s*\\d{4,8}\\b"),
        // PIN: "PIN 1234", "pin: 9876"
        Regex("(?i)\\bpin\\b\\s*[:=]?\\s*\\d{4,6}\\b"),
        // CVV: "cvv 123"
        Regex("(?i)\\bcvv\\b\\s*[:=]?\\s*\\d{3,4}\\b"),
        // Card numbers: 13–19 digits, optionally spaced/dashed
        Regex("\\b(?:\\d[ -]?){13,19}\\b"),
        // Plain 16-digit run (card number without spaces)
        Regex("(?<!\\d)\\d{16}(?!\\d)"),
        // "card number: 4111..." phrasing
        Regex("(?i)(card|credit|debit)\\s*(number|no\\.?)?\\s*[:=]?\\s*\\d[\\d -]{11,}")
    )

    /** True when the text contains NO sensitive secret. */
    fun isSafe(text: String): Boolean = denyList.none { it.containsMatchIn(text) }

    /** Words that make a message worth remembering (a liking, a routine, a task). */
    private val memoryHints = listOf(
        "yaad rakh", "pasand", "routine", "kaam hai", "meri ", "mera ",
        "birthday", "anniversary", "subah", "raat ko", "roz "
    )

    /**
     * True only when the text is safe AND looks like a real memory.
     * Short greetings ("hi", "ok") are not saved.
     */
    fun shouldSave(text: String): Boolean {
        if (text.trim().length < 12) return false
        if (!isSafe(text)) return false
        val lower = text.lowercase()
        return memoryHints.any { lower.contains(it) }
    }
}
