package com.hunterai.maya.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.navigation.AppNav
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Settings — API key, persona (Maya / Friday / Venom), gender
 * (selecting "Male" turns on Girlfriend Mode, like the original),
 * language, voice pitch/speed, auto-save.
 * The Gemini API key is NEVER hardcoded — the user pastes their own
 * FREE key here (get one at https://aistudio.google.com/app/apikey).
 */
@Composable
fun SettingsScreen(viewModel: MayaViewModel, navController: NavController) {
    val apiKey by viewModel.apiKey.collectAsState()
    val persona by viewModel.persona.collectAsState()
    val gender by viewModel.gender.collectAsState()
    val language by viewModel.language.collectAsState()
    val pitch by viewModel.voicePitch.collectAsState()
    val rate by viewModel.voiceRate.collectAsState()
    val autoSave by viewModel.autoSaveMemory.collectAsState()

    var keyInput by remember(apiKey) { mutableStateOf(apiKey) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Gemini API key (free)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Text(
                    "Apni FREE Gemini key yahan daalo — bina key ke Maya sirf offline jawab degi. Key sirf tumhare phone mein save hoti hai.",
                    fontSize = 13.sp, color = MayaColors.TextBody
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = {
                        keyInput = it
                        viewModel.setApiKey(it.trim())
                    },
                    label = { Text("AIza...") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Persona", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                for (option in listOf("Maya", "Friday", "Venom", "Jarvis")) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = persona == option, onClick = { viewModel.setPersona(option) })
                            .padding(vertical = 6.dp)
                    ) {
                        RadioButton(selected = persona == option, onClick = { viewModel.setPersona(option) })
                        Column {
                            Text(option, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MayaColors.TextDark)
                            Text(
                                when (option) {
                                    "Maya" -> "Pyaari, caring girlfriend-style dost"
                                    "Friday" -> "Smart, calm professional assistant"
                                    "Jarvis" -> "Precise, formal butler-style assistant"
                                    else -> "Bold, dark, mazahiya style"
                                },
                                fontSize = 12.sp, color = MayaColors.TextMuted
                            )
                        }
                    }
                }
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Tumhara gender", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Text(
                    "\"Male\" chuno to Girlfriend Mode on ho jata hai — Maya tumhe Babu, Jan keh kar baat karegi.",
                    fontSize = 13.sp, color = MayaColors.TextBody
                )
                Spacer(Modifier.height(8.dp))
                for (option in listOf("Male", "Female", "Prefer not to say")) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = gender == option, onClick = { viewModel.setGender(option) })
                            .padding(vertical = 6.dp)
                    ) {
                        RadioButton(selected = gender == option, onClick = { viewModel.setGender(option) })
                        Text(option, fontSize = 15.sp, color = MayaColors.TextDark)
                    }
                }
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Bhasha / Language", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                for (option in listOf("Hindi / Urdu (Hinglish)", "English", "Roman Urdu")) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = language == option, onClick = { viewModel.setLanguage(option) })
                            .padding(vertical = 6.dp)
                    ) {
                        RadioButton(selected = language == option, onClick = { viewModel.setLanguage(option) })
                        Text(option, fontSize = 15.sp, color = MayaColors.TextDark)
                    }
                }
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Awaz (Voice)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(8.dp))
                Text("Pitch: ${"%.2f".format(pitch)}", fontSize = 14.sp, color = MayaColors.TextBody)
                Slider(
                    value = pitch,
                    onValueChange = { viewModel.setVoicePitch(it) },
                    valueRange = 0.7f..1.4f
                )
                Text("Speed: ${"%.2f".format(rate)}", fontSize = 14.sp, color = MayaColors.TextBody)
                Slider(
                    value = rate,
                    onValueChange = { viewModel.setVoiceRate(it) },
                    valueRange = 0.7f..1.3f
                )
            }
        }

        // ---- Memory ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Memory", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Maya ko khud se yaad rakhne do",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = MayaColors.TextDark
                        )
                        Text(
                            "Jo kaam ki baatein wo pakadti hai unhe save karti hai — log, pasand, routine.",
                            fontSize = 13.sp,
                            color = MayaColors.TextBody
                        )
                    }
                    Switch(checked = autoSave, onCheckedChange = { viewModel.setAutoSaveMemory(it) })
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Passwords, OTP, PIN aur card numbers kabhi save nahi hote, ye chahe jaise bhi set ho. " +
                        "Tumhari yaadein isi phone pe rehti hain — sab Yaadein me dekh lo.",
                    fontSize = 13.sp,
                    color = MayaColors.TextBody
                )
            }
        }

        // ---- More Maya settings ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Maya ke aur settings", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(6.dp))
                SettingsLink("Secret settings — Girlfriend mode") { navController.navigate(AppNav.SECRET_SETTINGS) }
                SettingsLink("Awaaz — Voice picker") { navController.navigate(AppNav.VOICE_PICKER) }
                SettingsLink("Voice engine") { navController.navigate(AppNav.VOICE_ENGINE) }
                SettingsLink("Connectors") { navController.navigate(AppNav.CONNECTORS) }
            }
        }

        Text(
            "Maya v5.2.60 • by The Hunter AI",
            fontSize = 12.sp,
            color = MayaColors.TextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )
    }
}

@Composable
private fun SettingsLink(title: String, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 10.dp)
    ) {
        Text(title, fontSize = 15.sp, color = MayaColors.TextDark, modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MayaColors.TextMuted)
    }
}
