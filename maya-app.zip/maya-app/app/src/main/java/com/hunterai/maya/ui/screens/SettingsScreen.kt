package com.hunterai.maya.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.navigation.AppNav
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Settings — API key, persona (Maya / Friday / Venom), gender
 * (selecting "Male" turns on Girlfriend Mode, like the original),
 * language, voice pitch/speed, auto-save.
 * The Gemini API key is NEVER hardcoded — the user pastes their own
 * FREE key here (get one at https://aistudio.google.com/app/apikey).
 */
@Composable
fun SettingsScreen(viewModel: MayaViewModel, navController: NavController) {
    val context = LocalContext.current
    val apiKey by viewModel.apiKey.collectAsState()
    val persona by viewModel.persona.collectAsState()
    val gender by viewModel.gender.collectAsState()
    val language by viewModel.language.collectAsState()
    val pitch by viewModel.voicePitch.collectAsState()
    val rate by viewModel.voiceRate.collectAsState()
    val autoSave by viewModel.autoSaveMemory.collectAsState()
    val faceLock by viewModel.faceLock.collectAsState()
    val touchGuard by viewModel.touchGuard.collectAsState()
    val voiceGuardian by viewModel.voiceGuardian.collectAsState()
    val whatsappAutoReply by viewModel.whatsappAutoReply.collectAsState()
    val autoVoice by viewModel.autoVoice.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val conversationMode by viewModel.conversationMode.collectAsState()
    val messageAlerts by viewModel.messageAlerts.collectAsState()
    val waOnlyAsleep by viewModel.waOnlyAsleep.collectAsState()
    val waIncludeGroups by viewModel.waIncludeGroups.collectAsState()
    val waInstruction by viewModel.waInstruction.collectAsState()
    val godMode by viewModel.godMode.collectAsState()
    val recognizeVoice by viewModel.recognizeVoice.collectAsState()
    val accent by viewModel.accent.collectAsState()

    var keyInput by remember(apiKey) { mutableStateOf(apiKey) }
    var nameInput by remember(userName) { mutableStateOf(userName) }
    var waInstructionInput by remember(waInstruction) { mutableStateOf(waInstruction) }
    var backupMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Gemini API key (free)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Text(
                    "Apni FREE Gemini key yahan daalo — bina key ke Maya sirf offline jawab degi. Key sirf tumhare phone mein save hoti hai.",
                    fontSize = 13.sp, color = MayaColors.TextBody
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = {
                        keyInput = it
                        viewModel.setApiKey(it.trim())
                    },
                    label = { Text("AIza...") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Persona", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                for (option in listOf("Maya", "Friday", "Venom", "Jarvis")) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = persona == option, onClick = { viewModel.setPersona(option) })
                            .padding(vertical = 6.dp)
                    ) {
                        RadioButton(selected = persona == option, onClick = { viewModel.setPersona(option) })
                        Column {
                            Text(option, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MayaColors.TextDark)
                            Text(
                                when (option) {
                                    "Maya" -> "Pyaari, caring girlfriend-style dost"
                                    "Friday" -> "Smart, calm professional assistant"
                                    "Jarvis" -> "Precise, formal butler-style assistant"
                                    else -> "Bold, dark, mazahiya style"
                                },
                                fontSize = 12.sp, color = MayaColors.TextMuted
                            )
                        }
                    }
                }
            }
        }

        // ---- Tumhara naam (v8) — Home greeting "Good evening, [naam]" ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Tumhara naam", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Text(
                    "Maya tumhe isi naam se bulayegi — Home pe greeting bhi yahi aayegi.",
                    fontSize = 13.sp, color = MayaColors.TextBody
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = {
                        nameInput = it
                        viewModel.setUserName(it.trim())
                    },
                    label = { Text("Naam, jaise: Babu") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Tumhara gender", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Text(
                    "\"Male\" chuno to Girlfriend Mode on ho jata hai — Maya tumhe Babu, Jan keh kar baat karegi.",
                    fontSize = 13.sp, color = MayaColors.TextBody
                )
                Spacer(Modifier.height(8.dp))
                for (option in listOf("Male", "Female", "Prefer not to say")) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = gender == option, onClick = { viewModel.setGender(option) })
                            .padding(vertical = 6.dp)
                    ) {
                        RadioButton(selected = gender == option, onClick = { viewModel.setGender(option) })
                        Text(option, fontSize = 15.sp, color = MayaColors.TextDark)
                    }
                }
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Bhasha / Language", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                for (option in listOf("Hindi / Urdu (Hinglish)", "English", "Roman Urdu")) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = language == option, onClick = { viewModel.setLanguage(option) })
                            .padding(vertical = 6.dp)
                    ) {
                        RadioButton(selected = language == option, onClick = { viewModel.setLanguage(option) })
                        Text(option, fontSize = 15.sp, color = MayaColors.TextDark)
                    }
                }
            }
        }

        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Awaz (Voice)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(8.dp))
                Text("Pitch: ${"%.2f".format(pitch)}", fontSize = 14.sp, color = MayaColors.TextBody)
                Slider(
                    value = pitch,
                    onValueChange = { viewModel.setVoicePitch(it) },
                    valueRange = 0.7f..1.4f
                )
                Text("Speed: ${"%.2f".format(rate)}", fontSize = 14.sp, color = MayaColors.TextBody)
                Slider(
                    value = rate,
                    onValueChange = { viewModel.setVoiceRate(it) },
                    valueRange = 0.7f..1.3f
                )
            }
        }

        // ---- Memory ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Memory", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Maya ko khud se yaad rakhne do",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = MayaColors.TextDark
                        )
                        Text(
                            "Jo kaam ki baatein wo pakadti hai unhe save karti hai — log, pasand, routine.",
                            fontSize = 13.sp,
                            color = MayaColors.TextBody
                        )
                    }
                    Switch(checked = autoSave, onCheckedChange = { viewModel.setAutoSaveMemory(it) })
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Passwords, OTP, PIN aur card numbers kabhi save nahi hote, ye chahe jaise bhi set ho. " +
                        "Tumhari yaadein isi phone pe rehti hain — sab Yaadein me dekh lo.",
                    fontSize = 13.sp,
                    color = MayaColors.TextBody
                )
            }
        }

        // ---- More Maya settings ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Maya ke aur settings", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(6.dp))
                SettingsLink("Setup dobara chalao") { navController.navigate(AppNav.SETUP) }
                SettingsLink("Actions — jo Maya kar sakti hai") { navController.navigate(AppNav.ACTIONS) }
                SettingsLink("Skills") { navController.navigate(AppNav.SKILLS) }
                SettingsLink("Sub-agents") { navController.navigate(AppNav.SUB_AGENTS) }
                SettingsLink("Voice Guardian") { navController.navigate(AppNav.VOICE_GUARDIAN) }
                SettingsLink("Maya Home") { navController.navigate(AppNav.MAYA_HOME) }
                SettingsLink("Advanced settings") { navController.navigate(AppNav.ADVANCED) }
                SettingsLink("Secret settings — Girlfriend mode") { navController.navigate(AppNav.SECRET_SETTINGS) }
                SettingsLink("Awaaz — Voice picker") { navController.navigate(AppNav.VOICE_PICKER) }
                SettingsLink("Voice engine") { navController.navigate(AppNav.VOICE_ENGINE) }
                SettingsLink("Connectors") { navController.navigate(AppNav.CONNECTORS) }
            }
        }

        // ---- Conversation mode (v8) — "Talk to her, rather than ask her" ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Conversation mode", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(8.dp))
                SettingSwitch(
                    title = "Conversation mode",
                    subtitle = "Maya sirf — baat karte raho, wo khud sunti aur jawab deti rahegi. Emotion-adaptive, thode lambe jawab. Sirf Maya ke liye.",
                    checked = conversationMode,
                    onChange = { viewModel.setConversationMode(it) }
                )
            }
        }

        // ---- Auto voice (default ON) ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Auto voice", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(8.dp))
                SettingSwitch(
                    title = "Auto voice response",
                    subtitle = "App khulte hi Maya khud sunna shuru kar degi — mic dabane ki zaroorat nahi",
                    checked = autoVoice,
                    onChange = { viewModel.setAutoVoice(it) }
                )
            }
        }

        // ---- Suraksha (v7) ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Suraksha", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(8.dp))
                SettingSwitch(
                    title = "Face Lock",
                    subtitle = "App kholte waqt face / PIN se pehchan — koi aur Maya na khole",
                    checked = faceLock,
                    onChange = { viewModel.setFaceLock(it) }
                )
                SettingSwitch(
                    title = "Touch Guard",
                    subtitle = "Screen lock ho jati hai — long-press se khulti hai",
                    checked = touchGuard,
                    onChange = { viewModel.setTouchGuard(it) }
                )
                SettingSwitch(
                    title = "Voice Guardian",
                    subtitle = "Voice mein Maya sirf tab jawab degi jab pehle 'Maya' bolo",
                    checked = voiceGuardian,
                    onChange = { viewModel.setVoiceGuardian(it) }
                )
                SettingSwitch(
                    title = "God Mode (Touch Guard)",
                    subtitle = "ON ho to Touch Guard sirf tumhari awaz se khulega — long-press kaam nahi karega",
                    checked = godMode,
                    onChange = { viewModel.setGodMode(it) }
                )
                SettingSwitch(
                    title = "Recognise my voice",
                    subtitle = "God Mode ke liye — Maya tumhari awaz pehchane",
                    checked = recognizeVoice,
                    onChange = { viewModel.setRecognizeVoice(it) }
                )
            }
        }

        // ---- WhatsApp auto-reply (v8) — 3 toggles + instruction + message alerts ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("WhatsApp auto-reply", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Text(
                    "ON karne par Maya WhatsApp messages ka chhota sa pyaara jawab khud bhej degi. " +
                        "Jawab sirf phone pe bante hain — message kahin nahi jata, save nahi hota.",
                    fontSize = 13.sp, color = MayaColors.TextBody
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Reply",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = MayaColors.TextDark,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(checked = whatsappAutoReply, onCheckedChange = { viewModel.setWhatsappAutoReply(it) })
                }
                Text(
                    "Off by default. Nothing is sent until you turn this on.",
                    fontSize = 12.sp, color = MayaColors.TextMuted
                )
                Spacer(Modifier.height(8.dp))
                SettingSwitch(
                    title = "Only while Maya is asleep",
                    subtitle = "Voice baat chal rahi ho to jawab na bheje — beech mein kabhi nahi",
                    checked = waOnlyAsleep,
                    onChange = { viewModel.setWaOnlyAsleep(it) }
                )
                SettingSwitch(
                    title = "Include groups",
                    subtitle = "Group chats mein bhi auto-reply bheje (work group mein bot reply mushkil hai)",
                    checked = waIncludeGroups,
                    onChange = { viewModel.setWaIncludeGroups(it) }
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "How she replies — Your words. She follows these exactly.",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MayaColors.TextDark
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = waInstructionInput,
                    onValueChange = {
                        waInstructionInput = it
                        viewModel.setWaInstruction(it)
                    },
                    label = { Text("Apne words likho...") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                SettingSwitch(
                    title = "Message alerts",
                    subtitle = "WhatsApp aaye to Maya khud bataye — sirf jab wo khaali ho, beech mein kabhi nahi",
                    checked = messageAlerts,
                    onChange = { viewModel.setMessageAlerts(it) }
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }) { Text("System settings mein Notification access do") }
                Text(
                    "Pehle yahan se Notification access ON karo, warna auto-reply kaam nahi karega.",
                    fontSize = 12.sp, color = MayaColors.TextMuted
                )
            }
        }

        // ---- Appearance (v7) ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Appearance", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                for (option in listOf("Pink", "Blue", "Purple")) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = accent == option, onClick = { viewModel.setAccent(option) })
                            .padding(vertical = 6.dp)
                    ) {
                        RadioButton(selected = accent == option, onClick = { viewModel.setAccent(option) })
                        Text(option, fontSize = 15.sp, color = MayaColors.TextDark)
                    }
                }
            }
        }

        // ---- Backup (v7) ----
        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Backup", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Text(
                    "Chat, yaadein aur tasks ka ek JSON file Downloads mein save hoti hai.",
                    fontSize = 13.sp, color = MayaColors.TextBody
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = {
                    viewModel.backup { _, msg -> backupMsg = msg }
                }) { Text("Backup lo") }
                if (backupMsg.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(backupMsg, fontSize = 13.sp, color = MayaColors.TextBody)
                }
            }
        }

        Text(
            "Maya v5.2.60 (build 10) • by The Hunter AI",
            fontSize = 12.sp,
            color = MayaColors.TextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 8.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MayaColors.TextDark)
            Text(subtitle, fontSize = 13.sp, color = MayaColors.TextBody)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingsLink(title: String, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 10.dp)
    ) {
        Text(title, fontSize = 15.sp, color = MayaColors.TextDark, modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MayaColors.TextMuted)
    }
}
