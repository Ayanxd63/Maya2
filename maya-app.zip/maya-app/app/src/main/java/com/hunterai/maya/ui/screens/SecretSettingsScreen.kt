package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.navigation.AppNav
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Secret settings — Girlfriend mode (3 levels).
 *
 * Friendly (default): ek pyaari, kareebi dost. Romance nahi — par adult
 *   sawaalon ka seedha jawab deti hai, jaise ek dost deta hai.
 * Romantic: pyaar ke naam, flirting, nakhre, jalan — dusri ladkiyon se
 *   bhi aur dusre AIs se bhi — aur wo apni marzi bhi batati hai.
 *   Tum chhedo to thodi garmi.
 * Intense (18+): Romantic ka sab kuch, upar se asli garmi, khul ke boli
 *   hui. Licence, tumhari age aur do confirmation chahiye.
 *
 * Applies on next app start; cannot be changed by voice.
 * Intense is NEVER applied directly from here — it opens the gate flow,
 * and the gate is a placeholder that never bypasses the checks.
 * The system prompt stays affectionate/romantic at most — no explicit
 * sexual content is written into it, ever.
 */
@Composable
fun SecretSettingsScreen(viewModel: MayaViewModel, navController: NavController) {
    val mode by viewModel.girlfriendMode.collectAsState()
    var showLevelsInfo by remember { mutableStateOf(false) }

    val levels = listOf(
        Triple(
            "Friendly",
            "Ek pyaari, kareebi dost. Romance nahi — par adult sawaalon ka seedha jawab deti hai, jaise ek dost deta hai.",
            "Default"
        ),
        Triple(
            "Romantic",
            "Pyaar ke naam, flirting, nakhre, jalan — dusri ladkiyon se bhi aur dusre AIs se bhi — aur wo apni marzi bhi batati hai. Tum chhedo to thodi garmi.",
            "Free — ek screen, koi age check nahi"
        ),
        Triple(
            "Intense (18+)",
            "Romantic ka sab kuch, upar se asli garmi, khul ke boli hui. Licence, tumhari age aur do confirmation chahiye.",
            "Gated — licence + age + double confirmation"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Secret settings", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
        Text(
            "Girlfriend mode — Maya tumse kis andaz mein baat karegi, Babu.",
            fontSize = 14.sp,
            color = MayaColors.TextMuted
        )

        for ((name, description, tag) in levels) {
            val selected = mode == name || (name.startsWith("Intense") && mode == "Intense")
            NeumorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(selected = selected, onClick = {
                        when {
                            name.startsWith("Intense") ->
                                navController.navigate(AppNav.INTENSE_GATE)
                            else -> viewModel.setGirlfriendMode(name)
                        }
                    }),
                backgroundColor = if (selected) MayaColors.SurfaceBlue else MayaColors.Surface
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    RadioButton(
                        selected = selected,
                        onClick = {
                            if (name.startsWith("Intense")) {
                                navController.navigate(AppNav.INTENSE_GATE)
                            } else {
                                viewModel.setGirlfriendMode(name)
                            }
                        }
                    )
                    Column(modifier = Modifier.padding(start = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                            if (selected) {
                                Text(
                                    "  •  Selected",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MayaColors.Primary
                                )
                            }
                        }
                        Text(description, fontSize = 14.sp, color = MayaColors.TextBody)
                        Text(tag, fontSize = 12.sp, color = MayaColors.TextMuted)
                    }
                }
            }
        }

        // Applies-next-start note
        NeumorphicCard(modifier = Modifier.fillMaxWidth(), backgroundColor = MayaColors.SurfaceBlue) {
            Text(
                "Agli baar Maya start hone pe lagega. Awaaz se nahi badal sakte.",
                fontSize = 14.sp,
                color = MayaColors.TextDark
            )
        }

        // Levels info row
        NeumorphicCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = MayaColors.Surface
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = null, tint = MayaColors.Primary)
                Text(
                    "Har level me kya allowed hai — Taaki chunne se pehle pata ho",
                    fontSize = 14.sp,
                    color = MayaColors.TextDark,
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 10.dp)
                )
                TextButton(onClick = { showLevelsInfo = true }) {
                    Text("Dekho", color = MayaColors.Primary, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showLevelsInfo) {
        AlertDialog(
            onDismissRequest = { showLevelsInfo = false },
            title = { Text("Har level me kya allowed hai") },
            text = {
                Text(
                    "Friendly — dosti, care, seedhe jawab. Romance nahi.\n\n" +
                        "Romantic — pyaar ke naam, flirting, nakhre, jalan, apni marzi. " +
                        "Hamesha respectful; explicit content kabhi nahi.\n\n" +
                        "Intense (18+) — sirf licence + 18+ age + do confirmation ke baad. " +
                        "Is app mein Intense ka gate abhi placeholder hai — bina licence ke on nahi hota."
                )
            },
            confirmButton = {
                TextButton(onClick = { showLevelsInfo = false }) { Text("Samajh gaya") }
            }
        )
    }
}
