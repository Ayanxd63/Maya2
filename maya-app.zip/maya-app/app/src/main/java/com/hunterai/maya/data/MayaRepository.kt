package com.hunterai.maya.data

import android.content.Context
import com.hunterai.maya.data.network.GeminiApi
import com.hunterai.maya.data.network.GeminiRequest
import com.hunterai.maya.data.network.WeatherApi
import com.hunterai.maya.data.network.WeatherResponse
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * Single place for all data work: chat history, memories, tasks,
 * Gemini replies and weather. No API key is stored here — the key is
 * passed in per call from SettingsStore (user-entered in Settings).
 */
class MayaRepository(
    private val database: AppDatabase,
    private val settingsStore: SettingsStore,
    private val geminiApi: GeminiApi,
    private val weatherApi: WeatherApi
) {

    val messages: Flow<List<ChatMessage>> =
        database.chatDao().getAll().map { list ->
            list.map { ChatMessage(it.role, it.text) }
        }

    val memories: Flow<List<MemoryEntity>> = database.memoryDao().getAll()
    val tasks: Flow<List<TaskEntity>> = database.taskDao().getAll()

    suspend fun seedDefaultTasksIfNeeded() {
        database.taskDao().insertAll(AppDatabase.defaultTasks())
    }

    suspend fun addMessage(role: String, text: String) {
        database.chatDao().insert(ChatMessageEntity(role = role, text = text))
    }

    suspend fun clearChat() {
        database.chatDao().clearAll()
    }

    suspend fun saveMemory(text: String, category: String = "yaad") {
        database.memoryDao().insert(MemoryEntity(text = text, category = category))
    }

    suspend fun deleteMemory(memory: MemoryEntity) {
        database.memoryDao().delete(memory)
    }

    /**
     * Ask Gemini. Returns the reply text, or null on any failure
     * (no key, no network, API error) — the caller falls back to an
     * offline loving reply instead of crashing.
     */
    suspend fun askGemini(
        apiKey: String,
        systemPrompt: String,
        history: List<ChatMessage>,
        userText: String
    ): String? {
        if (apiKey.isBlank()) return null
        return try {
            val contents = (history.takeLast(10).map {
                GeminiRequest.Content(
                    role = if (it.role == "maya") "model" else "user",
                    parts = listOf(GeminiRequest.Part(it.text))
                )
            } + GeminiRequest.Content(
                role = "user",
                parts = listOf(GeminiRequest.Part(userText))
            ))
            val request = GeminiRequest(
                systemInstruction = GeminiRequest.SystemInstruction(
                    parts = listOf(GeminiRequest.Part(systemPrompt))
                ),
                contents = contents
            )
            val response = geminiApi.generateContent(apiKey, request)
            response.candidates
                ?.firstOrNull()
                ?.content?.parts?.firstOrNull()?.text
        } catch (e: Exception) {
            null
        }
    }

    /** Free keyless weather (Open-Meteo). Default: New Delhi area. */
    suspend fun getWeather(latitude: Double = 28.61, longitude: Double = 77.20): WeatherResponse? {
        return try {
            weatherApi.getCurrentWeather(latitude, longitude)
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        /** Reads the bundled Maya persona prompt from assets. */
        fun loadSystemPrompt(context: Context): String {
            return try {
                context.assets.open("maya_system_prompt.md")
                    .bufferedReader()
                    .use { it.readText() }
            } catch (e: Exception) {
                "You are Maya, a loving Hindi/Urdu AI girlfriend-style companion. " +
                    "Call the user Babu. Reply in Hinglish, never full English sentences."
            }
        }
    }
}
