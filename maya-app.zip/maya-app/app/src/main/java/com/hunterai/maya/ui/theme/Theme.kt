package com.hunterai.maya.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = MayaColors.Primary,
    onPrimary = MayaColors.TextOnPrimary,
    primaryContainer = MayaColors.SurfaceBlue,
    onPrimaryContainer = MayaColors.PrimaryDeep,
    secondary = MayaColors.PinkDeep,
    onSecondary = Color.White,
    tertiary = MayaColors.Pink,
    background = MayaColors.Background,
    onBackground = MayaColors.TextDark,
    surface = MayaColors.Surface,
    onSurface = MayaColors.TextDark,
    surfaceVariant = MayaColors.BackgroundSoft,
    onSurfaceVariant = MayaColors.TextMuted,
    outline = MayaColors.Divider,
    error = MayaColors.Error
)

private val DarkColors = darkColorScheme(
    primary = MayaColors.PrimaryLight,
    onPrimary = MayaColors.PrimaryDeep,
    primaryContainer = MayaColors.PrimaryDeep,
    onPrimaryContainer = MayaColors.SurfaceBlue,
    secondary = MayaColors.Pink,
    background = Color(0xFF10182E),
    onBackground = Color(0xFFE8EEF9),
    surface = Color(0xFF182238),
    onSurface = Color(0xFFE8EEF9),
    surfaceVariant = Color(0xFF22304F),
    onSurfaceVariant = Color(0xFF9FB2D6),
    outline = Color(0xFF33456B),
    error = Color(0xFFFF8A80)
)

@Composable
fun MayaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
