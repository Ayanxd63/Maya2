package com.hunterai.maya.data.network

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Free keyless weather from Open-Meteo (https://open-meteo.com).
 * No account, no key. Used for the "Mausam" card on Home.
 */
interface WeatherApi {

    @GET("v1/forecast?current=temperature_2m,relative_humidity_2m,weather_code&timezone=auto")
    suspend fun getCurrentWeather(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double
    ): WeatherResponse

    companion object {
        private const val BASE_URL = "https://api.open-meteo.org/"

        fun create(): WeatherApi {
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(WeatherApi::class.java)
        }
    }
}

data class WeatherResponse(
    val current: Current?
) {
    data class Current(
        @SerializedName("temperature_2m") val temperature: Double?,
        @SerializedName("relative_humidity_2m") val humidity: Int?,
        @SerializedName("weather_code") val weatherCode: Int?
    )
}
