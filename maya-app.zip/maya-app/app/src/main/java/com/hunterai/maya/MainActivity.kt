package com.hunterai.maya

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.hunterai.maya.ui.navigation.AppNav
import com.hunterai.maya.ui.screens.ChatScreen
import com.hunterai.maya.ui.screens.ConnectorsScreen
import com.hunterai.maya.ui.screens.HomeScreen
import com.hunterai.maya.ui.screens.IntenseGateScreen
import com.hunterai.maya.ui.screens.MemoryScreen
import com.hunterai.maya.ui.screens.PlaceholderScreen
import com.hunterai.maya.ui.screens.SecretSettingsScreen
import com.hunterai.maya.ui.screens.SettingsScreen
import com.hunterai.maya.ui.screens.SplashScreen
import com.hunterai.maya.ui.screens.UpgradeScreen
import com.hunterai.maya.ui.screens.VoiceEngineScreen
import com.hunterai.maya.ui.screens.VoicePickerScreen
import com.hunterai.maya.ui.screens.VoiceScreen
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.MayaTheme
import com.hunterai.maya.viewmodel.MayaViewModel
import com.hunterai.maya.viewmodel.MayaViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MayaTheme {
                val app = application as MayaApp
                val viewModel: MayaViewModel = viewModel(
                    factory = MayaViewModelFactory(app)
                )
                MayaRoot(viewModel)
            }
        }
    }
}

private data class DrawerItem(
    val title: String,
    val icon: ImageVector,
    val route: String? = null,       // null = opens placeholder screen
    val placeholderTitle: String? = null
)

private val drawerSections: List<Pair<String, List<DrawerItem>>> = listOf(
    "HOME" to listOf(
        DrawerItem("Home", Icons.Default.Home, AppNav.HOME),
        DrawerItem("Maya Home", Icons.Default.Home, AppNav.HOME)
    ),
    "KAAM-KAAJ" to listOf(
        DrawerItem("Markets", Icons.Default.TrendingUp, placeholderTitle = "Markets"),
        DrawerItem("Marketing", Icons.Default.Storefront, placeholderTitle = "Marketing"),
        DrawerItem("Documents", Icons.Default.Description, placeholderTitle = "Documents"),
        DrawerItem("Meri photos", Icons.Default.PhotoLibrary, placeholderTitle = "Meri photos"),
        DrawerItem("Website / Coding", Icons.Default.Code, placeholderTitle = "Website / Coding"),
        DrawerItem("Terminal", Icons.Default.Terminal, placeholderTitle = "Terminal"),
        DrawerItem("Browser", Icons.Default.Public, placeholderTitle = "Browser"),
        DrawerItem("Accessibility", Icons.Default.Accessibility, placeholderTitle = "Accessibility")
    ),
    "SYSTEM" to listOf(
        DrawerItem("Settings", Icons.Default.Settings, AppNav.SETTINGS),
        DrawerItem("Maya ke rules", Icons.Default.Shield, placeholderTitle = "Maya ke rules"),
        DrawerItem("PC ⇌ Phone", Icons.Default.Sync, placeholderTitle = "PC ⇌ Phone")
    ),
    "AUR" to listOf(
        DrawerItem("Privacy Policy", Icons.Default.Lock, placeholderTitle = "Privacy Policy"),
        DrawerItem("About", Icons.Default.Home, placeholderTitle = "About"),
        DrawerItem("Upgrade", Icons.Default.Star, AppNav.UPGRADE),
        DrawerItem("Notifications", Icons.Default.Notifications, placeholderTitle = "Notifications")
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MayaRoot(viewModel: MayaViewModel) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AppNav.SPLASH
    val showChrome = currentRoute != AppNav.SPLASH

    if (currentRoute == AppNav.SPLASH) {
        SplashScreen(onFinished = {
            navController.navigate(AppNav.HOME) {
                popUpTo(AppNav.SPLASH) { inclusive = true }
            }
        })
        return
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MayaColors.BackgroundSoft,
                drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    // Brand header
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(MayaColors.Primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "M",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "Maya",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MayaColors.TextDark
                            )
                            Text(
                                "by The Hunter AI",
                                fontSize = 13.sp,
                                color = MayaColors.TextMuted
                            )
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    for ((section, items) in drawerSections) {
                        Text(
                            section,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MayaColors.TextMuted,
                            modifier = Modifier.padding(start = 8.dp, bottom = 6.dp, top = 10.dp)
                        )
                        for (item in items) {
                            val selected = item.route == currentRoute
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (selected) MayaColors.Primary else Color.Transparent
                                    )
                                    .clickable {
                                        scope.launch { drawerState.close() }
                                        when {
                                            item.route != null -> navController.navigate(item.route) {
                                                launchSingleTop = true
                                            }
                                            item.placeholderTitle != null ->
                                                navController.navigate(
                                                    AppNav.placeholder(item.placeholderTitle)
                                                )
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    item.icon,
                                    contentDescription = item.title,
                                    tint = if (selected) Color.White else MayaColors.Primary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(14.dp))
                                Text(
                                    item.title,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (selected) Color.White else MayaColors.TextDark
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "v5.2.60  •  The Hunter AI",
                        fontSize = 12.sp,
                        color = MayaColors.TextMuted,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = MayaColors.Background,
            topBar = {
                if (showChrome) {
                    TopAppBar(
                        title = {
                            Text(
                                "Maya",
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                color = MayaColors.TextDark
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Menu,
                                        contentDescription = "Menu",
                                        tint = MayaColors.TextDark
                                    )
                                }
                            }
                        },
                        actions = {
                            IconButton(onClick = {
                                navController.navigate(AppNav.placeholder("Notifications"))
                            }) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box {
                                        Icon(
                                            Icons.Default.Notifications,
                                            contentDescription = "Notifications",
                                            tint = MayaColors.TextDark
                                        )
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .size(9.dp)
                                                .clip(CircleShape)
                                                .background(MayaColors.PinkDeep)
                                        )
                                    }
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MayaColors.Background
                        )
                    )
                }
            },
            bottomBar = {
                if (currentRoute in AppNav.MAIN_ROUTES) {
                    MayaBottomBar(navController, currentRoute)
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = AppNav.SPLASH
                ) {
                    composable(AppNav.SPLASH) {
                        SplashScreen(onFinished = {
                            navController.navigate(AppNav.HOME) {
                                popUpTo(AppNav.SPLASH) { inclusive = true }
                            }
                        })
                    }
                    composable(AppNav.HOME) { HomeScreen(viewModel, navController) }
                    composable(AppNav.CHAT) { ChatScreen(viewModel, navController) }
                    composable(AppNav.VOICE) { VoiceScreen(viewModel, navController) }
                    composable(AppNav.MEMORY) { MemoryScreen(viewModel, navController) }
                    composable(AppNav.SETTINGS) { SettingsScreen(viewModel, navController) }
                    composable(AppNav.UPGRADE) { UpgradeScreen(viewModel, navController) }
                    composable(AppNav.SECRET_SETTINGS) { SecretSettingsScreen(viewModel, navController) }
                    composable(AppNav.INTENSE_GATE) { IntenseGateScreen(viewModel, navController) }
                    composable(AppNav.VOICE_PICKER) { VoicePickerScreen(viewModel, navController) }
                    composable(AppNav.VOICE_ENGINE) { VoiceEngineScreen(viewModel, navController) }
                    composable(AppNav.CONNECTORS) { ConnectorsScreen(viewModel, navController) }
                    composable(AppNav.PLACEHOLDER) { backStack ->
                        val title = backStack.arguments?.getString("title") ?: "Maya"
                        PlaceholderScreen(title = title, navController = navController)
                    }
                }
            }
        }
    }
}

@Composable
private fun MayaBottomBar(navController: NavController, currentRoute: String) {
    NavigationBar(
        containerColor = MayaColors.Surface,
        tonalElevation = 8.dp
    ) {
        val itemColors = NavigationBarItemDefaults.colors(
            selectedIconColor = MayaColors.Primary,
            selectedTextColor = MayaColors.Primary,
            unselectedIconColor = MayaColors.TextMuted,
            unselectedTextColor = MayaColors.TextMuted,
            indicatorColor = MayaColors.SurfaceBlue
        )
        NavigationBarItem(
            selected = currentRoute == AppNav.HOME,
            onClick = { navController.navigate(AppNav.HOME) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home") },
            colors = itemColors
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(AppNav.placeholder("Scan")) },
            icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan") },
            label = { Text("Scan") },
            colors = itemColors
        )
        // Centre mic — highlighted, like the reference design
        NavigationBarItem(
            selected = currentRoute == AppNav.VOICE,
            onClick = { navController.navigate(AppNav.VOICE) { launchSingleTop = true } },
            icon = {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(MayaColors.Primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = "Bolo",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            label = { Text("") },
            colors = itemColors
        )
        NavigationBarItem(
            selected = currentRoute == AppNav.MEMORY,
            onClick = { navController.navigate(AppNav.MEMORY) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.History, contentDescription = "Yaadein") },
            label = { Text("Yaadein") },
            colors = itemColors
        )
        NavigationBarItem(
            selected = currentRoute == AppNav.CHAT,
            onClick = { navController.navigate(AppNav.CHAT) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.ChatBubble, contentDescription = "Chat") },
            label = { Text("Chat") },
            colors = itemColors
        )
    }
}
