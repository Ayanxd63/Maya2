package com.hunterai.maya

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.hunterai.maya.data.CrashLog
import com.hunterai.maya.ui.navigation.AppNav
import com.hunterai.maya.ui.screens.ActionsScreen
import com.hunterai.maya.ui.screens.AdvancedSettingsScreen
import com.hunterai.maya.ui.screens.ChatScreen
import com.hunterai.maya.ui.screens.ConnectorsScreen
import com.hunterai.maya.ui.screens.CrashReportScreen
import com.hunterai.maya.ui.screens.HomeScreen
import com.hunterai.maya.ui.screens.IntenseGateScreen
import com.hunterai.maya.ui.screens.MayaHomeScreen
import com.hunterai.maya.ui.screens.MemoryScreen
import com.hunterai.maya.ui.screens.PlaceholderScreen
import com.hunterai.maya.ui.screens.SecretSettingsScreen
import com.hunterai.maya.ui.screens.SettingsScreen
import com.hunterai.maya.ui.screens.SetupScreen
import com.hunterai.maya.ui.screens.SkillsScreen
import com.hunterai.maya.ui.screens.SplashScreen
import com.hunterai.maya.ui.screens.SubAgentsScreen
import com.hunterai.maya.ui.screens.UpgradeScreen
import com.hunterai.maya.ui.screens.VoiceEngineScreen
import com.hunterai.maya.ui.screens.VoiceGuardianScreen
import com.hunterai.maya.ui.screens.VoicePickerScreen
import com.hunterai.maya.ui.screens.VoiceScreen
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.MayaTheme
import com.hunterai.maya.viewmodel.MayaViewModel
import com.hunterai.maya.viewmodel.MayaViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val app = application as MayaApp
            val viewModel: MayaViewModel = viewModel(
                factory = MayaViewModelFactory(app)
            )
            val accent by viewModel.accent.collectAsState()
            MayaTheme(accentName = accent) {
                MayaRoot(viewModel)
            }
        }
    }
}

private data class DrawerItem(
    val title: String,
    val icon: ImageVector,
    val route: String? = null,       // null = opens placeholder screen
    val placeholderTitle: String? = null
)

private val drawerSections: List<Pair<String, List<DrawerItem>>> = listOf(
    "HOME" to listOf(
        DrawerItem("Home", Icons.Default.Home, AppNav.HOME),
        DrawerItem("Maya Home", Icons.Default.Home, AppNav.MAYA_HOME)
    ),
    "KAAM-KAAJ" to listOf(
        DrawerItem("Markets", Icons.Default.TrendingUp, placeholderTitle = "Markets"),
        DrawerItem("Marketing", Icons.Default.Storefront, placeholderTitle = "Marketing"),
        DrawerItem("Documents", Icons.Default.Description, placeholderTitle = "Documents"),
        DrawerItem("Meri photos", Icons.Default.PhotoLibrary, placeholderTitle = "Meri photos"),
        DrawerItem("Website / Coding", Icons.Default.Code, placeholderTitle = "Website / Coding"),
        DrawerItem("Terminal", Icons.Default.Terminal, placeholderTitle = "Terminal"),
        DrawerItem("Browser", Icons.Default.Public, placeholderTitle = "Browser"),
        DrawerItem("Actions", Icons.Default.PlayArrow, AppNav.ACTIONS),
        DrawerItem("Skills", Icons.Default.Star, AppNav.SKILLS),
        DrawerItem("Sub-agents", Icons.Default.Code, AppNav.SUB_AGENTS),
        DrawerItem("Accessibility", Icons.Default.Accessibility, placeholderTitle = "Accessibility")
    ),
    "SYSTEM" to listOf(
        DrawerItem("Settings", Icons.Default.Settings, AppNav.SETTINGS),
        DrawerItem("Setup dobara", Icons.Default.Tune, AppNav.SETUP),
        DrawerItem("Voice Guardian", Icons.Default.Shield, AppNav.VOICE_GUARDIAN),
        DrawerItem("Advanced", Icons.Default.Tune, AppNav.ADVANCED),
        DrawerItem("Maya ke rules", Icons.Default.Shield, placeholderTitle = "Maya ke rules"),
        DrawerItem("PC ⇌ Phone", Icons.Default.Sync, placeholderTitle = "PC ⇌ Phone")
    ),
    "AUR" to listOf(
        DrawerItem("Privacy Policy", Icons.Default.Lock, placeholderTitle = "Privacy Policy"),
        DrawerItem("About", Icons.Default.Home, placeholderTitle = "About"),
        DrawerItem("Upgrade", Icons.Default.Star, AppNav.UPGRADE),
        DrawerItem("Notifications", Icons.Default.Notifications, placeholderTitle = "Notifications")
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MayaRoot(viewModel: MayaViewModel) {
    val context = LocalContext.current
    // If a previous run crashed, show the saved crash report first so the
    // user can share the exact reason instead of crashing silently again.
    var crashLog by remember { mutableStateOf(CrashLog.read(context)) }
    if (crashLog != null) {
        CrashReportScreen(
            trace = crashLog!!,
            onShare = {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, crashLog)
                    putExtra(Intent.EXTRA_SUBJECT, "Maya crash log")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(intent, "Crash log share karo"))
            },
            onContinue = {
                CrashLog.clear(context)
                crashLog = null
            }
        )
        return
    }

    // Face Lock — biometric / device-credential gate on every launch (v7).
    val faceLock by viewModel.faceLock.collectAsState()
    var faceUnlocked by remember { mutableStateOf(false) }
    if (faceLock && !faceUnlocked) {
        FaceLockScreen(
            onUnlock = { faceUnlocked = true },
            onDisable = {
                viewModel.setFaceLock(false)
                faceUnlocked = true
            }
        )
        return
    }

    // Touch Guard — lock overlay, long-press to unlock for this session (v7).
    val touchGuard by viewModel.touchGuard.collectAsState()
    var guardLocked by remember(touchGuard) { mutableStateOf(touchGuard) }

    val setupDone by viewModel.setupDone.collectAsState()
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AppNav.SPLASH
    val showChrome = currentRoute != AppNav.SPLASH && currentRoute != AppNav.SETUP

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MayaColors.BackgroundSoft,
                drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    // Brand header
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(MayaColors.Primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "M",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "Maya",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MayaColors.TextDark
                            )
                            Text(
                                "by The Hunter AI",
                                fontSize = 13.sp,
                                color = MayaColors.TextMuted
                            )
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    for ((section, items) in drawerSections) {
                        Text(
                            section,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MayaColors.TextMuted,
                            modifier = Modifier.padding(start = 8.dp, bottom = 6.dp, top = 10.dp)
                        )
                        for (item in items) {
                            val selected = item.route == currentRoute
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (selected) MayaColors.Primary else Color.Transparent
                                    )
                                    .clickable {
                                        scope.launch { drawerState.close() }
                                        when {
                                            item.route != null -> navController.navigate(item.route) {
                                                launchSingleTop = true
                                            }
                                            item.placeholderTitle != null ->
                                                navController.navigate(
                                                    AppNav.placeholder(item.placeholderTitle)
                                                )
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    item.icon,
                                    contentDescription = item.title,
                                    tint = if (selected) Color.White else MayaColors.Primary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(14.dp))
                                Text(
                                    item.title,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (selected) Color.White else MayaColors.TextDark
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "v5.2.60 (build 10)  •  The Hunter AI",
                        fontSize = 12.sp,
                        color = MayaColors.TextMuted,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = MayaColors.Background,
            topBar = {
                if (showChrome) {
                    TopAppBar(
                        title = {
                            Text(
                                "Maya",
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                color = MayaColors.TextDark
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Menu,
                                        contentDescription = "Menu",
                                        tint = MayaColors.TextDark
                                    )
                                }
                            }
                        },
                        actions = {
                            IconButton(onClick = {
                                navController.navigate(AppNav.placeholder("Notifications"))
                            }) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box {
                                        Icon(
                                            Icons.Default.Notifications,
                                            contentDescription = "Notifications",
                                            tint = MayaColors.TextDark
                                        )
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .size(9.dp)
                                                .clip(CircleShape)
                                                .background(MayaColors.PinkDeep)
                                        )
                                    }
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MayaColors.Background
                        )
                    )
                }
            },
            bottomBar = {
                if (currentRoute in AppNav.MAIN_ROUTES) {
                    MayaBottomBar(navController, currentRoute)
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = AppNav.SPLASH
                ) {
                    // v7 crash fix: the splash is a NavHost destination now, so
                    // navigate() is only ever called AFTER the NavHost exists
                    // and has a graph. (v5 called navigate() before any NavHost
                    // was composed — no graph — and crashed at splash end.)
                    composable(AppNav.SPLASH) {
                        SplashScreen(onFinished = {
                            val next = if (setupDone) AppNav.HOME else AppNav.SETUP
                            navController.navigate(next) {
                                popUpTo(AppNav.SPLASH) { inclusive = true }
                            }
                        })
                    }
                    composable(AppNav.SETUP) { SetupScreen(viewModel, navController) }
                    composable(AppNav.ACTIONS) { ActionsScreen(viewModel, navController) }
                    composable(AppNav.HOME) { HomeScreen(viewModel, navController) }
                    composable(AppNav.CHAT) { ChatScreen(viewModel, navController) }
                    composable(AppNav.VOICE) { VoiceScreen(viewModel, navController) }
                    composable(AppNav.MEMORY) { MemoryScreen(viewModel, navController) }
                    composable(AppNav.SETTINGS) { SettingsScreen(viewModel, navController) }
                    composable(AppNav.UPGRADE) { UpgradeScreen(viewModel, navController) }
                    composable(AppNav.SECRET_SETTINGS) { SecretSettingsScreen(viewModel, navController) }
                    composable(AppNav.INTENSE_GATE) { IntenseGateScreen(viewModel, navController) }
                    composable(AppNav.VOICE_PICKER) { VoicePickerScreen(viewModel, navController) }
                    composable(AppNav.VOICE_ENGINE) { VoiceEngineScreen(viewModel, navController) }
                    composable(AppNav.CONNECTORS) { ConnectorsScreen(viewModel, navController) }
                    composable(AppNav.SKILLS) { SkillsScreen(viewModel, navController) }
                    composable(AppNav.SUB_AGENTS) { SubAgentsScreen(viewModel, navController) }
                    composable(AppNav.VOICE_GUARDIAN) { VoiceGuardianScreen(viewModel, navController) }
                    composable(AppNav.MAYA_HOME) { MayaHomeScreen(viewModel, navController) }
                    composable(AppNav.ADVANCED) { AdvancedSettingsScreen(viewModel, navController) }
                    composable(AppNav.PLACEHOLDER) { backStack ->
                        val title = backStack.arguments?.getString("title") ?: "Maya"
                        PlaceholderScreen(title = title, navController = navController)
                    }
                }
            }
        }
    }

    if (guardLocked) {
        TouchGuardOverlay(viewModel = viewModel, onUnlock = { guardLocked = false })
    }
}

/** Touch Guard overlay — long-press to unlock, or (God Mode) voice only. */
@Composable
private fun TouchGuardOverlay(viewModel: MayaViewModel, onUnlock: () -> Unit) {
    val godMode by viewModel.godMode.collectAsState()
    val recognizeVoice by viewModel.recognizeVoice.collectAsState()
    var status by remember { mutableStateOf("") }
    // God Mode: only your voice can unlock (long-press is disabled).
    val voiceOnly = godMode && recognizeVoice
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .pointerInput(voiceOnly) {
                if (!voiceOnly) {
                    detectTapGestures(onLongPress = { onUnlock() })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Icon(
                Icons.Default.Lock,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(56.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Touch Guard on hai",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(Modifier.height(8.dp))
            if (voiceOnly) {
                Text(
                    "God Mode on hai — sirf tumhari awaz khol sakti hai. 'Maya' bolo, Babu.",
                    fontSize = 15.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
                Button(onClick = {
                    status = "Sun rahi hoon — 'Maya' bolo..."
                    viewModel.unlockWithVoice { ok ->
                        if (ok) onUnlock()
                        else status = "Pehchan nahi hui — phir try karo, Babu."
                    }
                }) { Text("Voice se kholo") }
                if (status.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(status, fontSize = 14.sp, color = Color.White, textAlign = TextAlign.Center)
                }
            } else {
                Text(
                    "Unlock karne ke liye screen ko der tak dabaye rakho (long-press), Babu.",
                    fontSize = 15.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/** Face Lock screen — biometric / device-credential gate on app launch. */
@Composable
private fun FaceLockScreen(onUnlock: () -> Unit, onDisable: () -> Unit) {
    val activity = LocalContext.current as FragmentActivity
    var error by remember { mutableStateOf<String?>(null) }
    val authenticators = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
    } else {
        BiometricManager.Authenticators.BIOMETRIC_STRONG
    }
    val canAuth = remember {
        BiometricManager.from(activity).canAuthenticate(authenticators)
    }

    fun showPrompt() {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(
                    result: BiometricPrompt.AuthenticationResult
                ) {
                    onUnlock()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    error = errString.toString()
                }

                override fun onAuthenticationFailed() {
                    error = "Pehchan nahi hui, Babu — phir try karo."
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Maya — Face Lock")
            .setSubtitle("Maya kholne ke liye apni pehchan do, Babu.")
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.Lock,
            contentDescription = null,
            tint = MayaColors.Primary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(20.dp))
        Text(
            "Maya locked hai",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MayaColors.TextDark
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Face Lock on hai — kholne ke liye apni pehchan do, Babu.",
            fontSize = 15.sp,
            color = MayaColors.TextBody,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        if (canAuth == BiometricManager.BIOMETRIC_SUCCESS) {
            Button(onClick = { showPrompt() }, modifier = Modifier.fillMaxWidth()) {
                Text("Unlock karo")
            }
        } else {
            Text(
                "Is phone pe biometric / device lock available nahi hai.",
                fontSize = 14.sp,
                color = MayaColors.TextMuted,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = onUnlock, modifier = Modifier.fillMaxWidth()) {
                Text("Phir bhi kholo")
            }
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, fontSize = 14.sp, color = MayaColors.Error, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onDisable) { Text("Face Lock band karo") }
    }
}

@Composable
private fun MayaBottomBar(navController: NavController, currentRoute: String) {
    NavigationBar(
        containerColor = MayaColors.Surface,
        tonalElevation = 8.dp
    ) {
        val itemColors = NavigationBarItemDefaults.colors(
            selectedIconColor = MayaColors.Primary,
            selectedTextColor = MayaColors.Primary,
            unselectedIconColor = MayaColors.TextMuted,
            unselectedTextColor = MayaColors.TextMuted,
            indicatorColor = MayaColors.SurfaceBlue
        )
        NavigationBarItem(
            selected = currentRoute == AppNav.HOME,
            onClick = { navController.navigate(AppNav.HOME) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home") },
            colors = itemColors
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(AppNav.placeholder("Scan")) },
            icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan") },
            label = { Text("Scan") },
            colors = itemColors
        )
        // Centre mic — highlighted, like the reference design
        NavigationBarItem(
            selected = currentRoute == AppNav.VOICE,
            onClick = { navController.navigate(AppNav.VOICE) { launchSingleTop = true } },
            icon = {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(MayaColors.Primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = "Bolo",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            label = { Text("") },
            colors = itemColors
        )
        NavigationBarItem(
            selected = currentRoute == AppNav.MEMORY,
            onClick = { navController.navigate(AppNav.MEMORY) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.History, contentDescription = "Yaadein") },
            label = { Text("Yaadein") },
            colors = itemColors
        )
        NavigationBarItem(
            selected = currentRoute == AppNav.CHAT,
            onClick = { navController.navigate(AppNav.CHAT) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.ChatBubble, contentDescription = "Chat") },
            label = { Text("Chat") },
            colors = itemColors
        )
    }
}
