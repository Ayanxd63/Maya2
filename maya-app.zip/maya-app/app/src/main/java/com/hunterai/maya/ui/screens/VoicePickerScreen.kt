package com.hunterai.maya.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Awaaz (Voice picker) — "Tap karke suno, phir chuno".
 *
 * Persona tabs: Maya / Friday / Venom / Jarvis. Each voice has a
 * play-preview button and a selected checkmark.
 *
 * Voice IDs are REAL Gemini Live API voice names (see persona_config.json).
 * On-device TTS cannot speak in Gemini Live voices — the preview plays a
 * sample in the phone's hi-IN voice, and the selected NAME is stored for
 * the Gemini Live API call. The code never invents a voice ID.
 */
data class PersonaVoice(val label: String, val voiceId: String, val selectedByDefault: Boolean = false)

private val voicesByPersona: Map<String, List<PersonaVoice>> = mapOf(
    "Maya" to listOf(
        PersonaVoice("Halki-phulki", "Aoede", selectedByDefault = true),
        PersonaVoice("Damdaar", "Kore"),
        PersonaVoice("Jawaan", "Leda"),
        PersonaVoice("Chamakdaar", "Zephyr"),
        PersonaVoice("Josheeli", "Laomedeia"),
        PersonaVoice("Mulaayam", "Despina"),
        PersonaVoice("Saaf", "Erinome")
    ),
    "Friday" to listOf(
        PersonaVoice("Halki-phulki", "Sulafat", selectedByDefault = true),
        PersonaVoice("Gehri", "Umbriel"),
        PersonaVoice("Saaf", "Autonoe"),
        PersonaVoice("Naram", "Sadachbia")
    ),
    "Venom" to listOf(
        PersonaVoice("Khurdari", "Algenib", selectedByDefault = true),
        PersonaVoice("Jaankaari bhari", "Charon"),
        PersonaVoice("Utsaahi", "Fenrir"),
        PersonaVoice("Josheeli", "Puck"),
        PersonaVoice("Damdaar", "Orus"),
        PersonaVoice("Saanson bhari", "Enceladus"),
        PersonaVoice("Saaf", "Iapetus")
    ),
    "Jarvis" to listOf(
        PersonaVoice("Shaant", "Callirrhoe", selectedByDefault = true),
        PersonaVoice("Gehri", "Alnilam"),
        PersonaVoice("Saaf", "Schedar"),
        PersonaVoice("Classic", "Zubenelgenubi")
    )
)

@Composable
fun VoicePickerScreen(viewModel: MayaViewModel, navController: NavController) {
    val selectedVoice by viewModel.voiceName.collectAsState()
    val personas = voicesByPersona.keys.toList()
    var tabIndex by remember { mutableIntStateOf(0) }
    val currentPersona = personas[tabIndex]
    val voices = voicesByPersona[currentPersona].orEmpty()

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text("Awaaz", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Text(
                "Tap karke suno, phir chuno",
                fontSize = 14.sp,
                color = MayaColors.TextMuted
            )
            Spacer(Modifier.height(12.dp))
        }

        TabRow(selectedTabIndex = tabIndex) {
            personas.forEachIndexed { index, persona ->
                Tab(
                    selected = tabIndex == index,
                    onClick = { tabIndex = index },
                    text = { Text(persona) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(voices) { voice ->
                val isSelected = selectedVoice == voice.voiceId
                NeumorphicCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.setVoice(voice.voiceId, currentPersona)
                        },
                    backgroundColor = if (isSelected) MayaColors.SurfaceBlue else MayaColors.Surface,
                    cornerRadius = 20.dp
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.previewVoice(voice.voiceId) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Suno", tint = MayaColors.Primary)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(voice.label, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                            Text(voice.voiceId, fontSize = 12.sp, color = MayaColors.TextMuted)
                        }
                        if (isSelected) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Selected", tint = MayaColors.Primary)
                        }
                    }
                }
            }
            item {
                Text(
                    "Ye Gemini Live API ki asli voice names hain. Phone par preview phone ki hi-IN awaz mein bajta hai — Live API connect hone par chuni hui awaz lagegi.",
                    fontSize = 12.sp,
                    color = MayaColors.TextMuted
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}
