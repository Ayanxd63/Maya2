package com.hunterai.maya.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Maya — pastel blue / white neumorphic palette.
 * Matches the reference screenshots: soft blue-grey background, white cards,
 * deep navy text, blue primary, pink accent for hearts / love states.
 */
object MayaColors {
    // Backgrounds
    val Background = Color(0xFFE7EEF9)
    val BackgroundSoft = Color(0xFFF2F6FD)
    val Surface = Color(0xFFFFFFFF)
    val SurfaceBlue = Color(0xFFDCE8FA)

    // Brand
    val Primary = Color(0xFF4A7DE0)
    val PrimaryLight = Color(0xFF7FA8F0)
    val PrimaryDark = Color(0xFF2F5FBF)
    val PrimaryDeep = Color(0xFF1B3A7A)

    // Accent (hearts, mood, love states)
    val Pink = Color(0xFFFF7EB6)
    val PinkDeep = Color(0xFFE7548A)
    val HeartGlow = Color(0xFFFF9ECF)

    // Text
    val TextDark = Color(0xFF1E2A4A)
    val TextBody = Color(0xFF3A4A6B)
    val TextMuted = Color(0xFF7A8BB0)
    val TextOnPrimary = Color(0xFFFFFFFF)

    // Neumorphic shadows (light source top-left)
    val ShadowLight = Color(0xFFFFFFFF)
    val ShadowDark = Color(0xFFB9C8E2)

    // Orb / voice states
    val OrbCore = Color(0xFFFFC94D)
    val OrbRing = Color(0xFFFF8A9E)
    val OrbGlow = Color(0xFFFF6B8A)
    val Listening = Color(0xFF4ADE80)
    val Thinking = Color(0xFFFBBF24)
    val Speaking = Color(0xFF60A5FA)

    // Status
    val Success = Color(0xFF22C55E)
    val Warning = Color(0xFFF59E0B)
    val Error = Color(0xFFEF4444)
    val Divider = Color(0xFFD7E1F2)

    // Theme accents (Appearance setting — Pink default, Blue, Purple)
    val AccentPink = Color(0xFFFF5CA8)
    val AccentBlue = Color(0xFF4A7DE0)
    val AccentPurple = Color(0xFF8B5CF6)

    /** Accent colour for the given Appearance name ("Pink" / "Blue" / "Purple"). */
    fun accent(name: String): Color = when (name) {
        "Blue" -> AccentBlue
        "Purple" -> AccentPurple
        else -> AccentPink
    }

    // Splash (dark night-blue, like the reference splash screen)
    val NightTop = Color(0xFF0B1030)
    val NightMid = Color(0xFF1B2A6B)
    val NightBottom = Color(0xFF2E4DB0)
    val NeonBlue = Color(0xFF5EC8F2)
    val NeonPink = Color(0xFFFF5CA8)
}
