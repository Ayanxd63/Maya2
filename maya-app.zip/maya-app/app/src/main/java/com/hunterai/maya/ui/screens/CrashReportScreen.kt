package com.hunterai.maya.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard

/**
 * Shown on launch when a previous run crashed: the saved stack trace,
 * a Share button (send it to the developer) and a Continue button
 * (clear the log and open the app normally).
 */
@Composable
fun CrashReportScreen(
    trace: String,
    onShare: () -> Unit,
    onContinue: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Uff Babu, Maya crash ho gayi thi",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MayaColors.TextDark
        )
        Text(
            "Neeche crash ki wajah likhi hai. \"Share karo\" dabakar ye report bhej do — " +
                "main dekh kar theek kar dungi. Phir \"App kholo\" se aage badho.",
            fontSize = 14.sp,
            color = MayaColors.TextBody
        )
        NeumorphicCard(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            cornerRadius = 16.dp
        ) {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    trace,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MayaColors.TextDark
                )
            }
        }
        Button(
            onClick = onShare,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Share karo")
        }
        TextButton(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Clear karke app kholo")
        }
        Spacer(Modifier.height(4.dp))
    }
}
