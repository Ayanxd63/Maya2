package com.hunterai.maya.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "maya_settings")

/**
 * Settings storage (DataStore Preferences).
 * The Gemini API key lives ONLY here, on the user's own phone, entered by
 * the user in Settings. It is never hardcoded, never logged, never synced.
 */
class SettingsStore(private val context: Context) {

    companion object {
        private val KEY_API_KEY = stringPreferencesKey("gemini_api_key")
        private val KEY_PERSONA = stringPreferencesKey("persona")
        private val KEY_GENDER = stringPreferencesKey("gender")
        private val KEY_LANGUAGE = stringPreferencesKey("language")
        private val KEY_AUTO_SAVE = booleanPreferencesKey("auto_save_memory")
        private val KEY_VOICE_PITCH = floatPreferencesKey("voice_pitch")
        private val KEY_VOICE_RATE = floatPreferencesKey("voice_rate")
        private val KEY_PREMIUM = booleanPreferencesKey("is_premium")
        private val KEY_GIRLFRIEND_MODE = stringPreferencesKey("girlfriend_mode")
        private val KEY_VOICE_NAME = stringPreferencesKey("voice_name")
        private val KEY_VOICE_ENGINE = stringPreferencesKey("voice_engine")
        private val KEY_SETUP_DONE = booleanPreferencesKey("setup_done")
        private val KEY_ACCENT = stringPreferencesKey("accent")
        private val KEY_FACE_LOCK = booleanPreferencesKey("face_lock")
        private val KEY_TOUCH_GUARD = booleanPreferencesKey("touch_guard")
        private val KEY_VOICE_GUARDIAN = booleanPreferencesKey("voice_guardian")
        private val KEY_WHATSAPP_AUTO_REPLY = booleanPreferencesKey("whatsapp_auto_reply")

        const val PERSONA_MAYA = "Maya"
        const val PERSONA_FRIDAY = "Friday"
        const val PERSONA_VENOM = "Venom"
        const val PERSONA_JARVIS = "Jarvis"

        const val MODE_FRIENDLY = "Friendly"
        const val MODE_ROMANTIC = "Romantic"
        const val MODE_INTENSE = "Intense"

        const val ENGINE_SWIFT = "Swift"
        const val ENGINE_SOUL = "Soul"
        const val ENGINE_MIND = "Mind"
    }

    val apiKey: Flow<String> = context.settingsDataStore.data.map { it[KEY_API_KEY] ?: "" }
    val persona: Flow<String> = context.settingsDataStore.data.map { it[KEY_PERSONA] ?: PERSONA_MAYA }
    val gender: Flow<String> = context.settingsDataStore.data.map { it[KEY_GENDER] ?: "Prefer not to say" }
    val language: Flow<String> = context.settingsDataStore.data.map { it[KEY_LANGUAGE] ?: "Hindi / Urdu (Hinglish)" }
    val autoSaveMemory: Flow<Boolean> = context.settingsDataStore.data.map { it[KEY_AUTO_SAVE] ?: true }
    val voicePitch: Flow<Float> = context.settingsDataStore.data.map { it[KEY_VOICE_PITCH] ?: 1.1f }
    val voiceRate: Flow<Float> = context.settingsDataStore.data.map { it[KEY_VOICE_RATE] ?: 0.95f }
    val isPremium: Flow<Boolean> = context.settingsDataStore.data.map { it[KEY_PREMIUM] ?: false }

    /** Girlfriend mode — default Friendly. Applies on next app start. */
    val girlfriendMode: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_GIRLFRIEND_MODE] ?: MODE_FRIENDLY }

    /** Selected Gemini Live API voice name (e.g. "Aoede"). */
    val voiceName: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_VOICE_NAME] ?: "Aoede" }

    /** Voice engine — Swift (default), Soul or Mind. */
    val voiceEngine: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_VOICE_ENGINE] ?: ENGINE_SWIFT }

    /** First-run setup done (permissions + key + persona). Default false. */
    val setupDone: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_SETUP_DONE] ?: false }

    /** Appearance accent — "Pink" (default), "Blue" or "Purple". */
    val accent: Flow<String> =
        context.settingsDataStore.data.map { it[KEY_ACCENT] ?: "Pink" }

    /** Face Lock — biometric / device-credential gate on app launch. Default off. */
    val faceLock: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_FACE_LOCK] ?: false }

    /** Touch Guard — lock overlay, long-press to unlock. Default off. */
    val touchGuard: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_TOUCH_GUARD] ?: false }

    /** Voice Guardian — voice sessions only answer after the wake word "Maya". Default off. */
    val voiceGuardian: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_VOICE_GUARDIAN] ?: false }

    /** WhatsApp auto-reply — OFF by default; needs Notification access in system settings. */
    val whatsappAutoReply: Flow<Boolean> =
        context.settingsDataStore.data.map { it[KEY_WHATSAPP_AUTO_REPLY] ?: false }

    suspend fun setApiKey(value: String) {
        context.settingsDataStore.edit { it[KEY_API_KEY] = value }
    }

    suspend fun setPersona(value: String) {
        context.settingsDataStore.edit { it[KEY_PERSONA] = value }
    }

    suspend fun setGender(value: String) {
        context.settingsDataStore.edit { it[KEY_GENDER] = value }
    }

    suspend fun setLanguage(value: String) {
        context.settingsDataStore.edit { it[KEY_LANGUAGE] = value }
    }

    suspend fun setAutoSaveMemory(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_AUTO_SAVE] = value }
    }

    suspend fun setVoicePitch(value: Float) {
        context.settingsDataStore.edit { it[KEY_VOICE_PITCH] = value }
    }

    suspend fun setVoiceRate(value: Float) {
        context.settingsDataStore.edit { it[KEY_VOICE_RATE] = value }
    }

    suspend fun setPremium(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_PREMIUM] = value }
    }

    suspend fun setGirlfriendMode(value: String) {
        context.settingsDataStore.edit { it[KEY_GIRLFRIEND_MODE] = value }
    }

    suspend fun setVoiceName(value: String) {
        context.settingsDataStore.edit { it[KEY_VOICE_NAME] = value }
    }

    suspend fun setVoiceEngine(value: String) {
        context.settingsDataStore.edit { it[KEY_VOICE_ENGINE] = value }
    }

    suspend fun setSetupDone(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_SETUP_DONE] = value }
    }

    suspend fun setAccent(value: String) {
        context.settingsDataStore.edit { it[KEY_ACCENT] = value }
    }

    suspend fun setFaceLock(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_FACE_LOCK] = value }
    }

    suspend fun setTouchGuard(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_TOUCH_GUARD] = value }
    }

    suspend fun setVoiceGuardian(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_VOICE_GUARDIAN] = value }
    }

    suspend fun setWhatsappAutoReply(value: Boolean) {
        context.settingsDataStore.edit { it[KEY_WHATSAPP_AUTO_REPLY] = value }
    }
}
