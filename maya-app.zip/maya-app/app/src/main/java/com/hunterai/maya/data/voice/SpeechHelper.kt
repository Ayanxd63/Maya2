package com.hunterai.maya.data.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Speech in / speech out for Maya.
 * - Listening: Android SpeechRecognizer, language "hi-IN" (Hindi/Urdu).
 * - Speaking: TextToSpeech, locale hi-IN, pitch ~1.1 and rate ~0.95,
 *   preferring a female voice when the device offers one.
 * Voice availability depends on the phone's installed TTS engine
 * (Google TTS usually has hi-IN female voices).
 */
class SpeechHelper(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    var pitch: Float = 1.1f
    var rate: Float = 0.95f

    fun initTts(onReady: () -> Unit = {}) {
        if (tts != null) return
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val locale = Locale("hi", "IN")
                val result = tts?.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    tts?.language = Locale.US
                }
                pickFemaleVoice()
                ttsReady = true
                onReady()
            }
        }
    }

    /** Best-effort female voice pick: prefer a hi-IN voice whose name hints female. */
    private fun pickFemaleVoice() {
        try {
            val voices = tts?.voices ?: return
            val female = voices.firstOrNull { voice ->
                voice.locale.language == "hi" &&
                    (voice.name.contains("female", ignoreCase = true) ||
                        voice.name.contains("femme", ignoreCase = true) ||
                        voice.name.contains("f", ignoreCase = true) &&
                        voice.name.contains("hi", ignoreCase = true))
            } ?: voices.firstOrNull { it.locale.language == "hi" }
            if (female != null) {
                tts?.voice = female
            }
        } catch (e: Exception) {
            // Voice selection is best-effort only.
        }
    }

    fun speak(text: String, onDone: () -> Unit = {}) {
        if (!ttsReady) {
            initTts { speak(text, onDone) }
            return
        }
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { onDone() }
            override fun onError(utteranceId: String?) { onDone() }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maya_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun isListening(): Boolean = recognizer != null

    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition is phone mein available nahi hai, Babu.")
            return
        }
        stopListening()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    onError("Uff Babu, sun nahi payi — ek baar phir bolo na.")
                }
                override fun onResults(results: Bundle?) {
                    val heard = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (heard.isNotBlank()) onResult(heard) else onError("Kuch suna nahi, Babu.")
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(intent)
        }
    }

    fun stopListening() {
        try {
            recognizer?.stopListening()
            recognizer?.destroy()
        } catch (e: Exception) {
            // ignore
        }
        recognizer = null
    }

    fun shutdown() {
        stopListening()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }
}
