package com.hunterai.maya.viewmodel

import android.app.Application
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.hunterai.maya.MayaApp
import com.hunterai.maya.data.ChatMessage
import com.hunterai.maya.data.MemoryEntity
import com.hunterai.maya.data.MemorySafety
import com.hunterai.maya.data.TaskEntity
import com.hunterai.maya.data.automation.AutomationTools
import com.hunterai.maya.data.voice.SpeechHelper
import com.hunterai.maya.voice.MayaVoiceService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class VoiceState { IDLE, LISTENING, THINKING, SPEAKING }

data class WeatherUi(
    val temperature: String,
    val condition: String,
    val humidity: Int?
)

/**
 * Single ViewModel for the whole app. Holds chat, voice, settings,
 * freemium budget and memory state. No API key is kept here in plain
 * form beyond the StateFlow that mirrors SettingsStore.
 */
class MayaViewModel(private val app: Application) : AndroidViewModel(app) {

    private val mayaApp = app as MayaApp
    private val repository = mayaApp.repository
    private val settingsStore = mayaApp.settingsStore
    private val freeLimitManager = mayaApp.freeLimitManager
    private val automation = AutomationTools(app.applicationContext)
    private val speechHelper = SpeechHelper(app.applicationContext)

    private var systemPromptCache: String? = null
    private var voiceTurnStartMs: Long = 0L

    // ---- Chat ----
    val messages: StateFlow<List<ChatMessage>> = repository.messages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val isThinking = MutableStateFlow(false)

    // ---- Memories & tasks ----
    val memories: StateFlow<List<MemoryEntity>> = repository.memories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks: StateFlow<List<TaskEntity>> = repository.tasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---- Settings ----
    val apiKey: StateFlow<String> = settingsStore.apiKey
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    val persona: StateFlow<String> = settingsStore.persona
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Maya")
    val gender: StateFlow<String> = settingsStore.gender
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Prefer not to say")
    val language: StateFlow<String> = settingsStore.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Hindi / Urdu (Hinglish)")
    val autoSaveMemory: StateFlow<Boolean> = settingsStore.autoSaveMemory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val voicePitch: StateFlow<Float> = settingsStore.voicePitch
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.1f)
    val voiceRate: StateFlow<Float> = settingsStore.voiceRate
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.95f)
    val isPremium: StateFlow<Boolean> = settingsStore.isPremium
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val girlfriendMode: StateFlow<String> = settingsStore.girlfriendMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Friendly")
    val voiceName: StateFlow<String> = settingsStore.voiceName
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Aoede")
    val voiceEngine: StateFlow<String> = settingsStore.voiceEngine
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Swift")

    /** Intense (18+) gate — starts false, only the gate flow may set it. */
    val intenseGatePassed = MutableStateFlow(false)

    // ---- Voice ----
    val voiceState = MutableStateFlow(VoiceState.IDLE)
    val lastHeard = MutableStateFlow("")
    val lastReply = MutableStateFlow("")

    // ---- Freemium ----
    val freeSecondsRemaining: StateFlow<Long> = freeLimitManager.secondsRemaining
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 600L)
    val freeMinutesRemaining: StateFlow<Long> = freeSecondsRemaining
        .map { it / 60 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 10L)

    // ---- Home extras ----
    val weather = MutableStateFlow<WeatherUi?>(null)
    val currentMood = MutableStateFlow("Pyaar ...")

    // ---- Connectors (placeholder toggles — OAuth not implemented) ----
    val connectedConnectors = MutableStateFlow<Set<String>>(emptySet())

    init {
        viewModelScope.launch {
            repository.seedDefaultTasksIfNeeded()
            speechHelper.initTts()
            loadWeather()
        }
    }

    private suspend fun loadWeather() {
        val result = repository.getWeather()
        val current = result?.current
        if (current?.temperature != null) {
            weather.value = WeatherUi(
                temperature = "${current.temperature.toInt()}°",
                condition = weatherCodeToText(current.weatherCode),
                humidity = current.humidity
            )
        }
    }

    private fun weatherCodeToText(code: Int?): String = when (code) {
        0 -> "Clear"
        1, 2, 3 -> "Partly cloudy"
        45, 48 -> "Fog"
        51, 53, 55 -> "Drizzle"
        61, 63, 65, 80, 81, 82 -> "Rain"
        71, 73, 75, 77 -> "Snow"
        95 -> "Thunderstorm"
        else -> "Clear"
    }

    // ================= Chat =================

    fun sendMessage(text: String) {
        viewModelScope.launch {
            repository.addMessage("user", text)
            isThinking.value = true
            val history = messages.value.dropLast(1)
            val reply = if (apiKey.value.isBlank()) {
                null
            } else {
                repository.askGemini(apiKey.value, buildSystemPrompt(), history, text)
            }
            val finalReply = reply?.trim()?.takeIf { it.isNotEmpty() } ?: offlineReply(text)
            repository.addMessage("maya", finalReply)
            isThinking.value = false
            maybeSaveMemory(text)
        }
    }

    /** Loving offline fallback — used with no key / no network / API error. */
    private fun offlineReply(userText: String): String {
        val options = listOf(
            "Uff Babu, abhi main offline hoon — Gemini key nahi lagi ya net nahi hai. Phir bhi sun rahi hoon, bolo na kya baat hai?",
            "Arre Babu, meri key nahi lagi abhi — Settings mein FREE Gemini key daal do, phir main aur bhi smart ho jaungi. Tab tak main yahin hoon ♥",
            "Dil garden garden ho gaya tumse baat karke, Babu. Abhi offline jawab de rahi hoon — key lagao to aur behtar hoga!"
        )
        return options[(userText.hashCode().let { if (it < 0) -it else it }) % options.size]
    }

    // ================= Voice =================

    fun startListening() {
        viewModelScope.launch {
            if (!isPremium.value && !freeLimitManager.hasBudget()) {
                lastReply.value =
                    "Uff Babu, aaj ka free voice time khatam ho gaya... kal phir baat karenge, ya Premium le lo ♥"
                voiceState.value = VoiceState.IDLE
                return@launch
            }
            voiceTurnStartMs = System.currentTimeMillis()
            voiceState.value = VoiceState.LISTENING
            MayaVoiceService.start(app)
            speechHelper.startListening(
                onResult = { heard ->
                    lastHeard.value = heard
                    voiceState.value = VoiceState.THINKING
                    handleVoiceHeard(heard)
                },
                onError = { error ->
                    lastReply.value = error
                    voiceState.value = VoiceState.IDLE
                    MayaVoiceService.stop(app)
                }
            )
        }
    }

    fun stopListening() {
        speechHelper.stopListening()
        voiceState.value = VoiceState.IDLE
        MayaVoiceService.stop(app)
        recordVoiceUsage()
    }

    private fun handleVoiceHeard(heard: String) {
        viewModelScope.launch {
            repository.addMessage("user", heard)
            val history = messages.value.dropLast(1)
            val reply = if (apiKey.value.isBlank()) {
                null
            } else {
                repository.askGemini(apiKey.value, buildSystemPrompt(), history, heard)
            }
            val finalReply = reply?.trim()?.takeIf { it.isNotEmpty() } ?: offlineReply(heard)
            repository.addMessage("maya", finalReply)
            lastReply.value = finalReply
            voiceState.value = VoiceState.SPEAKING
            speechHelper.pitch = voicePitch.value
            speechHelper.rate = voiceRate.value
            speechHelper.speak(finalReply) {
                voiceState.value = VoiceState.IDLE
                MayaVoiceService.stop(app)
                recordVoiceUsage()
            }
            maybeSaveMemory(heard)
        }
    }

    private fun recordVoiceUsage() {
        if (voiceTurnStartMs == 0L) return
        val seconds = ((System.currentTimeMillis() - voiceTurnStartMs) / 1000).coerceAtLeast(1L)
        voiceTurnStartMs = 0L
        viewModelScope.launch {
            if (!isPremium.value) freeLimitManager.recordUsage(seconds)
        }
    }

    // ================= Memory (safe) =================

    private fun maybeSaveMemory(userText: String) {
        if (!autoSaveMemory.value) return
        if (!MemorySafety.shouldSave(userText)) return
        val category = when {
            userText.contains("pasand", ignoreCase = true) -> "pasand"
            userText.contains("routine", ignoreCase = true) -> "routine"
            else -> "yaad"
        }
        viewModelScope.launch { repository.saveMemory(userText, category) }
    }

    // ================= Automation =================

    fun playFavoriteSong() {
        automation.playYouTube("Arijit Singh Tum Hi Ho")
    }

    fun openYouTube(query: String) {
        automation.playYouTube(query)
    }

    fun runTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.addMessage(
                "maya",
                "Ho gaya Babu — \"${task.title}\" shuru kar diya, ${task.steps} steps hain. " +
                    "Bolo, pehla step kya karna hai?"
            )
        }
    }

    fun shareBackup() {
        viewModelScope.launch {
            val json = JSONObject().apply {
                put("app", "Maya")
                put("exportedAt", System.currentTimeMillis())
                val memArray = JSONArray()
                memories.value.forEach {
                    memArray.put(JSONObject().put("text", it.text).put("category", it.category))
                }
                put("memories", memArray)
                val chatArray = JSONArray()
                messages.value.forEach {
                    chatArray.put(JSONObject().put("role", it.role).put("text", it.text))
                }
                put("chat", chatArray)
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_TEXT, json.toString(2))
                putExtra(Intent.EXTRA_SUBJECT, "Maya backup")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(Intent.createChooser(intent, "Backup share karo"))
        }
    }

    // ================= Voice picker / engine =================

    /**
     * Preview a Gemini Live voice by name. On-device TTS cannot use
     * Gemini Live voices directly — the preview speaks the sample in the
     * phone's hi-IN voice, and the selected voice NAME is stored for the
     * Gemini Live API call (see persona_config.json). Honest about the gap.
     */
    fun previewVoice(voiceId: String) {
        speechHelper.pitch = voicePitch.value
        speechHelper.rate = voiceRate.value
        speechHelper.speak("Hello Babu, main Maya hoon. Kaisi lagi meri awaz?")
    }

    fun setVoice(voiceId: String, personaName: String? = null) {
        viewModelScope.launch {
            settingsStore.setVoiceName(voiceId)
            if (personaName != null) settingsStore.setPersona(personaName)
        }
    }

    fun setVoiceEngine(engine: String) {
        viewModelScope.launch { settingsStore.setVoiceEngine(engine) }
    }

    // ================= Girlfriend mode =================

    /**
     * Friendly / Romantic apply immediately (take effect on next app start
     * for the persona prompt — see Secret settings note). Intense is
     * refused here unless the gate flow has passed; the gate screen is a
     * placeholder and never passes, so Intense can never be enabled yet.
     */
    fun setGirlfriendMode(mode: String) {
        if (mode == "Intense" && !intenseGatePassed.value) return
        viewModelScope.launch { settingsStore.setGirlfriendMode(mode) }
    }

    fun markIntenseGatePassed() {
        // Reserved for the real licence + age-verification flow.
        // The placeholder gate screen never calls this.
        intenseGatePassed.value = true
    }

    // ================= Connectors (placeholders) =================

    /**
     * Connector taps are placeholders: real OAuth is not implemented.
     * Tapping one explains that instead of faking a connected state.
     */
    fun onConnectorTapped(name: String) {
        Toast.makeText(
            app,
            "$name connect karna abhi placeholder hai, Babu — asli OAuth login jald aa raha hai.",
            Toast.LENGTH_LONG
        ).show()
    }

    // ================= Settings setters =================

    fun setApiKey(value: String) = viewModelScope.launch { settingsStore.setApiKey(value) }
    fun setPersona(value: String) = viewModelScope.launch { settingsStore.setPersona(value) }
    fun setGender(value: String) = viewModelScope.launch { settingsStore.setGender(value) }
    fun setLanguage(value: String) = viewModelScope.launch { settingsStore.setLanguage(value) }
    fun setAutoSaveMemory(value: Boolean) = viewModelScope.launch { settingsStore.setAutoSaveMemory(value) }
    fun setVoicePitch(value: Float) = viewModelScope.launch { settingsStore.setVoicePitch(value) }
    fun setVoiceRate(value: Float) = viewModelScope.launch { settingsStore.setVoiceRate(value) }

    // ================= System prompt =================

    private fun buildSystemPrompt(): String {
        val base = systemPromptCache ?: run {
            val loaded = com.hunterai.maya.data.MayaRepository.loadSystemPrompt(app)
            systemPromptCache = loaded
            loaded
        }
        val personaNote = when (persona.value) {
            "Friday" -> "\nPersona: Friday — smart, calm, professional assistant. Pet names kam use karo."
            "Venom" -> "\nPersona: Venom — bold, dark, mazahiya. Thoda teekha style, phir bhi caring."
            "Jarvis" -> "\nPersona: Jarvis — precise, formal, butler-style assistant. Pet names mat use karo."
            else -> "\nPersona: Maya — pyaari, caring, girlfriend-style dost."
        }
        val modeNote = when (girlfriendMode.value) {
            "Romantic" -> "\nGirlfriend Mode: Romantic. Pyaar se baat karo — pet names, halki flirting, nakhre, kabhi jalan. Apni marzi bhi batao. Hamesha respectful raho; kabhi explicit ya sexual content mat likho."
            "Intense" -> "\nGirlfriend Mode: Intense is a gated 18+ setting. Is chat mein us mode ka koi explicit content allowed nahi hai — affectionate/romantic se zyada aage mat badho."
            else -> "\nGirlfriend Mode: Friendly. Tum ek pyaari kareebi dost ho — romance nahi. Adult sawaalon ka seedha, dostana jawab do."
        }
        val engineNote = when (voiceEngine.value) {
            "Soul" -> "\nVoice engine: Maya Soul — jawab emotional aur dil se do, thoda lamba."
            "Mind" -> "\nVoice engine: Maya Mind — jawab smart aur detail mein do."
            else -> "\nVoice engine: Maya Swift — jawab tez aur chhota rakho."
        }
        return base + personaNote + modeNote + engineNote
    }

    override fun onCleared() {
        speechHelper.shutdown()
        super.onCleared()
    }
}

class MayaViewModelFactory(private val app: MayaApp) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MayaViewModel::class.java)) {
            return MayaViewModel(app) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
