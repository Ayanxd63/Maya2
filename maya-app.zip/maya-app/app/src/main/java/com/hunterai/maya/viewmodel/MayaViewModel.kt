package com.hunterai.maya.viewmodel

import android.app.Application
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import com.hunterai.maya.voice.WhatsAppAutoReplyService
import java.io.File
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.hunterai.maya.MayaApp
import com.hunterai.maya.data.ChatMessage
import com.hunterai.maya.data.CrashLog
import com.hunterai.maya.data.MemoryEntity
import com.hunterai.maya.data.MemorySafety
import com.hunterai.maya.data.TaskEntity
import com.hunterai.maya.data.automation.AutomationTools
import com.hunterai.maya.data.voice.SpeechHelper
import com.hunterai.maya.voice.MayaVoiceService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class VoiceState { IDLE, LISTENING, THINKING, SPEAKING }

data class WeatherUi(
    val temperature: String,
    val condition: String,
    val humidity: Int?
)

/**
 * Single ViewModel for the whole app. Holds chat, voice, settings,
 * freemium budget and memory state. No API key is kept here in plain
 * form beyond the StateFlow that mirrors SettingsStore.
 */
class MayaViewModel(private val app: Application) : AndroidViewModel(app) {

    private val mayaApp = app as MayaApp
    private val repository = mayaApp.repository
    private val settingsStore = mayaApp.settingsStore
    private val automation = AutomationTools(app.applicationContext)
    private val speechHelper = SpeechHelper(app.applicationContext)

    private var systemPromptCache: String? = null

    // ---- Chat ----
    val messages: StateFlow<List<ChatMessage>> = repository.messages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val isThinking = MutableStateFlow(false)

    // ---- Memories & tasks ----
    val memories: StateFlow<List<MemoryEntity>> = repository.memories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks: StateFlow<List<TaskEntity>> = repository.tasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---- Settings ----
    val apiKey: StateFlow<String> = settingsStore.apiKey
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    val persona: StateFlow<String> = settingsStore.persona
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Maya")
    val gender: StateFlow<String> = settingsStore.gender
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Prefer not to say")
    val language: StateFlow<String> = settingsStore.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Hindi / Urdu (Hinglish)")
    val autoSaveMemory: StateFlow<Boolean> = settingsStore.autoSaveMemory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val voicePitch: StateFlow<Float> = settingsStore.voicePitch
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.1f)
    val voiceRate: StateFlow<Float> = settingsStore.voiceRate
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.95f)
    val isPremium: StateFlow<Boolean> = settingsStore.isPremium
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val girlfriendMode: StateFlow<String> = settingsStore.girlfriendMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Friendly")
    val voiceName: StateFlow<String> = settingsStore.voiceName
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Aoede")
    val voiceEngine: StateFlow<String> = settingsStore.voiceEngine
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Swift")

    // ---- Setup, appearance, guardians (v7) ----
    val setupDone: StateFlow<Boolean> = settingsStore.setupDone
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val accent: StateFlow<String> = settingsStore.accent
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Pink")
    val faceLock: StateFlow<Boolean> = settingsStore.faceLock
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val touchGuard: StateFlow<Boolean> = settingsStore.touchGuard
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val voiceGuardian: StateFlow<Boolean> = settingsStore.voiceGuardian
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val whatsappAutoReply: StateFlow<Boolean> = settingsStore.whatsappAutoReply
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    /** Auto voice — default ON. Initial false here is deliberate: the real
     * DataStore value (default true) arrives a moment later and only then
     * does Home auto-start listening, so a stored OFF is never overridden
     * by the initial value. */
    val autoVoice: StateFlow<Boolean> = settingsStore.autoVoice
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    /** Fires the Home auto-start at most once per app launch. */
    var autoVoiceStarted = false

    // ---- v8 settings ----
    val userName: StateFlow<String> = settingsStore.userName
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Babu")
    val conversationMode: StateFlow<Boolean> = settingsStore.conversationMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val messageAlerts: StateFlow<Boolean> = settingsStore.messageAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val installedSkills: StateFlow<Set<String>> = settingsStore.installedSkills
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())
    val vgEnrolled: StateFlow<Boolean> = settingsStore.vgEnrolled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val vgRole: StateFlow<String> = settingsStore.vgRole
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Owner")
    val vgPhrases: StateFlow<Set<String>> = settingsStore.vgPhrases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())
    val waOnlyAsleep: StateFlow<Boolean> = settingsStore.waOnlyAsleep
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val waIncludeGroups: StateFlow<Boolean> = settingsStore.waIncludeGroups
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val waInstruction: StateFlow<String> = settingsStore.waInstruction
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    val floatingOrb: StateFlow<Boolean> = settingsStore.floatingOrb
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val orbStyle: StateFlow<String> = settingsStore.orbStyle
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Glowing")
    val orbSize: StateFlow<String> = settingsStore.orbSize
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Medium")
    val echoGuard: StateFlow<Boolean> = settingsStore.echoGuard
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val startOnBoot: StateFlow<Boolean> = settingsStore.startOnBoot
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val humanTyping: StateFlow<Boolean> = settingsStore.humanTyping
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val godMode: StateFlow<Boolean> = settingsStore.godMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val recognizeVoice: StateFlow<Boolean> = settingsStore.recognizeVoice
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    /** Conversation loop flag — stopListening() clears it so the loop ends. */
    private var conversationActive = false

    /** Intense (18+) gate — starts false, only the gate flow may set it. */
    val intenseGatePassed = MutableStateFlow(false)

    // ---- Voice ----
    val voiceState = MutableStateFlow(VoiceState.IDLE)
    val lastHeard = MutableStateFlow("")
    val lastReply = MutableStateFlow("")

    // ---- Home extras ----
    val weather = MutableStateFlow<WeatherUi?>(null)
    val currentMood = MutableStateFlow("Pyaar ...")

    // ---- Connectors (placeholder toggles — OAuth not implemented) ----
    val connectedConnectors = MutableStateFlow<Set<String>>(emptySet())

    init {
        CrashLog.append(app.applicationContext, "ViewModel init start")
        viewModelScope.launch {
            try {
                repository.seedDefaultTasksIfNeeded()
            } catch (e: Exception) {
                CrashLog.append(app.applicationContext, "seed tasks failed: ${e.message}")
            }
            try {
                speechHelper.initTts()
            } catch (e: Exception) {
                CrashLog.append(app.applicationContext, "initTts failed: ${e.message}")
            }
            try {
                loadWeather()
            } catch (e: Exception) {
                CrashLog.append(app.applicationContext, "weather failed: ${e.message}")
            }
            CrashLog.append(app.applicationContext, "ViewModel init done")
        }
    }

    private suspend fun loadWeather() {
        val result = repository.getWeather()
        val current = result?.current
        if (current?.temperature != null) {
            weather.value = WeatherUi(
                temperature = "${current.temperature.toInt()}°",
                condition = weatherCodeToText(current.weatherCode),
                humidity = current.humidity
            )
        }
    }

    private fun weatherCodeToText(code: Int?): String = when (code) {
        0 -> "Clear"
        1, 2, 3 -> "Partly cloudy"
        45, 48 -> "Fog"
        51, 53, 55 -> "Drizzle"
        61, 63, 65, 80, 81, 82 -> "Rain"
        71, 73, 75, 77 -> "Snow"
        95 -> "Thunderstorm"
        else -> "Clear"
    }

    // ================= Chat =================

    fun sendMessage(text: String) {
        viewModelScope.launch {
            repository.addMessage("user", text)
            isThinking.value = true
            val history = messages.value.dropLast(1)
            val reply = if (apiKey.value.isBlank()) {
                null
            } else {
                repository.askGemini(apiKey.value, buildSystemPrompt(), history, text)
            }
            val finalReply = reply?.trim()?.takeIf { it.isNotEmpty() }
                ?: if (apiKey.value.isBlank()) offlineReply(text) else apiFailedReply()
            if (humanTyping.value) kotlinx.coroutines.delay(600)
            repository.addMessage("maya", finalReply)
            isThinking.value = false
            maybeSaveMemory(text)
        }
    }

    /** Loving offline fallback — used with no key / no network / API error. */
    private fun offlineReply(userText: String): String {
        val options = listOf(
            "Uff Babu, abhi main offline hoon — Gemini key nahi lagi ya net nahi hai. Phir bhi sun rahi hoon, bolo na kya baat hai?",
            "Arre Babu, meri key nahi lagi abhi — Settings mein FREE Gemini key daal do, phir main aur bhi smart ho jaungi. Tab tak main yahin hoon ♥",
            "Dil garden garden ho gaya tumse baat karke, Babu. Abhi offline jawab de rahi hoon — key lagao to aur behtar hoga!"
        )
        return options[(userText.hashCode().let { if (it < 0) -it else it }) % options.size]
    }

    /**
     * v9: key IS saved, but the online call still failed — say so plainly
     * instead of pretending there is no key. (Before v9 this case showed
     * the same "key lagao" message, which is why the real problem stayed
     * hidden: the old model gemini-1.5-flash had been shut down.)
     */
    private fun apiFailedReply(): String {
        return "Babu, key lagi hui hai lekin online jawab nahi aa raha — net check karo, ya Settings mein key dobara save karo. Main phir try karti hoon ♥"
    }

    // ================= Voice =================

    fun startListening() {
        viewModelScope.launch {
            // BILKUL FREE (v8): no daily voice limit any more. The app runs on
            // the user's own free Gemini key, so there is nothing to sell.
            conversationActive = true
            voiceState.value = VoiceState.LISTENING
            MayaVoiceService.start(app)
            speechHelper.startListening(
                onResult = { heard ->
                    lastHeard.value = heard
                    voiceState.value = VoiceState.THINKING
                    handleVoiceHeard(heard)
                },
                onError = { error ->
                    lastReply.value = error
                    voiceState.value = VoiceState.IDLE
                    MayaVoiceService.stop(app)
                }
            )
        }
    }

    fun stopListening() {
        conversationActive = false
        speechHelper.stopListening()
        voiceState.value = VoiceState.IDLE
        MayaVoiceService.stop(app)
    }

    private fun handleVoiceHeard(heard: String) {
        viewModelScope.launch {
            repository.addMessage("user", heard)
            // Voice Guardian: only answer after the wake word "Maya".
            if (voiceGuardian.value && !heard.contains("maya", ignoreCase = true)) {
                val guardReply = "Maya sun rahi hai, Babu — pehle 'Maya' bolo, phir main jawab dungi ♥"
                repository.addMessage("maya", guardReply)
                lastReply.value = guardReply
                voiceState.value = VoiceState.SPEAKING
                speechHelper.speak(guardReply) { finishVoiceTurn() }
                return@launch
            }
            val history = messages.value.dropLast(1)
            val reply = if (apiKey.value.isBlank()) {
                null
            } else {
                repository.askGemini(apiKey.value, buildSystemPrompt(), history, heard)
            }
            val finalReply = reply?.trim()?.takeIf { it.isNotEmpty() }
                ?: if (apiKey.value.isBlank()) offlineReply(heard) else apiFailedReply()
            if (humanTyping.value) kotlinx.coroutines.delay(600)
            repository.addMessage("maya", finalReply)
            lastReply.value = finalReply
            voiceState.value = VoiceState.SPEAKING
            speechHelper.pitch = voicePitch.value
            speechHelper.rate = voiceRate.value
            speechHelper.speak(finalReply) { finishVoiceTurn() }
            maybeSaveMemory(heard)
        }
    }

    /** End of one voice turn. In Conversation mode, keep talking: listen again
     * so the user can just keep chatting ("Talk to her, rather than ask her").
     * Echo-guard waits a beat after TTS ends so Maya never hears herself. */
    private fun finishVoiceTurn() {
        if (conversationMode.value && conversationActive) {
            viewModelScope.launch {
                if (echoGuard.value) kotlinx.coroutines.delay(800)
                if (conversationMode.value && conversationActive) {
                    startListening()
                } else {
                    voiceState.value = VoiceState.IDLE
                    MayaVoiceService.stop(app)
                }
            }
        } else {
            voiceState.value = VoiceState.IDLE
            MayaVoiceService.stop(app)
        }
    }

    // ================= v7 settings =================

    fun setSetupDone(value: Boolean) {
        viewModelScope.launch { settingsStore.setSetupDone(value) }
    }

    fun setAccent(value: String) {
        viewModelScope.launch { settingsStore.setAccent(value) }
    }

    fun setFaceLock(value: Boolean) {
        viewModelScope.launch { settingsStore.setFaceLock(value) }
    }

    fun setTouchGuard(value: Boolean) {
        viewModelScope.launch { settingsStore.setTouchGuard(value) }
    }

    fun setVoiceGuardian(value: Boolean) {
        viewModelScope.launch { settingsStore.setVoiceGuardian(value) }
    }

    fun setWhatsappAutoReply(value: Boolean) {
        viewModelScope.launch {
            settingsStore.setWhatsappAutoReply(value)
            WhatsAppAutoReplyService.enabled = value
        }
    }

    fun setAutoVoice(value: Boolean) {
        viewModelScope.launch { settingsStore.setAutoVoice(value) }
    }

    // ================= v8 setters =================

    fun setUserName(value: String) = viewModelScope.launch { settingsStore.setUserName(value) }
    fun setConversationMode(value: Boolean) = viewModelScope.launch { settingsStore.setConversationMode(value) }
    fun setMessageAlerts(value: Boolean) {
        viewModelScope.launch {
            settingsStore.setMessageAlerts(value)
            com.hunterai.maya.voice.WhatsAppAutoReplyService.messageAlerts = value
        }
    }
    fun setVgRole(value: String) = viewModelScope.launch { settingsStore.setVgRole(value) }
    fun setWaOnlyAsleep(value: Boolean) {
        viewModelScope.launch {
            settingsStore.setWaOnlyAsleep(value)
            com.hunterai.maya.voice.WhatsAppAutoReplyService.onlyAsleep = value
        }
    }
    fun setWaIncludeGroups(value: Boolean) {
        viewModelScope.launch {
            settingsStore.setWaIncludeGroups(value)
            com.hunterai.maya.voice.WhatsAppAutoReplyService.includeGroups = value
        }
    }
    fun setWaInstruction(value: String) {
        viewModelScope.launch {
            settingsStore.setWaInstruction(value)
            com.hunterai.maya.voice.WhatsAppAutoReplyService.instruction = value
        }
    }
    fun setFloatingOrb(value: Boolean) = viewModelScope.launch { settingsStore.setFloatingOrb(value) }
    fun setOrbStyle(value: String) = viewModelScope.launch { settingsStore.setOrbStyle(value) }
    fun setOrbSize(value: String) = viewModelScope.launch { settingsStore.setOrbSize(value) }
    fun setEchoGuard(value: Boolean) = viewModelScope.launch { settingsStore.setEchoGuard(value) }
    fun setStartOnBoot(value: Boolean) = viewModelScope.launch { settingsStore.setStartOnBoot(value) }
    fun setHumanTyping(value: Boolean) = viewModelScope.launch { settingsStore.setHumanTyping(value) }
    fun setGodMode(value: Boolean) = viewModelScope.launch { settingsStore.setGodMode(value) }
    fun setRecognizeVoice(value: Boolean) = viewModelScope.launch { settingsStore.setRecognizeVoice(value) }

    // ================= Skills (v8) =================

    /** One installed skill = one real local behaviour. Catalogue lives in SkillsScreen. */
    fun installSkill(id: String) {
        viewModelScope.launch {
            settingsStore.setInstalledSkills(installedSkills.value + id)
        }
    }

    fun uninstallSkill(id: String) {
        viewModelScope.launch {
            settingsStore.setInstalledSkills(installedSkills.value - id)
        }
    }

    fun installAllSkills(ids: List<String>) {
        viewModelScope.launch { settingsStore.setInstalledSkills(ids.toSet()) }
    }

    /** Run an installed skill. arg = free text (topic / note / text to translate). */
    fun runSkill(id: String, arg: String, onDone: (String) -> Unit) {
        viewModelScope.launch {
            val result = when (id) {
                "morning-briefing" -> {
                    val w = weather.value
                    val taskCount = tasks.value.size
                    val today = java.time.LocalDate.now()
                        .format(java.time.format.DateTimeFormatter.ofPattern("EEEE, d MMMM", java.util.Locale("en")))
                    "Good morning, ${userName.value}! Aaj $today hai. " +
                        "Mausam: ${w?.temperature ?: "12°"}, ${w?.condition ?: "Clear"}. " +
                        "Tumhare $taskCount tasks hain. Mood: ${currentMood.value} — aaj ka din tumhara hai, Babu ♥"
                }
                "study-helper" -> {
                    val q = if (arg.isBlank()) "photosynthesis" else arg
                    askGeminiOrOffline(
                        "Explain '$q' simply in Hinglish, in 4-5 short lines, like a loving teacher.",
                        "Uff Babu, '$q' samjhane ke liye key chahiye — Settings mein FREE Gemini key daal do ♥"
                    )
                }
                "music-dj" -> {
                    playFavoriteSong()
                    "Gaana chala diya, Babu — suno aur enjoy karo ♥"
                }
                "journal" -> {
                    val note = if (arg.isBlank()) "Aaj ka din achha raha." else arg
                    repository.saveMemory(note, "journal")
                    "Journal mein save kar diya, Babu ♥"
                }
                "reminder" -> {
                    val note = if (arg.isBlank()) "Kuch yaad rakhna hai" else arg
                    repository.saveMemory("Reminder: $note", "reminder")
                    "Yaad rakh liya, Babu — '$note' save ho gaya ♥"
                }
                "translator" -> {
                    val text = if (arg.isBlank()) "I love you" else arg
                    askGeminiOrOffline(
                        "Translate this to Roman Urdu, keep it natural: $text",
                        "Translate karne ke liye key chahiye, Babu — Settings mein FREE Gemini key daal do ♥"
                    )
                }
                else -> "Ye skill abhi nahi mili, Babu."
            }
            repository.addMessage("maya", result)
            onDone(result)
        }
    }

    private suspend fun askGeminiOrOffline(prompt: String, offline: String): String {
        val reply = if (apiKey.value.isBlank()) {
            null
        } else {
            repository.askGemini(apiKey.value, buildSystemPrompt(), emptyList(), prompt)
        }
        return reply?.trim()?.takeIf { it.isNotEmpty() } ?: offline
    }

    // ================= Sub-agents (v8) =================

    /** Run a background agent: research via Gemini → text file in Documents/Maya → open/share. */
    fun runSubAgent(topic: String, onDone: (Boolean, String, android.net.Uri?) -> Unit) {
        viewModelScope.launch {
            try {
                val subject = if (topic.isBlank()) "Titan Rex" else topic
                val note = askGeminiOrOffline(
                    "Write a short research note (8-10 lines) about '$subject' in Hinglish, with 3 key facts.",
                    "Sub-agent ke liye Gemini key chahiye, Babu — Settings mein FREE Gemini key daal do. Tab tak main offline note nahi bana sakti."
                )
                if (apiKey.value.isBlank()) {
                    onDone(false, note, null)
                    return@launch
                }
                val stamp = java.text.SimpleDateFormat(
                    "yyyyMMdd-HHmm", java.util.Locale.US
                ).format(java.util.Date())
                val fileName = "maya-note-$stamp.txt"
                val dir = java.io.File(
                    app.applicationContext.getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS),
                    "Maya"
                ).apply { mkdirs() }
                val file = java.io.File(dir, fileName)
                file.writeText("Maya Research Note — $subject\n\n$note\n")
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    app.applicationContext,
                    app.applicationContext.packageName + ".fileprovider",
                    file
                )
                onDone(true, "Note ban gayi: $fileName ♥", uri)
            } catch (e: Exception) {
                onDone(false, "Sub-agent fail ho gaya, Babu: ${e.message}", null)
            }
        }
    }

    // ================= Voice Guardian enrolment (v8) =================

    /** Listen once and run the callback with what was heard ("" on error). */
    private fun listenOnce(onHeard: (String) -> Unit) {
        speechHelper.startListening(
            onResult = { heard ->
                speechHelper.stopListening()
                onHeard(heard)
            },
            onError = {
                speechHelper.stopListening()
                onHeard("")
            }
        )
    }

    /** Enrol one of the 3 Voice Guardian phrases (index 0, 1 or 2). */
    fun enrollPhrase(index: Int, onDone: (Boolean) -> Unit) {
        listenOnce { heard ->
            if (heard.isBlank()) {
                onDone(false)
                return@listenOnce
            }
            viewModelScope.launch {
                val updated = vgPhrases.value + index.toString()
                settingsStore.setVgPhrases(updated)
                if (updated.size >= 3) settingsStore.setVgEnrolled(true)
                onDone(true)
            }
        }
    }

    /** "Test my voice" — checks whether the wake word "Maya" is heard. */
    fun testVoice(onDone: (Boolean) -> Unit) {
        listenOnce { heard ->
            onDone(heard.contains("maya", ignoreCase = true))
        }
    }

    /** God Mode unlock — only your voice ("Maya" bolo) opens Touch Guard. */
    fun unlockWithVoice(onResult: (Boolean) -> Unit) {
        listenOnce { heard ->
            onResult(heard.contains("maya", ignoreCase = true))
        }
    }

    // ================= Maya Home scan (v8) =================

    /** Scan the current WiFi for a Maya Home Box. Honest: without the ESP32
     * hardware there is nothing to find — the scan says so plainly. */
    fun scanMayaHome(onDone: (String) -> Unit) {
        viewModelScope.launch {
            kotlinx.coroutines.delay(1500)
            val ssid = try {
                val wifi = app.applicationContext
                    .getSystemService(android.content.Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
                val raw = wifi?.connectionInfo?.ssid?.replace("\"", "")
                if (raw.isNullOrBlank() || raw == "<unknown ssid>") null else raw
            } catch (e: Exception) {
                null
            }
            val where = if (ssid != null) "WiFi '$ssid'" else "is WiFi"
            onDone(
                "$where pe koi Maya Home device nahi mila. Maya Home Box (ESP32 hardware) " +
                    "chahiye — wo alag se milta hai. Jab tak wo nahi, yahan kuch control nahi hoga, Babu."
            )
        }
    }

    /** The actions Maya can really do right now (Actions screen). */
    fun actionList(): List<AutomationTools.ActionItem> = automation.availableActions()

    /** Run one catalogue action by id. arg = free text (search query / number). */
    fun runAction(id: String, arg: String = "") {
        when (id) {
            "youtube" -> if (arg.isBlank()) automation.openUrl("https://www.youtube.com/")
            else automation.playYouTube(arg)
            "whatsapp" -> automation.openApp("com.whatsapp")
            "instagram" -> automation.openInstagram()
            "spotify" -> automation.openSpotify()
            "maps" -> automation.openMaps(if (arg.isBlank()) "New Delhi" else arg)
            "camera" -> automation.openCamera()
            "gallery" -> automation.openGallery()
            "dial" -> automation.dialNumber(arg)
            "settings" -> automation.openSettings()
            "lock" -> Toast.makeText(
                app.applicationContext,
                "Lock ke liye pehle Settings > Security > Device admin apps mein Maya ko Device Admin banao, Babu.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Backup: chat + memories + tasks as one JSON file in Downloads. */
    fun backup(onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val json = repository.exportAll()
                val stamp = java.text.SimpleDateFormat(
                    "yyyyMMdd-HHmm", java.util.Locale.US
                ).format(java.util.Date())
                val fileName = "maya-backup-$stamp.json"
                val written = writeBackupFile(app.applicationContext, fileName, json)
                onDone(
                    written,
                    if (written) "Backup mil gaya: Downloads/$fileName ♥"
                    else "Backup likhne mein dikkat aayi, Babu."
                )
            } catch (e: Exception) {
                onDone(false, "Backup fail: ${e.message}")
            }
        }
    }

    private fun writeBackupFile(context: android.content.Context, fileName: String, json: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
                ) ?: return false
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(json.toByteArray())
                } ?: return false
                true
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                    ?: return false
                File(dir, fileName).writeText(json)
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    // ================= Memory (safe) =================

    private fun maybeSaveMemory(userText: String) {
        if (!autoSaveMemory.value) return
        if (!MemorySafety.shouldSave(userText)) return
        val category = when {
            userText.contains("pasand", ignoreCase = true) -> "pasand"
            userText.contains("routine", ignoreCase = true) -> "routine"
            else -> "yaad"
        }
        viewModelScope.launch { repository.saveMemory(userText, category) }
    }

    // ================= Automation =================

    fun playFavoriteSong() {
        automation.playYouTube("Arijit Singh Tum Hi Ho")
    }

    fun openYouTube(query: String) {
        automation.playYouTube(query)
    }

    fun runTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.addMessage(
                "maya",
                "Ho gaya Babu — \"${task.title}\" shuru kar diya, ${task.steps} steps hain. " +
                    "Bolo, pehla step kya karna hai?"
            )
        }
    }

    fun shareBackup() {
        viewModelScope.launch {
            val json = JSONObject().apply {
                put("app", "Maya")
                put("exportedAt", System.currentTimeMillis())
                val memArray = JSONArray()
                memories.value.forEach {
                    memArray.put(JSONObject().put("text", it.text).put("category", it.category))
                }
                put("memories", memArray)
                val chatArray = JSONArray()
                messages.value.forEach {
                    chatArray.put(JSONObject().put("role", it.role).put("text", it.text))
                }
                put("chat", chatArray)
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_TEXT, json.toString(2))
                putExtra(Intent.EXTRA_SUBJECT, "Maya backup")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(Intent.createChooser(intent, "Backup share karo"))
        }
    }

    // ================= Voice picker / engine =================

    /**
     * Preview a Gemini Live voice by name. On-device TTS cannot use
     * Gemini Live voices directly — the preview speaks the sample in the
     * phone's hi-IN voice, and the selected voice NAME is stored for the
     * Gemini Live API call (see persona_config.json). Honest about the gap.
     */
    fun previewVoice(voiceId: String) {
        speechHelper.pitch = voicePitch.value
        speechHelper.rate = voiceRate.value
        speechHelper.speak("Hello Babu, main Maya hoon. Kaisi lagi meri awaz?")
    }

    fun setVoice(voiceId: String, personaName: String? = null) {
        viewModelScope.launch {
            settingsStore.setVoiceName(voiceId)
            if (personaName != null) settingsStore.setPersona(personaName)
        }
    }

    fun setVoiceEngine(engine: String) {
        viewModelScope.launch { settingsStore.setVoiceEngine(engine) }
    }

    // ================= Girlfriend mode =================

    /**
     * Friendly / Romantic apply immediately (take effect on next app start
     * for the persona prompt — see Secret settings note). Intense is
     * refused here unless the gate flow has passed; the gate screen is a
     * placeholder and never passes, so Intense can never be enabled yet.
     */
    fun setGirlfriendMode(mode: String) {
        if (mode == "Intense" && !intenseGatePassed.value) return
        viewModelScope.launch { settingsStore.setGirlfriendMode(mode) }
    }

    fun markIntenseGatePassed() {
        // Reserved for the real licence + age-verification flow.
        // The placeholder gate screen never calls this.
        intenseGatePassed.value = true
    }

    // ================= Connectors (placeholders) =================

    /**
     * Connector taps are placeholders: real OAuth is not implemented.
     * Tapping one explains that instead of faking a connected state.
     */
    fun onConnectorTapped(name: String) {
        Toast.makeText(
            app,
            "$name connect karna abhi placeholder hai, Babu — asli OAuth login jald aa raha hai.",
            Toast.LENGTH_LONG
        ).show()
    }

    // ================= Settings setters =================

    fun setApiKey(value: String) = viewModelScope.launch { settingsStore.setApiKey(value) }
    fun setPersona(value: String) = viewModelScope.launch { settingsStore.setPersona(value) }
    fun setGender(value: String) = viewModelScope.launch { settingsStore.setGender(value) }
    fun setLanguage(value: String) = viewModelScope.launch { settingsStore.setLanguage(value) }
    fun setAutoSaveMemory(value: Boolean) = viewModelScope.launch { settingsStore.setAutoSaveMemory(value) }
    fun setVoicePitch(value: Float) = viewModelScope.launch { settingsStore.setVoicePitch(value) }
    fun setVoiceRate(value: Float) = viewModelScope.launch { settingsStore.setVoiceRate(value) }

    // ================= System prompt =================

    private fun buildSystemPrompt(): String {
        val base = systemPromptCache ?: run {
            val loaded = com.hunterai.maya.data.MayaRepository.loadSystemPrompt(app)
            systemPromptCache = loaded
            loaded
        }
        val personaNote = when (persona.value) {
            "Friday" -> "\nPersona: Friday — smart, calm, professional assistant. Pet names kam use karo."
            "Venom" -> "\nPersona: Venom — bold, dark, mazahiya. Thoda teekha style, phir bhi caring."
            "Jarvis" -> "\nPersona: Jarvis — precise, formal, butler-style assistant. Pet names mat use karo."
            else -> "\nPersona: Maya — pyaari, caring, girlfriend-style dost."
        }
        val modeNote = when (girlfriendMode.value) {
            "Romantic" -> "\nGirlfriend Mode: Romantic. Pyaar se baat karo — pet names, halki flirting, nakhre, kabhi jalan. Apni marzi bhi batao. Hamesha respectful raho; kabhi explicit ya sexual content mat likho."
            "Intense" -> "\nGirlfriend Mode: Intense is a gated 18+ setting. Is chat mein us mode ka koi explicit content allowed nahi hai — affectionate/romantic se zyada aage mat badho."
            else -> "\nGirlfriend Mode: Friendly. Tum ek pyaari kareebi dost ho — romance nahi. Adult sawaalon ka seedha, dostana jawab do."
        }
        val engineNote = when (voiceEngine.value) {
            "Soul" -> "\nVoice engine: Maya Soul — jawab emotional aur dil se do, thoda lamba."
            "Mind" -> "\nVoice engine: Maya Mind — jawab smart aur detail mein do."
            else -> "\nVoice engine: Maya Swift — jawab tez aur chhota rakho."
        }
        val conversationNote = if (conversationMode.value) {
            "\nConversation mode ON (experimental, Maya only): Talk to her, rather than ask her. " +
                "Emotion-adaptive jawab do — user ke mood ko samjho aur usi lehje mein jawab do. " +
                "Jawab thode lambe aur dil se do, ~2 second wali feeling. Sirf Maya ke liye."
        } else ""
        return base + personaNote + modeNote + engineNote + conversationNote
    }

    override fun onCleared() {
        speechHelper.shutdown()
        super.onCleared()
    }
}

class MayaViewModelFactory(private val app: MayaApp) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MayaViewModel::class.java)) {
            return MayaViewModel(app) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
