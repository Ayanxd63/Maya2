package com.hunterai.maya.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.data.TaskEntity
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Yaadein — Memory & custom automated tasks, like the reference screen:
 * built-in tasks ("gemini se poochho", "gemini video", "gemini image",
 * "chatgpt image"...), the auto-save toggle "Baat ke baad khud yaad rakhe",
 * and Backup & restore.
 */
@Composable
fun MemoryScreen(viewModel: MayaViewModel, navController: NavController) {
    val tasks by viewModel.tasks.collectAsState()
    val memories by viewModel.memories.collectAsState()
    val autoSave by viewModel.autoSaveMemory.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "Yaadein",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = MayaColors.TextDark
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Maya tumhari baatein aur kaam yaad rakhti hai, Babu ♥",
                fontSize = 14.sp,
                color = MayaColors.TextMuted
            )
        }

        // Auto-save toggle
        item {
            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Baat ke baad khud yaad rakhe",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MayaColors.TextDark
                        )
                        Text(
                            "Har baat khatam hone par kaam ki baatein khud save karti hai",
                            fontSize = 13.sp,
                            color = MayaColors.TextBody
                        )
                    }
                    Switch(
                        checked = autoSave,
                        onCheckedChange = { viewModel.setAutoSaveMemory(it) }
                    )
                }
            }
        }

        // Built-in tasks
        item {
            Text(
                "Built-in tasks",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MayaColors.TextDark
            )
        }
        items(tasks) { task ->
            TaskRow(task = task, onRun = { viewModel.runTask(task) })
        }

        // Saved memories
        if (memories.isNotEmpty()) {
            item {
                Text(
                    "Meri yaadein",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MayaColors.TextDark
                )
            }
            items(memories) { memory ->
                NeumorphicCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 18.dp) {
                    Column {
                        Text(
                            memory.text,
                            fontSize = 15.sp,
                            color = MayaColors.TextDark
                        )
                        Text(
                            memory.category,
                            fontSize = 12.sp,
                            color = MayaColors.TextMuted
                        )
                    }
                }
            }
        }

        // Backup & restore
        item {
            NeumorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.shareBackup() }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Backup, contentDescription = null, tint = MayaColors.Primary)
                    Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(
                            "Backup & restore",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MayaColors.TextDark
                        )
                        Text(
                            "Apni yaadein aur chats dusre phone pe le jao",
                            fontSize = 13.sp,
                            color = MayaColors.TextBody
                        )
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MayaColors.TextMuted)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun TaskRow(task: TaskEntity, onRun: () -> Unit) {
    NeumorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onRun() },
        cornerRadius = 20.dp
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    task.title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MayaColors.TextDark
                )
                Text(
                    "${task.steps} steps  •  ${task.type}  •  built-in",
                    fontSize = 13.sp,
                    color = MayaColors.Primary
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = MayaColors.Primary)
                Text("Chalao", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MayaColors.Primary)
            }
        }
    }
}
