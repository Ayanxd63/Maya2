package com.hunterai.maya.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.ui.theme.NeumorphicCard
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Voice engine screen.
 *
 * Two cards: Normal (selected) vs Advanced Agentic — "Maya ke full
 * version ke saath milta hai — getmaya.online se." Tapping Advanced only
 * explains that; it does not enable anything in this build.
 *
 * Normal engines (affect reply style/speed via the system prompt):
 *  - Maya Swift — "Sabse tez" (default, selected)
 *  - Maya Soul  — "Asli emotions" (badge "Thoda")
 *  - Maya Mind  — "Tez dimaag"
 */
@Composable
fun VoiceEngineScreen(viewModel: MayaViewModel, navController: NavController) {
    val engine by viewModel.voiceEngine.collectAsState()
    var showAdvancedInfo by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Voice engine", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
        Text(
            "Maya kaise soche aur kitni tez jawab de — yahan se chuno, Babu.",
            fontSize = 14.sp,
            color = MayaColors.TextMuted
        )

        // Normal card
        NeumorphicCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = MayaColors.SurfaceBlue
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row {
                    Text("Normal", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                    Spacer(Modifier.weight(1f))
                    Text("Selected", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MayaColors.Primary)
                }
                EngineRow(
                    name = "Maya Swift",
                    tag = "Sabse tez",
                    selected = engine == "Swift",
                    onClick = { viewModel.setVoiceEngine("Swift") }
                )
                EngineRow(
                    name = "Maya Soul",
                    tag = "Asli emotions",
                    badge = "Thoda",
                    selected = engine == "Soul",
                    onClick = { viewModel.setVoiceEngine("Soul") }
                )
                EngineRow(
                    name = "Maya Mind",
                    tag = "Tez dimaag",
                    selected = engine == "Mind",
                    onClick = { viewModel.setVoiceEngine("Mind") }
                )
            }
        }

        // Advanced Agentic card
        NeumorphicCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showAdvancedInfo = true }
        ) {
            Column {
                Text("Advanced Agentic", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Maya ke full version ke saath milta hai — getmaya.online se.",
                    fontSize = 14.sp,
                    color = MayaColors.TextBody
                )
                Text(
                    "Tap karo to detail dekho",
                    fontSize = 12.sp,
                    color = MayaColors.Primary
                )
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showAdvancedInfo) {
        AlertDialog(
            onDismissRequest = { showAdvancedInfo = false },
            title = { Text("Advanced Agentic") },
            text = {
                Text(
                    "Advanced Agentic engine Maya ke full version mein milta hai — getmaya.online se. " +
                        "Is free build mein sirf Normal engines (Swift / Soul / Mind) chalte hain, Babu."
                )
            },
            confirmButton = {
                TextButton(onClick = { showAdvancedInfo = false }) { Text("Theek hai") }
            }
        )
    }
}

@Composable
private fun EngineRow(
    name: String,
    tag: String,
    badge: String? = null,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MayaColors.TextDark)
            Text(tag, fontSize = 13.sp, color = MayaColors.TextMuted)
        }
        if (badge != null) {
            Text(
                badge,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MayaColors.PinkDeep,
                modifier = Modifier.padding(end = 8.dp)
            )
        }
        Text(
            if (selected) "●" else "○",
            fontSize = 18.sp,
            color = if (selected) MayaColors.Primary else MayaColors.TextMuted
        )
    }
}
