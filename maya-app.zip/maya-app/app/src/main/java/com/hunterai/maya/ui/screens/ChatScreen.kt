package com.hunterai.maya.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hunterai.maya.data.ChatMessage
import com.hunterai.maya.ui.navigation.AppNav
import com.hunterai.maya.ui.theme.MayaColors
import com.hunterai.maya.viewmodel.MayaViewModel

/**
 * Chat — text conversation with Maya. Messages are stored in Room and
 * shown with Maya's bubble on the left (pink/white) and yours on the right.
 */
@Composable
fun ChatScreen(viewModel: MayaViewModel, navController: NavController) {
    val messages by viewModel.messages.collectAsState()
    val isThinking by viewModel.isThinking.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (messages.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("♥", fontSize = 48.sp, color = MayaColors.PinkDeep)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Arre waah hello Babu, kaise ho aap aaj?",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium,
                        color = MayaColors.TextDark
                    )
                    Text(
                        "Kya kar rahe the? Bolo, main sun rahi hoon.",
                        fontSize = 14.sp,
                        color = MayaColors.TextMuted
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    ChatBubble(message)
                }
                if (isThinking) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp))
                                    .background(Color.White)
                                    .padding(12.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = MayaColors.Primary,
                                    strokeWidth = 2.dp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Input row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Maya se kuch bhi poochho...") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                maxLines = 3
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = { navController.navigate(AppNav.VOICE) },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MayaColors.SurfaceBlue)
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Bolo", tint = MayaColors.Primary)
            }
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = {
                    val text = input.trim()
                    if (text.isNotEmpty()) {
                        viewModel.sendMessage(text)
                        input = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MayaColors.Primary)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Bhejo", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    val isMaya = message.role == "maya"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMaya) Arrangement.Start else Arrangement.End
    ) {
        Box(
            modifier = Modifier
                .clip(
                    if (isMaya) RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)
                    else RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp)
                )
                .background(if (isMaya) Color.White else MayaColors.Primary)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                message.text,
                fontSize = 15.sp,
                color = if (isMaya) MayaColors.TextDark else Color.White
            )
        }
    }
}
