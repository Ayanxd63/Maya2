package com.hunterai.maya.data.network

import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Gemini API (Google AI Studio — FREE key, entered by the user in Settings).
 * v9: the model is a @Path so the app can fall back to another model when
 * one is retired. gemini-1.5-flash was SHUT DOWN by Google on 2025-09-29 —
 * that is why every v7/v8 install stayed offline even with a valid key.
 * Current model: gemini-2.5-flash (free tier), fallbacks 2.0-flash and
 * 2.5-flash-lite. The key is passed as a query param per call and is
 * NEVER stored in code.
 */
interface GeminiApi {

    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse

    companion object {
        const val MODEL = "gemini-2.5-flash"
        val MODELS = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-flash-lite")
        private const val BASE_URL = "https://generativelanguage.googleapis.com/"

        fun create(): GeminiApi {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logging)
                .build()
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(GeminiApi::class.java)
        }
    }
}

data class GeminiRequest(
    @SerializedName("system_instruction")
    val systemInstruction: SystemInstruction? = null,
    val contents: List<Content>
) {
    data class SystemInstruction(val parts: List<Part>)
    data class Content(val role: String, val parts: List<Part>)
    data class Part(val text: String)
}

data class GeminiResponse(
    val candidates: List<Candidate>?
) {
    data class Candidate(val content: Content?)
    data class Content(val parts: List<Part>?)
    data class Part(val text: String?)
}
