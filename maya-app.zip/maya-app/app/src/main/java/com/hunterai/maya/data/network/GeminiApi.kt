package com.hunterai.maya.data.network

import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Gemini API (Google AI Studio — FREE key, entered by the user in Settings).
 * Model: gemini-1.5-flash. The key is passed as a query param per call and
 * is NEVER stored in code. If the model name changes, update MODEL below.
 */
interface GeminiApi {

    @POST("v1beta/models/$MODEL:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse

    companion object {
        const val MODEL = "gemini-1.5-flash"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/"

        fun create(): GeminiApi {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logging)
                .build()
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(GeminiApi::class.java)
        }
    }
}

data class GeminiRequest(
    @SerializedName("system_instruction")
    val systemInstruction: SystemInstruction? = null,
    val contents: List<Content>
) {
    data class SystemInstruction(val parts: List<Part>)
    data class Content(val role: String, val parts: List<Part>)
    data class Part(val text: String)
}

data class GeminiResponse(
    val candidates: List<Candidate>?
) {
    data class Candidate(val content: Content?)
    data class Content(val parts: List<Part>?)
    data class Part(val text: String?)
}
