# Maya — by The Hunter AI

A free Android AI voice assistant app. **Original code, written fresh** —
Kotlin + Jetpack Compose (Material3), inspired by the reference screenshots
and the demo video ("Maya AI Android Full Setup Hindi", HunterIsLive).

Maya is a loving, caring companion who speaks Hinglish (Hindi/Urdu in Roman
script) — she calls you **Babu** (default), **Jan** (softer, intimate),
**Janu / Jaaneman / Darling** (rare, playful). She sighs *"Uff Babu"*,
giggles, says *"dil garden garden ho gaya"*, and checks in when you go quiet:
*"Chup hi kyun hai Jan? Main yahin hoon."*

> **Honest note:** this is a complete source project, not a compiled APK.
> It was written on a Linux machine with no Android SDK, so it has **not
> been compiled here**. Open it in Android Studio, build the debug APK and
> install it on a **real phone**. The app runs on your real phone with your
> real location — it contains **no fake GPS / location spoofing, no
> proxy/VPN, and no hosted virtual Android**.

## Screens

- **Splash** — the real splash art from the reference screenshots
  (`res/drawable/splash_art.jpg`: anime girl, neon hearts, night city,
  "MAYA" + "Ek second... load ho raha hai ♥"), full-screen, with the
  animated loading bar overlaid at the bottom.
- **Home** — free-mode banner ("Free mode • aaj 10 min baaki" + "Activate
  karo"), greeting, glowing neural orb, quick cards Gaane / Padhai /
  Journal, info cards Mausam / Aaj / Mood.
- **Chat** — text conversation with Maya, stored in Room.
- **Voice (Conversation Mode)** — big mic screen, orb states
  idle / listening / thinking / speaking.
- **Yaadein (Memory)** — auto-save toggle "Baat ke baad khud yaad rakhe",
  built-in tasks (gemini se poochho, chatgpt se poochho, gemini video,
  gemini image, chatgpt image), Backup & restore (shares a JSON export).
- **Settings** — Gemini API key, persona (Maya / Friday / Venom / Jarvis),
  gender (Male turns on Girlfriend Mode), language, voice pitch/speed,
  Memory section, and links to the screens below.
- **Secret settings — Girlfriend mode** — Friendly (default), Romantic,
  Intense (18+). Applies on next app start; cannot be changed by voice.
  **Intense is gated** behind licence + 18+ age check + double
  confirmation — the gate screen is a placeholder that never bypasses
  the checks, so Intense cannot be enabled in this build. The system
  prompt stays affectionate/romantic at most and never contains
  explicit sexual content.
- **Settings — Memory** — toggle "Maya ko khud se yaad rakhne do"
  (default ON) plus the safety note: passwords, OTP, PIN and card
  numbers are **never** saved. Enforced in code by `MemorySafety.kt`
  (regex deny-list) and memories live only on-device in Room — no
  cloud sync anywhere.
- **Awaaz (Voice picker)** — persona tabs Maya / Friday / Venom / Jarvis,
  "Tap karke suno, phir chuno". Each voice has a play-preview button and
  a selected checkmark. Voice IDs are **real Gemini Live API voice names**
  (Maya: Aoede, Kore, Leda, Zephyr, Laomedeia, Despina, Erinome; Venom:
  Algenib, Charon, Fenrir, Puck, Orus, Enceladus, Iapetus; Friday:
  Sulafat, Umbriel, Autonoe, Sadachbia; Jarvis: Callirrhoe, Alnilam,
  Schedar, Zubenelgenubi). Note: on-device TTS cannot speak in Gemini
  Live voices — the preview plays in the phone's hi-IN voice and the
  selected name is stored for the Live API call.
- **Voice engine** — Normal (Maya Swift "Sabse tez", Maya Soul "Asli
  emotions", Maya Mind "Tez dimaag") vs Advanced Agentic ("Maya ke full
  version ke saath milta hai — getmaya.online se."). The engine changes
  reply style/speed via the system prompt.
- **Connectors** — search bar, filter chips (Sab / Files / Code /
  Notes & tasks), list: Google Drive, GitHub, Vercel, Notion, Telegram,
  Todoist, GitLab, Linear. **Placeholders:** the connect toggles do not
  perform OAuth — tapping one explains that real OAuth login is coming
  soon. No account is ever linked by this screen.
- **Upgrade** — freemium: 10 min/day free voice, locked tools, UPI
  payment. **Payment is a placeholder** (fake UPI ID `hunterai@upi`,
  placeholder QR box) — put your own real UPI ID in before any real sale.
- **Sidebar drawer** — Home, Maya Home, Markets, Marketing, Documents,
  Meri photos, Website/Coding, Terminal, Browser, Accessibility,
  Settings, Maya ke rules, PC ⇌ Phone, Privacy Policy, Upgrade.
  Items without a full screen open an honest "coming soon" page.
- **Bottom nav** — Home, Scan, Mic (highlighted centre), Yaadein, Chat.

## Setup

### Option A — GitHub Actions se APK banao (Android Studio ki zaroorat nahi)

1. GitHub.com par ek **naya repository** banao (public ya private, dono free hain).
2. Is project ki saari files us repo mein upload karo
   (web se: **Add file → Upload files**, ya `git push` se).
3. Repo ke **Actions** tab mein jao → **"Build Maya APK"** workflow
   → **Run workflow** dabao. (Push karne par bhi khud chal jata hai.)
4. Build complete hone par usi run ke page par neeche **Artifacts** mein
   **maya-debug-apk** milega — download karo, andar `app-debug.apk` hoga.
5. APK ko phone par install karo (pehli baar "unknown sources" allow karna).
6. App kholo → **Settings → Gemini API key** mein apni FREE key daalo
   (https://aistudio.google.com/app/apikey se lo) — key sirf phone par rehti hai.

### Option B — Android Studio se

1. Open the project in **Android Studio** (Hedgehog or newer).
2. Let Gradle sync (needs internet once for dependencies).
3. Get a **FREE Gemini API key** at https://aistudio.google.com/app/apikey
   and paste it in the app under **Settings → Gemini API key**.
   The key lives only on your phone (DataStore) — it is never in the code.
4. Run on a real phone (or emulator) and grant Microphone when asked.
5. Build → Build APK(s) for a debug APK you can share.

## What works / what is a placeholder

| Feature | Status |
|---|---|
| Chat with Maya (Gemini 1.5 Flash) | Works, with your own free key |
| Voice in/out (SpeechRecognizer + TTS hi-IN) | Works on device |
| Free 10 min/day voice budget, resets daily | Works (DataStore) |
| Memories auto-save (filtered) + tasks + backup | Works (Room, on-device) |
| Weather card (Open-Meteo, keyless) | Works (online) |
| Open apps / YouTube / WhatsApp via intents | Works |
| Girlfriend mode Friendly / Romantic | Works (prompt-level) |
| Intense (18+) | **Gated placeholder — cannot be enabled yet** |
| Voice picker preview | Plays in phone TTS; Gemini Live voice name stored for Live API |
| Advanced Agentic engine | Not in this free build (getmaya.online) |
| Connectors (Drive, GitHub, …) | **Placeholder UI only — no OAuth** |
| UPI payment / QR | **Placeholder — fake UPI ID** |
| Screenshot (MediaProjection) | **Stub** — needs a capture-permission flow |
| Lock screen (Device Admin) | **Stub** — needs user to enable Device Admin |
| Scan (QR) | Placeholder screen |

## Permissions

Declared (only what the code uses): INTERNET, ACCESS_NETWORK_STATE,
RECORD_AUDIO, CAMERA, READ_MEDIA_IMAGES, READ_MEDIA_AUDIO,
ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION, POST_NOTIFICATIONS,
FOREGROUND_SERVICE, FOREGROUND_SERVICE_MICROPHONE, SYSTEM_ALERT_WINDOW
(optional, floating orb only).

**Not** declared, even though the reference screenshots show them in the
app-info page: call logs, contacts, phone state, SMS, nearby devices.
The app does not read those — if a future feature needs one, add the
permission, the runtime request, and the reason in Settings.

## Project structure

```
settings.gradle.kts / build.gradle.kts / app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/hunterai/maya/
  MainActivity.kt            (NavHost, drawer, bottom nav)
  MayaApp.kt                 (singletons)
  ui/theme/                  (Color, Theme, Neumorphic)
  ui/navigation/AppNav.kt    (routes)
  ui/screens/                (Splash, Home, Chat, Voice, Memory,
                              Settings, SecretSettings, IntenseGate,
                              VoicePicker, VoiceEngine, Connectors,
                              Upgrade, Placeholder)
  viewmodel/MayaViewModel.kt (chat, voice, settings, budget)
  data/                      (Room DB, SettingsStore, MemorySafety,
                              MayaRepository)
  data/network/              (GeminiApi, WeatherApi)
  data/voice/                (SpeechHelper, MayaVoiceService)
  data/freemium/             (FreeLimitManager)
  data/automation/           (AutomationTools)
app/src/main/assets/
  maya_system_prompt.md      (full Maya persona prompt)
  persona_config.json        (voices, engines, modes, safety)
app/src/main/res/values/     (strings.xml, themes.xml)
```

## Persona & voice rules (summary)

Full rules live in `app/src/main/assets/maya_system_prompt.md` and
`persona_config.json`. In short: Hinglish only, never a full English
sentence; Babu by default, Jan when intimate, Janu/Jaaneman/Darling
rarely; "Uff Babu" sigh; "Ho gaya Babu... dekh lo ek baar" / "Ab khush
ho?"; proactive "Chup hi kyun hai Jan? Main yahin hoon."; celebrates
wins, cute apologies, upbeat failures. Conversation Mode = more
emotional/situational. Girlfriend mode turns on when "Male" is selected
in personal settings.

## No secrets

No API keys, passwords, tokens or merchant IDs are in this project.
The Gemini key is entered by the user in Settings and stored only in
the phone's DataStore.

---

## v7 — crash fix + powerful build (2026-11-17)

**The crash, found:** v5 crashed at the end of the splash ("Maya keeps stopping").
Full audit of the startup path (Application, ViewModel init, Room, TTS, Home
composition, voice service) found no fault there. The fault was in
`MainActivity.MayaRoot`: the splash was shown by an early-return branch OUTSIDE
the NavHost, and its `onFinished` called `navController.navigate(HOME)` BEFORE
any NavHost had been composed — so the NavController had NO graph yet, and
`navigate()` throws. Splash rendered fine, then the app died at the exact
moment it should have gone Home. **v7 fix:** the NavHost is ALWAYS composed
(startDestination = splash); the splash is a destination, and its `onFinished`
navigates only after the graph exists. The v6 crash catcher is kept, so if it
ever crashes again the next launch shows the exact stack trace on the
Crash Report screen (Share karo).

**New in v7 (from the HunterIsLive video + getmaya.online study):**
- **Setup screen (first run):** permissions (mic, notifications, battery),
  FREE Gemini key entry with "FREE key banao" link, persona pick. Re-runnable
  from Settings ("Setup dobara chalao").
- **Actions screen:** every real thing Maya can do — YouTube search + open,
  WhatsApp, Instagram, Spotify, Maps, Camera, Gallery, dial, Settings.
  Honest count from `AutomationTools.availableActions()` — no fake "150+".
- **WhatsApp auto-reply:** NotificationListenerService, OFF by default.
  Enable in Settings + system Notification access; replies are short local
  Hinglish templates only — message text never leaves the phone.
- **Face Lock:** biometric / device-credential gate on app launch (BiometricPrompt).
  Always has a fallback — never locks you out.
- **Touch Guard:** lock overlay, long-press to unlock for the session.
- **Voice Guardian:** voice sessions only answer after the wake word "Maya".
- **Appearance:** accent picker — Pink / Blue / Purple (drives Material3 primary).
- **Backup:** chat + memories + tasks as one JSON file in Downloads.
- **Crash catcher kept** (v6) + milestone logging.

**About the 10 MB APK:** a debug APK is ~10 MB — normal. Debug builds carry
extra tooling; the real Maya is 84 MB because it bundles voices, models and
data. Size was never the problem; the crash was. (Release builds are smaller
still; the GitHub workflow builds `assembleDebug`.)

**Honest limits (unchanged):** on-phone voice is device TTS (Hindi hi-IN),
not the video's Gemini Live voice — Gemini Live voice names are stored for
the Live API call only. Full phone control needs the real Maya backend;
this source does what Android allows a normal app to do with public intents.
No fake location, no virtual Android, no mobile number ever asked.
