// Top-level build file — Maya (by The Hunter AI)
// Original code. No API keys, no secrets, no location-spoofing features.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
